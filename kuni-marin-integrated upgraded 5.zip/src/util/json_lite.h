#pragma once

#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace util::json {

/**
 * @brief Minimal strict JSON (RFC 8259) value and parser. Pure C++, no dependencies.
 * @details
 * Exists so that the external tools catalog can be parsed and tested without the UI framework. Limits: depth 64,
 * input 4 MiB. Duplicate object keys: the last one wins.
 */
struct Member;

struct Value {
    enum class Type { NUL, BOOL, NUMBER, STRING, ARRAY, OBJECT };

    Type type = Type::NUL;
    bool boolean = false;
    double number = 0;
    bool integer = false;   // the number literal had no fraction and no exponent
    std::string string;
    std::vector<Value> array;
    std::vector<Member> object;   // Member определён ниже: vector допускает неполный тип, а std::pair<string, Value> внутри Value Clang отвергает

    [[nodiscard]] bool isNull() const noexcept { return type == Type::NUL; }
    [[nodiscard]] bool isBool() const noexcept { return type == Type::BOOL; }
    [[nodiscard]] bool isNumber() const noexcept { return type == Type::NUMBER; }
    [[nodiscard]] bool isString() const noexcept { return type == Type::STRING; }
    [[nodiscard]] bool isArray() const noexcept { return type == Type::ARRAY; }
    [[nodiscard]] bool isObject() const noexcept { return type == Type::OBJECT; }

    /// Object member lookup; nullptr if this is not an object or the key is missing.
    [[nodiscard]] const Value* find(std::string_view key) const noexcept;

    /// Compact serialization (valid JSON, UTF-8 passed through, control characters escaped).
    [[nodiscard]] std::string dump() const;
};

/// Член объекта JSON. Поля названы first/second, как у пары.
struct Member {
    std::string first;
    Value second;

    Member() = default;
    Member(std::string key, Value value) : first(std::move(key)), second(std::move(value)) {}
};

struct ParseResult {
    std::optional<Value> value;
    std::string error;       // empty on success
    size_t errorOffset = 0;
};

ParseResult parse(std::string_view text);

/// JSON string literal with quotes.
std::string quote(std::string_view s);

}   // namespace util::json
