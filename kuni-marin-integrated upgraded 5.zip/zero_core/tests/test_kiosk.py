import configparser
import contextlib
import io
import os
import re
import shutil
import stat
import subprocess
import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path

from zerocore import kiosk
from zerocore.cli import main
from zerocore.kernel.errors import ZeroCoreError

PY, ZPY = "/usr/bin/python3", "/home/marinka/zero_core/zerocore.py"


def make_stubs(directory, names, log=None, fail_curl_times=0):
    """Заглушки команд: записывают вызовы в журнал и ничего не делают."""
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    for name in names:
        body = '#!/bin/sh\necho "$(basename "$0") $*" >> "$ZC_LOG"\nexit 0\n'
        if name == "curl":
            body = ('#!/bin/sh\necho "curl $*" >> "$ZC_LOG"\nn=$(cat "$ZC_CURL_COUNT" 2>/dev/null || echo 0)\n'
                    'n=$((n + 1))\necho $n > "$ZC_CURL_COUNT"\n[ "$n" -gt "${ZC_CURL_FAILS:-0}" ]\n')
        if name == "sleep":
            body = "#!/bin/sh\nexit 0\n"
        p = d / name
        p.write_text(body)
        p.chmod(p.stat().st_mode | stat.S_IEXEC)
    return d


def heredocs(text):
    """Содержимое heredoc-блоков скрипта: путь -> текст."""
    out = {}
    for m in re.finditer(r"cat > (\S+) <<'ZC_EOF'\n(.*?)\nZC_EOF\n", text, re.S):
        out[m.group(1).strip('"')] = m.group(2)
    return out


class GeneratorTests(unittest.TestCase):
    def script(self, **kw):
        args = dict(user="marinka", user_home="/home/marinka", zerocore_home="/home/marinka/zero_core_home", zerocore_py=ZPY, python=PY, port=8767, browser="epiphany", boot=False)
        args.update(kw)
        return kiosk.setup_script(**args)

    def sh_ok(self, text):
        r = subprocess.run(["sh", "-n"], input=text, capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)

    def test_everything_generated_is_valid_shell(self):
        for browser in kiosk.BROWSERS:
            for boot in (False, True):
                text = self.script(browser=browser, boot=boot)
                self.sh_ok(text)
                for name, body in heredocs(text).items():
                    if name.endswith("session.sh"):
                        self.sh_ok(body)
        self.sh_ok(kiosk.session_script("/x", 8767, "firefox"))

    def test_heredocs_are_balanced_and_contain_every_file(self):
        text = self.script()
        self.assertEqual(text.count("\nZC_EOF\n"), len(heredocs(text)))
        names = " ".join(heredocs(text))
        for part in ("Xwrapper.config", "session.sh", "openbox-rc.xml", "zerocore-panel.service", "zerocore-kiosk.service"):
            self.assertIn(part, names)

    def test_packages_depend_on_the_browser_choice(self):
        base = kiosk.BASE_PACKAGES
        for browser, pkg in (("epiphany", "epiphany-browser"), ("chromium", "chromium-browser"), ("firefox", "firefox")):
            line = next(l for l in self.script(browser=browser).splitlines() if l.startswith("apt-get install"))
            self.assertTrue(all(p in line for p in base) and pkg in line, line)
        line = next(l for l in self.script(browser="existing").splitlines() if l.startswith("apt-get install"))
        self.assertNotIn("browser", line)
        self.assertNotIn("firefox", line)

    def test_enable_on_boot_only_when_asked(self):
        self.assertNotIn("systemctl enable zerocore-panel zerocore-kiosk\n", self.script(boot=False))
        self.assertIn("systemctl enable zerocore-panel zerocore-kiosk\n", self.script(boot=True))

    def test_units_and_openbox_config_are_well_formed(self):
        files = heredocs(self.script())
        rc = ET.fromstring(next(v for k, v in files.items() if k.endswith("openbox-rc.xml")))
        self.assertTrue(rc.tag.endswith("openbox_config"))
        self.assertIn("<fullscreen>yes</fullscreen>", ET.tostring(rc, encoding="unicode") if False else next(v for k, v in files.items() if k.endswith("openbox-rc.xml")))
        for name in ("zerocore-panel.service", "zerocore-kiosk.service"):
            cp = configparser.ConfigParser(interpolation=None, strict=False)
            cp.optionxform = str
            cp.read_string(next(v for k, v in files.items() if k.endswith(name)))
            self.assertEqual(set(cp.sections()), {"Unit", "Service", "Install"})
            self.assertEqual(cp["Service"]["User"], "marinka")
        panel = configparser.ConfigParser(interpolation=None)
        panel.read_string(next(v for k, v in files.items() if k.endswith("zerocore-panel.service")))
        self.assertIn("panel --host 127.0.0.1 --port 8767", panel["Service"]["ExecStart"])   # панель только для самого ноутбука
        kiosk_unit = next(v for k, v in files.items() if k.endswith("zerocore-kiosk.service"))
        for needed in ("PAMName=login", "TTYPath=/dev/tty7", "ExecStart=/usr/bin/xinit /home/marinka/.zerocore-kiosk/session.sh -- :0 vt7", "ExecStartPost=+/usr/bin/chvt 7", "Wants=zerocore-panel.service"):
            self.assertIn(needed, kiosk_unit)

    def test_paths_with_spaces_are_quoted_for_systemd_and_shell(self):
        text = self.script(python="/opt/my python/bin/python3", zerocore_home="/home/marinka/zc home", user_home="/home/marinka")
        panel = next(v for k, v in heredocs(text).items() if k.endswith("zerocore-panel.service"))
        self.assertIn('ExecStart="/opt/my python/bin/python3"', panel)
        self.assertIn('--home "/home/marinka/zc home"', panel)
        self.assertEqual(kiosk.sd_quote("/plain/path-1.2"), "/plain/path-1.2")
        self.assertEqual(kiosk.sd_quote('a "b" c'), '"a \\"b\\" c"')

    def test_no_token_is_ever_written_into_generated_files(self):
        text = self.script()
        self.assertNotIn("SECRET", text)
        session = next(v for k, v in heredocs(text).items() if k.endswith("session.sh"))
        self.assertIn('TOKEN=$(cat "$ZHOME/panel_token"', session)   # токен читается из файла в момент запуска

    def test_invalid_input_is_rejected(self):
        for bad in ("Bad User", "", "root;rm", "a" * 40):
            with self.assertRaises(ZeroCoreError):
                self.script(user=bad)
        with self.assertRaises(ZeroCoreError):
            self.script(browser="netscape")
        with self.assertRaises(ZeroCoreError):
            kiosk.session_script("/x", 8767, "netscape")


class SessionScriptRunTests(unittest.TestCase):
    """Скрипт сессии выполняется по-настоящему: на заглушках браузера и curl видно, с какими аргументами всё запускается."""

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="zc_kiosk_"))
        self.home = self.tmp / "home"
        (self.home / ".zerocore-kiosk").mkdir(parents=True)
        self.zhome = self.tmp / "zc home 'x'"   # с пробелом и кавычкой: проверка экранирования в настоящем shell
        self.zhome.mkdir()
        (self.zhome / "panel_token").write_text("SECRET-TOKEN\n")
        self.log = self.tmp / "log.txt"

    def run_session(self, browser, installed, fails=0, port=8767):
        stubs = make_stubs(self.tmp / "bin", ["curl", "openbox", "xset", "xsetroot", "sleep"] + list(installed))
        for real in ("cat", "basename"):   # настоящие команды, нужные сессии (читает токен) и заглушкам (имя в журнал)
            if not (stubs / real).exists():
                (stubs / real).symlink_to(shutil.which(real))
        script = self.home / ".zerocore-kiosk" / "session.sh"
        script.write_text(kiosk.session_script(self.zhome, port, browser))
        # PATH только из заглушек: настоящие браузеры машины (на серверах CI они есть в /usr/bin) не должны влиять на результат
        env = {"PATH": str(stubs), "HOME": str(self.home), "ZC_LOG": str(self.log), "ZC_CURL_COUNT": str(self.tmp / "count"), "ZC_CURL_FAILS": str(fails)}
        r = subprocess.run(["/bin/sh", str(script)], env=env, capture_output=True, text=True, timeout=30)
        calls = self.log.read_text().splitlines() if self.log.exists() else []
        return r, calls

    def test_epiphany_gets_application_mode_profile_and_the_token_url(self):
        r, calls = self.run_session("epiphany", ["epiphany-browser"])
        self.assertEqual(r.returncode, 0, r.stderr)
        line = next(c for c in calls if c.startswith("epiphany-browser"))
        self.assertIn("--application-mode", line)
        self.assertIn(f"--profile={self.home}/.zerocore-kiosk/epiphany", line)
        self.assertTrue(line.endswith("http://127.0.0.1:8767/#token=SECRET-TOKEN"), line)

    def test_chromium_kiosk_flags(self):
        r, calls = self.run_session("chromium", ["chromium-browser"])
        line = next(c for c in calls if c.startswith("chromium-browser"))
        for flag in ("--kiosk", "--no-first-run", "--noerrdialogs", f"--user-data-dir={self.home}/.zerocore-kiosk/chromium", "#token=SECRET-TOKEN"):
            self.assertIn(flag, line)

    def test_firefox_kiosk(self):
        r, calls = self.run_session("firefox", ["firefox"])
        self.assertTrue(any(c.startswith("firefox --kiosk http://127.0.0.1:8767/#token=SECRET-TOKEN") for c in calls), calls)

    def test_falls_back_to_whatever_browser_is_installed(self):
        r, calls = self.run_session("chromium", ["firefox"])   # хромиума нет, есть firefox
        self.assertTrue(any(c.startswith("firefox --kiosk") for c in calls), calls)

    def test_without_any_browser_it_reports_and_fails(self):
        r, calls = self.run_session("existing", [])
        self.assertEqual(r.returncode, 1)
        self.assertIn("браузер не найден", r.stderr)

    def test_waits_for_the_panel_to_answer(self):
        r, calls = self.run_session("firefox", ["firefox"], fails=3)
        self.assertEqual(len([c for c in calls if c.startswith("curl")]), 4, "три отказа и один успех")
        self.assertTrue(any(c.startswith("firefox") for c in calls))

    def test_screen_blanking_is_disabled_and_the_cursor_shape_is_set(self):
        r, calls = self.run_session("firefox", ["firefox"])
        self.assertTrue(any(c.startswith("xset s off -dpms s noblank") for c in calls))
        self.assertTrue(any(c.startswith("xsetroot -cursor_name left_ptr") for c in calls), "курсор мыши будет виден")
        self.assertTrue(any(c.startswith("openbox --config-file") for c in calls))

    def test_the_port_is_taken_from_the_settings(self):
        r, calls = self.run_session("firefox", ["firefox"], port=9123)
        self.assertTrue(any("http://127.0.0.1:9123/#token=" in c for c in calls), calls)


class SetupScriptRunTests(unittest.TestCase):
    """Скрипт установки выполняется на заглушках apt-get, systemctl и др.: проверяется, что и куда он пишет и что вызывает."""

    def run_setup(self, browser="epiphany", boot=False):
        tmp = Path(tempfile.mkdtemp(prefix="zc_setup_"))
        self.tmp, self.log = tmp, tmp / "log.txt"
        user_home = tmp / "home" / "marinka"
        user_home.mkdir(parents=True)
        stubs = make_stubs(tmp / "bin", ["apt-get", "usermod", "systemctl", "id", "chown"])
        script = tmp / "setup.sh"
        script.write_text(kiosk.setup_script("marinka", str(user_home), "/home/marinka/zero_core_home", ZPY, PY, 8767, browser, boot))
        env = {"PATH": f"{stubs}:/usr/bin:/bin", "ZC_ROOT": str(tmp / "root"), "ZC_LOG": str(self.log)}
        r = subprocess.run(["sh", str(script)], env=env, capture_output=True, text=True, timeout=30)
        self.user_home = user_home
        return r, self.log.read_text().splitlines()

    def test_writes_all_files_and_calls_the_system_tools(self):
        r, calls = self.run_setup()
        self.assertEqual(r.returncode, 0, r.stderr)
        root = self.tmp / "root"
        self.assertEqual((root / "etc/X11/Xwrapper.config").read_text(), "allowed_users=anybody\nneeds_root_rights=yes\n")
        for name in ("zerocore-panel.service", "zerocore-kiosk.service"):
            self.assertTrue((root / "etc/systemd/system" / name).is_file())
        kdir = self.user_home / ".zerocore-kiosk"
        self.assertTrue((kdir / "session.sh").stat().st_mode & stat.S_IXUSR, "сессия исполняемая")
        self.assertTrue((kdir / "openbox-rc.xml").is_file())
        ET.parse(kdir / "openbox-rc.xml")
        install = next(c for c in calls if c.startswith("apt-get install"))
        for pkg in ("xserver-xorg", "openbox", "xinit", "epiphany-browser", "curl"):
            self.assertIn(pkg, install)
        self.assertTrue(any(c.startswith("usermod -aG video,input marinka") for c in calls))
        self.assertTrue(any(c.startswith("chown -R marinka:marinka") for c in calls))
        self.assertIn("systemctl daemon-reload", calls)
        self.assertFalse(any(c.startswith("systemctl enable") for c in calls))
        self.assertIn("sudo systemctl start zerocore-kiosk", r.stdout)

    def test_boot_flag_enables_both_services(self):
        r, calls = self.run_setup(boot=True)
        self.assertIn("systemctl enable zerocore-panel zerocore-kiosk", calls)

    def test_installed_session_script_is_the_valid_one(self):
        r, calls = self.run_setup(browser="firefox")
        body = (self.user_home / ".zerocore-kiosk" / "session.sh").read_text()
        self.assertIn("PREFERRED=firefox", body)
        self.assertEqual(subprocess.run(["sh", "-n"], input=body, text=True, capture_output=True).returncode, 0)

    def test_refuses_to_run_without_root(self):
        tmp = Path(tempfile.mkdtemp(prefix="zc_noroot_"))
        stubs = make_stubs(tmp / "bin", ["apt-get"])
        (stubs / "id").write_text('#!/bin/sh\nif [ "$1" = "-u" ]; then echo 1000; else exit 0; fi\n')   # обычный пользователь
        (stubs / "id").chmod(0o755)
        script = tmp / "setup.sh"
        script.write_text(kiosk.setup_script("marinka", str(tmp / "h"), "/z", ZPY, PY))
        r = subprocess.run(["sh", str(script)], env={"PATH": f"{stubs}:/usr/bin:/bin", "ZC_LOG": str(tmp / "l")}, capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertIn("sudo sh", r.stderr)
        self.assertFalse((tmp / "l").exists(), "apt-get не вызывался")

    def test_stops_if_the_user_does_not_exist(self):
        tmp = Path(tempfile.mkdtemp(prefix="zc_nouser_"))
        stubs = make_stubs(tmp / "bin", ["apt-get"])
        (stubs / "id").write_text("#!/bin/sh\nexit 1\n")
        (stubs / "id").chmod(0o755)
        script = tmp / "setup.sh"
        script.write_text(kiosk.setup_script("marinka", str(tmp / "h"), "/z", ZPY, PY))
        r = subprocess.run(["sh", str(script)], env={"PATH": f"{stubs}:/usr/bin:/bin", "ZC_ROOT": str(tmp / "r"), "ZC_LOG": str(tmp / "l")}, capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertIn("Нет пользователя", r.stderr)
        self.assertFalse((tmp / "r" / "etc").exists(), "ничего не записано")


class KioskCliTests(unittest.TestCase):
    def test_cli_writes_the_script_and_prints_next_steps(self):
        tmp = Path(tempfile.mkdtemp(prefix="zc_clik_"))
        out = tmp / "setup.sh"
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            code = main(["--home", str(tmp / "h"), "kiosk", "setup", "--user", "marinka", "--browser", "chromium", "--boot", "--out", str(out)])
        self.assertEqual(code, 0)
        text = out.read_text()
        self.assertIn("chromium-browser", text)
        self.assertIn("systemctl enable zerocore-panel zerocore-kiosk", text)
        self.assertEqual(subprocess.run(["sh", "-n", str(out)], capture_output=True).returncode, 0)
        self.assertIn(f"sudo sh {out}", buf.getvalue())
        self.assertIn("systemctl start zerocore-kiosk", buf.getvalue())

    def test_cli_rejects_a_bad_user(self):
        tmp = Path(tempfile.mkdtemp(prefix="zc_clik2_"))
        buf = io.StringIO()
        with contextlib.redirect_stderr(buf):
            code = main(["--home", str(tmp / "h"), "kiosk", "setup", "--user", "Bad User", "--out", str(tmp / "x.sh")])
        self.assertEqual(code, 1)
        self.assertFalse((tmp / "x.sh").exists())


if __name__ == "__main__":
    unittest.main()
