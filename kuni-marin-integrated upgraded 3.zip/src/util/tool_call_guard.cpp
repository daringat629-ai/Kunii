#include "tool_call_guard.h"

#include <string>

namespace util {

std::string ToolCallGuard::normalizeArguments(const std::string& arguments) {
    std::string out;
    out.reserve(arguments.size());
    bool inString = false;
    bool escape = false;
    for (char c : arguments) {
        if (inString) {
            out += c;
            if (escape) {
                escape = false;
            } else if (c == '\\') {
                escape = true;
            } else if (c == '"') {
                inString = false;
            }
            continue;
        }
        if (c == '"') {
            inString = true;
            out += c;
            continue;
        }
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            continue;
        }
        out += c;
    }
    return out;
}

void ToolCallGuard::reset() {
    mExecuted = 0;
    mRefused = 0;
    mLastSignature.clear();
    mConsecutive = 0;
    mPerToolExecuted.clear();
}

ToolCallGuard::Decision ToolCallGuard::refuse(Verdict verdict, std::string message) {
    ++mRefused;
    Decision d;
    d.verdict = verdict;
    d.message = std::move(message);
    d.abortTurn = mLimits.abortAfterRefusals != 0 && mRefused >= mLimits.abortAfterRefusals;
    return d;
}

ToolCallGuard::Decision ToolCallGuard::check(const std::string& toolName, const std::string& arguments) {
    // the signature includes refused attempts: a stubborn LLM keeps being refused instead of "resetting" the streak
    std::string signature = toolName;
    signature += '\x1f';
    signature += normalizeArguments(arguments);
    if (signature == mLastSignature) {
        ++mConsecutive;
    } else {
        mLastSignature = std::move(signature);
        mConsecutive = 1;
    }

    if (mLimits.maxConsecutiveIdentical != 0 && mConsecutive > mLimits.maxConsecutiveIdentical) {
        return refuse(
            Verdict::REFUSE_IDENTICAL,
            "Refused: you have called `" + toolName + "` with exactly the same arguments " +
                std::to_string(mConsecutive) +
                " times in a row. The result will not change. Do something else (a different tool or different "
                "arguments), or finish the turn (pause).");
    }

    if (mLimits.maxCallsPerTurn != 0 && mExecuted >= mLimits.maxCallsPerTurn) {
        return refuse(
            Verdict::REFUSE_BUDGET,
            "Refused: the limit of " + std::to_string(mLimits.maxCallsPerTurn) +
                " tool calls per turn is reached. Wrap up: send your final message if needed and finish the turn "
                "(pause).");
    }

    if (auto limit = mLimits.perTool.find(toolName); limit != mLimits.perTool.end() && limit->second != 0) {
        if (mPerToolExecuted[toolName] >= limit->second) {
            return refuse(
                Verdict::REFUSE_TOOL_BUDGET,
                "Refused: `" + toolName + "` was already called " + std::to_string(limit->second) +
                    " times in this turn, which is the limit. Use another approach, or finish the turn (pause).");
        }
    }

    ++mExecuted;
    ++mPerToolExecuted[toolName];
    return {};
}

}   // namespace util
