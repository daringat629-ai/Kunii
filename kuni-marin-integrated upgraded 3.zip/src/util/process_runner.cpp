#include "process_runner.h"

#include <string>

#ifndef _WIN32
#include <fcntl.h>
#include <poll.h>
#include <signal.h>
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cstdlib>
#include <cstring>
#include <thread>
#include <vector>

extern char** environ;
#endif

namespace util::process {

void trimIncompleteUtf8(std::string& s) {
    // find the start of the last character
    size_t i = s.size();
    size_t back = 0;
    while (i > 0 && back < 4) {
        --i;
        ++back;
        const auto c = static_cast<unsigned char>(s[i]);
        if ((c & 0xC0) == 0x80) {
            continue;   // continuation byte
        }
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) {
            need = 2;
        } else if ((c & 0xF0) == 0xE0) {
            need = 3;
        } else if ((c & 0xF8) == 0xF0) {
            need = 4;
        }
        if (need > back) {
            s.resize(i);   // sequence is cut off
        }
        return;
    }
}

std::string formatForLlm(const Result& r) {
    if (r.spawnFailed) {
        return "error: failed to start the shell: " + r.error;
    }
    std::string s = r.output;
    if (r.truncated) {
        s += "\n[output truncated]";
    }
    if (r.timedOut) {
        s += "\n[timed out after " + std::to_string(r.timeoutUsed.count() / 1000) + " s; the process was killed]";
    } else if (r.exitCode != 0) {
        s += "\n[exit code " + std::to_string(r.exitCode) + "]";
    }
    if (s.empty()) {
        return "(no output)";
    }
    return s;
}

#ifdef _WIN32

Result run(const Options& options) {
    Result r;
    r.spawnFailed = true;
    r.error = "the shell tool is not supported on this platform";
    r.timeoutUsed = options.timeout;
    return r;
}

#else

namespace {

void drain(int fd, std::string& out, size_t cap, bool& truncated, bool& eof) {
    char buf[4096];
    for (;;) {
        const ssize_t n = ::read(fd, buf, sizeof buf);
        if (n > 0) {
            const size_t room = out.size() < cap ? cap - out.size() : 0;
            if (room >= static_cast<size_t>(n)) {
                out.append(buf, static_cast<size_t>(n));
            } else {
                out.append(buf, room);
                truncated = true;
            }
            continue;
        }
        if (n == 0) {
            eof = true;
            return;
        }
        if (errno == EINTR) {
            continue;
        }
        return;   // EAGAIN: nothing more for now
    }
}

/// An unlinked temporary file containing `data`, positioned at the start. -1 on failure.
int makeStdinFile(const std::string& data) {
    const char* dir = std::getenv("TMPDIR");
    std::string tmpl = std::string(dir != nullptr && *dir != '\0' ? dir : "/tmp") + "/kuni-stdin-XXXXXX";
    const int fd = ::mkstemp(tmpl.data());
    if (fd < 0) {
        return -1;
    }
    ::unlink(tmpl.c_str());
    size_t off = 0;
    while (off < data.size()) {
        const ssize_t n = ::write(fd, data.data() + off, data.size() - off);
        if (n < 0 && errno == EINTR) {
            continue;
        }
        if (n <= 0) {
            ::close(fd);
            return -1;
        }
        off += static_cast<size_t>(n);
    }
    ::lseek(fd, 0, SEEK_SET);
    ::fcntl(fd, F_SETFD, FD_CLOEXEC);
    return fd;
}

int exitCodeFromStatus(int status) {
    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    }
    if (WIFSIGNALED(status)) {
        return 128 + WTERMSIG(status);
    }
    return -1;
}

}   // namespace

Result run(const Options& options) {
    using clock = std::chrono::steady_clock;
    Result result;
    result.timeoutUsed = options.timeout;

    int pipefd[2];
    if (::pipe(pipefd) != 0) {
        result.spawnFailed = true;
        result.error = std::string("pipe: ") + std::strerror(errno);
        return result;
    }
    ::fcntl(pipefd[0], F_SETFD, FD_CLOEXEC);
    ::fcntl(pipefd[1], F_SETFD, FD_CLOEXEC);
    const int devnull = ::open("/dev/null", O_RDONLY | O_CLOEXEC);
    int stdinFd = devnull;
    int stdinFile = -1;
    if (!options.stdinData.empty()) {
        stdinFile = makeStdinFile(options.stdinData);
        if (stdinFile < 0) {
            ::close(pipefd[0]);
            ::close(pipefd[1]);
            if (devnull >= 0) {
                ::close(devnull);
            }
            result.spawnFailed = true;
            result.error = "could not prepare stdin for the process";
            return result;
        }
        stdinFd = stdinFile;
    }

    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, stdinFd, 0);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], 1);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], 2);
    posix_spawnattr_t attr;
    posix_spawnattr_init(&attr);
    posix_spawnattr_setpgroup(&attr, 0);   // the child leads its own group, so we can kill all of it
    posix_spawnattr_setflags(&attr, POSIX_SPAWN_SETPGROUP);

    std::vector<std::string> args;
    if (!options.argv.empty()) {
        args = options.argv;
    } else if (!options.dockerContainer.empty()) {
        args = { "docker", "exec", "-i", options.dockerContainer, "bash", "-c", options.command };
    } else {
        args = { "bash", "-c", options.command };
    }
    if (!options.cwd.empty()) {
        // portable chdir before exec (posix_spawn_file_actions_addchdir_np is not available everywhere, e.g. musl)
        std::vector<std::string> wrapped = { "sh", "-c", "cd \"$0\" && exec \"$@\"", options.cwd };
        wrapped.insert(wrapped.end(), args.begin(), args.end());
        args = std::move(wrapped);
    }
    std::vector<char*> argv;
    for (auto& a : args) {
        argv.push_back(a.data());
    }
    argv.push_back(nullptr);

    std::vector<std::string> envStorage;
    std::vector<char*> envp;
    char** envForChild = environ;
    if (!options.env.empty()) {
        for (char** e = environ; e != nullptr && *e != nullptr; ++e) {
            const std::string entry(*e);
            const std::string key = entry.substr(0, entry.find('='));
            bool overridden = false;
            for (const auto& kv : options.env) {
                if (kv.first == key) {
                    overridden = true;
                    break;
                }
            }
            if (!overridden) {
                envStorage.push_back(entry);
            }
        }
        for (const auto& kv : options.env) {
            envStorage.push_back(kv.first + "=" + kv.second);
        }
        for (auto& e : envStorage) {
            envp.push_back(e.data());
        }
        envp.push_back(nullptr);
        envForChild = envp.data();
    }

    pid_t pid = 0;
    const int spawnRc = posix_spawnp(&pid, argv[0], &actions, &attr, argv.data(), envForChild);
    posix_spawn_file_actions_destroy(&actions);
    posix_spawnattr_destroy(&attr);
    ::close(pipefd[1]);
    if (devnull >= 0) {
        ::close(devnull);
    }
    if (stdinFile >= 0) {
        ::close(stdinFile);
    }
    if (spawnRc != 0) {
        ::close(pipefd[0]);
        result.spawnFailed = true;
        result.error = std::string(argv[0]) + ": " + std::strerror(spawnRc);
        return result;
    }

    ::fcntl(pipefd[0], F_SETFL, ::fcntl(pipefd[0], F_GETFL) | O_NONBLOCK);
    const auto deadline = clock::now() + options.timeout;
    bool eof = false;
    bool exited = false;
    int status = 0;

    auto tryReap = [&] {
        if (!exited && ::waitpid(pid, &status, WNOHANG) == pid) {
            exited = true;
        }
    };

    for (;;) {
        const auto now = clock::now();
        if (now >= deadline) {
            result.timedOut = true;
            break;
        }
        const auto remaining = std::chrono::duration_cast<std::chrono::milliseconds>(deadline - now);
        pollfd pfd { .fd = pipefd[0], .events = POLLIN, .revents = 0 };
        const int timeoutMs = static_cast<int>(std::max<long long>(1, std::min<long long>(50, remaining.count())));
        if (!eof && ::poll(&pfd, 1, timeoutMs) > 0) {
            drain(pipefd[0], result.output, options.maxOutputBytes, result.truncated, eof);
        } else if (eof) {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        tryReap();
        if (exited) {
            // the process is gone; grab what is still buffered. Background jobs may keep the pipe open, ignore them.
            drain(pipefd[0], result.output, options.maxOutputBytes, result.truncated, eof);
            break;
        }
    }

    if (result.timedOut) {
        ::killpg(pid, SIGTERM);
        const auto graceEnd = clock::now() + options.killGrace;
        while (!exited && clock::now() < graceEnd) {
            drain(pipefd[0], result.output, options.maxOutputBytes, result.truncated, eof);
            tryReap();
            if (!exited) {
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
            }
        }
        if (!exited) {
            ::killpg(pid, SIGKILL);
            ::waitpid(pid, &status, 0);
            exited = true;
        } else {
            ::killpg(pid, SIGKILL);   // stragglers of the group, if any
        }
        drain(pipefd[0], result.output, options.maxOutputBytes, result.truncated, eof);
    }

    ::close(pipefd[0]);
    result.exitCode = exitCodeFromStatus(status);
    if (result.truncated) {
        trimIncompleteUtf8(result.output);
    }
    return result;
}

#endif

Result runBash(const Options& options) {
    return run(options);
}

}   // namespace util::process
