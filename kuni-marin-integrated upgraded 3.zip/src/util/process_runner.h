#pragma once

#include <chrono>
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

namespace util::process {

struct Options {
    /// Executed as `bash -c <command>`.
    std::string command;
    /// If not empty: `docker exec -i <container> bash -c <command>`.
    std::string dockerContainer;
    /// If not empty, this program is executed directly (no shell); `command` and `dockerContainer` are ignored.
    std::vector<std::string> argv;
    /// Working directory; empty = inherit.
    std::string cwd;
    /// Extra environment variables, added to (and overriding) the inherited environment.
    std::vector<std::pair<std::string, std::string>> env;
    /// Data given to the process on stdin (through an unlinked temporary file, so a process that never reads stdin
    /// cannot block us or cause SIGPIPE). Empty = /dev/null.
    std::string stdinData;
    std::chrono::milliseconds timeout { 60000 };
    /// After the timeout the process group gets SIGTERM; after this grace period, SIGKILL.
    std::chrono::milliseconds killGrace { 2000 };
    size_t maxOutputBytes = 8000;
};

struct Result {
    std::string output;   // stdout and stderr merged
    int exitCode = -1;    // 128+N if killed by signal N
    bool timedOut = false;
    bool truncated = false;
    bool spawnFailed = false;
    std::string error;
    std::chrono::milliseconds timeoutUsed { 0 };
};

/**
 * @brief Runs a bash command and waits for it. Blocking: call it from a worker thread, never from the UI thread.
 * @details
 * - stdin is /dev/null;
 * - the child leads its own process group; on timeout the whole group is killed (the previous `timeout 60 bash -c`
 *   killed bash only, leaving its children running);
 * - background jobs (`cmd &`) do not block the call once the main process exits;
 * - the output is capped, a partial trailing UTF-8 sequence is dropped.
 * Not supported on Windows (returns spawnFailed).
 */
Result run(const Options& options);

/// The historical name: the same as run().
Result runBash(const Options& options);

/// Drops an incomplete UTF-8 sequence at the end of `s` (after cutting at a byte limit).
void trimIncompleteUtf8(std::string& s);

/// Text for the LLM: the output plus short notes about timeout, truncation and non-zero exit code.
std::string formatForLlm(const Result& result);

}   // namespace util::process
