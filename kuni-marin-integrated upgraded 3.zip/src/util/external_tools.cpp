#include "external_tools.h"

#include "json_lite.h"

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>

namespace util::external {

namespace {

constexpr size_t MAX_PAYLOAD = 65536;

bool isIdentStart(char c) { return (c >= 'a' && c <= 'z'); }
bool isIdentChar(char c) { return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_'; }

bool isParamName(std::string_view name) {
    if (name.empty() || name.size() > 64 || !isIdentStart(name[0])) {
        return false;
    }
    return std::all_of(name.begin(), name.end(), isIdentChar);
}

bool isEnvName(std::string_view s) {
    if (s.empty() || s.size() > 128) {
        return false;
    }
    const auto first = static_cast<unsigned char>(s[0]);
    if (!(std::isalpha(first) || first == '_')) {
        return false;
    }
    return std::all_of(s.begin(), s.end(), [](char c) {
        const auto u = static_cast<unsigned char>(c);
        return std::isalnum(u) || u == '_';
    });
}

bool isParamType(std::string_view t) {
    return t == "string" || t == "integer" || t == "number" || t == "boolean";
}

std::string ctx(size_t index, const std::string& name) {
    return "tools[" + std::to_string(index) + "]" + (name.empty() ? "" : " (" + name + ")");
}

/// Returns an empty string if the entry is valid and fills `out`; otherwise the reason.
std::string parseTool(const json::Value& v, Tool& out) {
    if (!v.isObject()) {
        return "must be an object";
    }
    auto str = [&](const char* key) -> const std::string* {
        const auto* f = v.find(key);
        return f && f->isString() ? &f->string : nullptr;
    };
    const auto* name = str("name");
    if (!name || !isValidToolName(*name)) {
        return "name: lowercase letters, digits and _, 2-64 characters, starts with a letter";
    }
    out.name = *name;
    if (const auto* mod = str("module")) {
        out.module = *mod;
    }
    const auto* desc = str("description");
    if (!desc || desc->empty() || desc->size() > 2000) {
        return "description: a non-empty string up to 2000 characters";
    }
    out.description = *desc;

    if (const auto* params = v.find("parameters")) {
        if (!params->isObject()) {
            return "parameters: must be an object";
        }
        if (const auto* props = params->find("properties")) {
            if (!props->isObject()) {
                return "parameters.properties: must be an object";
            }
            if (props->object.size() > 32) {
                return "parameters.properties: at most 32 parameters";
            }
            for (const auto& kv : props->object) {
                if (!isParamName(kv.first)) {
                    return "parameter name \"" + kv.first + "\" is invalid";
                }
                if (!kv.second.isObject()) {
                    return "parameter \"" + kv.first + "\" must be an object";
                }
                const auto* type = kv.second.find("type");
                if (!type || !type->isString() || !isParamType(type->string)) {
                    return "parameter \"" + kv.first + "\": type must be string, integer, number or boolean";
                }
                Param p;
                p.name = kv.first;
                p.type = type->string;
                if (const auto* d = kv.second.find("description"); d && d->isString()) {
                    p.description = d->string.substr(0, 1000);
                }
                out.params.push_back(std::move(p));
            }
        }
        if (const auto* req = params->find("required")) {
            if (!req->isArray()) {
                return "parameters.required: must be an array";
            }
            for (const auto& r : req->array) {
                if (!r.isString() || out.param(r.string) == nullptr) {
                    return "parameters.required: unknown parameter";
                }
                out.required.push_back(r.string);
            }
        }
    }

    const auto* cmd = v.find("command");
    if (!cmd || !cmd->isArray() || cmd->array.empty() || cmd->array.size() > 64) {
        return "command: a non-empty array of up to 64 strings";
    }
    for (const auto& a : cmd->array) {
        if (!a.isString()) {
            return "command: all elements must be strings";
        }
        out.argv.push_back(a.string);
    }
    if (out.argv[0].empty()) {
        return "command: the program name is empty";
    }
    if (const auto* cwd = v.find("cwd")) {
        if (!cwd->isString()) {
            return "cwd: must be a string";
        }
        out.cwd = cwd->string;
    }
    if (const auto* env = v.find("env")) {
        if (!env->isObject() || env->object.size() > 64) {
            return "env: an object with up to 64 variables";
        }
        for (const auto& kv : env->object) {
            if (!isEnvName(kv.first) || !kv.second.isString()) {
                return "env: invalid variable \"" + kv.first + "\"";
            }
            out.env.emplace_back(kv.first, kv.second.string);
        }
    }
    if (const auto* t = v.find("timeout_seconds")) {
        if (!t->isNumber() || !t->integer || t->number < 1 || t->number > 300) {
            return "timeout_seconds: an integer from 1 to 300";
        }
        out.timeoutSeconds = static_cast<int>(t->number);
    }
    if (const auto* m = v.find("max_output_bytes")) {
        if (!m->isNumber() || !m->integer || m->number < 100 || m->number > 65536) {
            return "max_output_bytes: an integer from 100 to 65536";
        }
        out.maxOutputBytes = static_cast<size_t>(m->number);
    }
    return {};
}

bool parseWholeDouble(const std::string& s, double& out) {
    if (s.empty()) {
        return false;
    }
    errno = 0;
    char* end = nullptr;
    const double v = std::strtod(s.c_str(), &end);
    if (errno != 0 || end == s.c_str() || *end != '\0' || !std::isfinite(v)) {
        return false;
    }
    out = v;
    return true;
}

/// Converts the LLM's value to the declared type; returns an error text or an empty string.
std::string coerce(const Param& p, const json::Value& in, json::Value& out) {
    out = json::Value {};
    if (p.type == "string") {
        out.type = json::Value::Type::STRING;
        if (in.isString()) {
            out.string = in.string;
        } else if (in.isNumber() || in.isBool()) {
            out.string = in.dump();
        } else {
            return "argument \"" + p.name + "\" must be a string";
        }
        return {};
    }
    if (p.type == "boolean") {
        out.type = json::Value::Type::BOOL;
        if (in.isBool()) {
            out.boolean = in.boolean;
        } else if (in.isString() && (in.string == "true" || in.string == "false")) {
            out.boolean = in.string == "true";
        } else {
            return "argument \"" + p.name + "\" must be a boolean";
        }
        return {};
    }
    double d = 0;
    if (in.isNumber()) {
        d = in.number;
    } else if (in.isString() && parseWholeDouble(in.string, d)) {
        // "3" -> 3
    } else {
        return "argument \"" + p.name + "\" must be a number";
    }
    out.type = json::Value::Type::NUMBER;
    out.number = d;
    if (p.type == "integer") {
        // some models print integers in scientific notation (7.576e+08): integral values are fine
        if (std::floor(d) != d || std::fabs(d) >= 9e15) {
            return "argument \"" + p.name + "\" must be an integer";
        }
        out.integer = true;
    }
    return {};
}

}   // namespace

const Param* Tool::param(std::string_view paramName) const noexcept {
    for (const auto& p : params) {
        if (p.name == paramName) {
            return &p;
        }
    }
    return nullptr;
}

bool isValidToolName(std::string_view name) noexcept {
    if (name.size() < 2 || name.size() > 64 || !isIdentStart(name[0])) {
        return false;
    }
    return std::all_of(name.begin(), name.end(), isIdentChar);
}

Catalog parseCatalog(std::string_view jsonText) {
    Catalog catalog;
    auto parsed = json::parse(jsonText);
    if (!parsed.value) {
        catalog.errors.push_back("catalog is not valid JSON: " + parsed.error + " (offset " + std::to_string(parsed.errorOffset) + ")");
        return catalog;
    }
    const auto& root = *parsed.value;
    if (!root.isObject()) {
        catalog.errors.push_back("catalog must be a JSON object");
        return catalog;
    }
    const auto* version = root.find("version");
    if (!version || !version->isNumber() || version->number != 1) {
        catalog.errors.push_back("unsupported catalog version (expected 1)");
        return catalog;
    }
    const auto* tools = root.find("tools");
    if (!tools || !tools->isArray()) {
        catalog.errors.push_back("catalog has no \"tools\" array");
        return catalog;
    }
    for (size_t i = 0; i < tools->array.size(); ++i) {
        Tool tool;
        const std::string reason = parseTool(tools->array[i], tool);
        if (!reason.empty()) {
            catalog.errors.push_back(ctx(i, tool.name) + ": " + reason);
            continue;
        }
        const bool duplicate = std::any_of(catalog.tools.begin(), catalog.tools.end(), [&](const Tool& t) { return t.name == tool.name; });
        if (duplicate) {
            catalog.errors.push_back(ctx(i, tool.name) + ": duplicate tool name, the first one is used");
            continue;
        }
        catalog.tools.push_back(std::move(tool));
    }
    return catalog;
}

Prepared prepareCall(const Tool& tool, std::string_view argumentsJson) {
    Prepared result;
    json::Value args;
    args.type = json::Value::Type::OBJECT;
    const bool blank = std::all_of(argumentsJson.begin(), argumentsJson.end(), [](char c) { return c == ' ' || c == '\n' || c == '\t' || c == '\r'; });
    if (!blank) {
        auto parsed = json::parse(argumentsJson);
        if (!parsed.value) {
            result.error = "error: the arguments are not valid JSON: " + parsed.error;
            return result;
        }
        if (parsed.value->isNull()) {
            // treated as no arguments
        } else if (!parsed.value->isObject()) {
            result.error = "error: the arguments must be a JSON object";
            return result;
        } else {
            args = std::move(*parsed.value);
        }
    }

    json::Value cleaned;
    cleaned.type = json::Value::Type::OBJECT;
    for (const auto& kv : args.object) {
        const Param* p = tool.param(kv.first);
        if (p == nullptr) {
            result.error = "error: unknown argument \"" + kv.first + "\" for tool " + tool.name;
            return result;
        }
        if (kv.second.isNull()) {
            continue;   // an explicit null means "not provided"
        }
        json::Value converted;
        if (auto problem = coerce(*p, kv.second, converted); !problem.empty()) {
            result.error = "error: " + problem;
            return result;
        }
        cleaned.object.emplace_back(kv.first, std::move(converted));
    }
    for (const auto& name : tool.required) {
        if (cleaned.find(name) == nullptr) {
            result.error = "error: missing required argument \"" + name + "\" for tool " + tool.name;
            return result;
        }
    }

    json::Value payload;
    payload.type = json::Value::Type::OBJECT;
    json::Value toolName;
    toolName.type = json::Value::Type::STRING;
    toolName.string = tool.name;
    payload.object.emplace_back("tool", std::move(toolName));
    payload.object.emplace_back("arguments", std::move(cleaned));
    result.stdinPayload = payload.dump();
    if (result.stdinPayload.size() > MAX_PAYLOAD) {
        result.error = "error: the arguments are too large (limit " + std::to_string(MAX_PAYLOAD) + " bytes)";
        result.stdinPayload.clear();
        return result;
    }
    result.ok = true;
    return result;
}

process::Options makeOptions(const Tool& tool, std::string stdinPayload) {
    process::Options o;
    o.argv = tool.argv;
    o.cwd = tool.cwd;
    o.env = tool.env;
    o.stdinData = std::move(stdinPayload);
    o.timeout = std::chrono::seconds(tool.timeoutSeconds);
    o.maxOutputBytes = tool.maxOutputBytes;
    return o;
}

std::string formatToolResult(const process::Result& r) {
    if (r.spawnFailed) {
        return "error: failed to start the tool: " + r.error;
    }
    std::string out = r.output;
    while (!out.empty() && (out.back() == '\n' || out.back() == '\r' || out.back() == ' ' || out.back() == '\t')) {
        out.pop_back();
    }
    if (r.truncated) {
        out += "\n[output truncated]";
    }
    if (r.timedOut) {
        out += "\n[timed out after " + std::to_string(r.timeoutUsed.count() / 1000) + " s; the process was killed]";
    } else if (r.exitCode != 0) {
        out = "error: the tool exited with code " + std::to_string(r.exitCode) + (out.empty() ? "" : "\n" + out);
    }
    if (out.empty()) {
        return "(no output)";
    }
    return out;
}

}   // namespace util::external
