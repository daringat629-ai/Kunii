#pragma once

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <vector>
#include <utility>

namespace util {

/**
 * @brief Time-limited cache of the contact list. Pure logic, no dependencies.
 * @details
 * Replaces a function-local `static` that was filled once and never refreshed, so contacts added while the bot was
 * running were invisible until restart.
 */
class ContactsCache {
public:
    using Clock = std::chrono::steady_clock;

    explicit ContactsCache(std::chrono::seconds ttl = std::chrono::minutes(5)) : mTtl(ttl) {}

    [[nodiscard]] bool fresh(Clock::time_point now = Clock::now()) const noexcept {
        return mLoaded && now - mFetchedAt < mTtl;
    }

    void update(std::vector<int64_t> ids, Clock::time_point now = Clock::now()) {
        mIds = std::move(ids);
        mFetchedAt = now;
        mLoaded = true;
    }

    [[nodiscard]] bool contains(int64_t id) const noexcept {
        return std::find(mIds.begin(), mIds.end(), id) != mIds.end();
    }

    void invalidate() noexcept { mLoaded = false; }

    [[nodiscard]] size_t size() const noexcept { return mIds.size(); }

private:
    std::chrono::seconds mTtl;
    Clock::time_point mFetchedAt {};
    bool mLoaded = false;
    std::vector<int64_t> mIds;
};

}   // namespace util
