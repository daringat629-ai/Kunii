#include "chat_allowlist.h"

#include <algorithm>
#include <cerrno>
#include <cstdlib>

namespace util {

ChatAllowlist ChatAllowlist::parse(const std::string& csv) {
    ChatAllowlist result;
    std::string token;
    auto flush = [&] {
        if (token.empty()) {
            return;
        }
        errno = 0;
        char* end = nullptr;
        const long long value = std::strtoll(token.c_str(), &end, 10);
        if (errno == 0 && end != nullptr && *end == '\0' && token != "-" && token != "+") {
            result.ids.push_back(static_cast<int64_t>(value));
        } else {
            result.invalid.push_back(token);
        }
        token.clear();
    };
    for (char c : csv) {
        if (c == ',' || c == ';' || c == ' ' || c == '\t' || c == '\n' || c == '\r') {
            flush();
        } else {
            token += c;
        }
    }
    flush();
    return result;
}

bool ChatAllowlist::contains(int64_t chatId) const noexcept {
    return std::find(ids.begin(), ids.end(), chatId) != ids.end();
}

}   // namespace util
