#pragma once

#include <cstddef>
#include <string>
#include <unordered_map>
#include <utility>

namespace util {

/**
 * @brief Per-turn protection against runaway tool-call loops. Pure logic, no dependencies.
 * @details
 * LLMs occasionally get stuck calling the same tool over and over (e.g., #ask with the very same query), or flood a
 * powerful tool (shell) with variations of one command. One ToolCallGuard instance is scoped to a single turn (one
 * AppBase notification). It enforces:
 * - a limit on identical calls in a row (same tool, same arguments, ignoring insignificant JSON whitespace);
 * - a budget of executed calls per turn;
 * - optional per-tool budgets (by default, shell).
 * Refused calls are not executed; the LLM receives an explanation instead. If the LLM keeps insisting, `abortTurn` is
 * set so the caller can end the turn.
 */
class ToolCallGuard {
public:
    struct Limits {
        /// Executed tool calls per turn. 0 = unlimited.
        size_t maxCallsPerTurn = 100;
        /// The (N+1)-th identical call in a row is refused. 0 = unlimited.
        size_t maxConsecutiveIdentical = 3;
        /// Executed calls per tool per turn. A zero value (or a missing entry) = unlimited.
        std::unordered_map<std::string, size_t> perTool = { { "shell", 30 } };
        /// After this many refusals in a turn the guard asks to abort the turn. 0 = never.
        size_t abortAfterRefusals = 3;
    };

    enum class Verdict {
        ALLOW,
        REFUSE_IDENTICAL,
        REFUSE_BUDGET,
        REFUSE_TOOL_BUDGET,
    };

    struct Decision {
        Verdict verdict = Verdict::ALLOW;
        std::string message;      // explanation for the LLM when refused
        bool abortTurn = false;   // the LLM ignores refusals; the caller should end the turn

        [[nodiscard]] bool allowed() const noexcept { return verdict == Verdict::ALLOW; }
    };

    ToolCallGuard() = default;
    explicit ToolCallGuard(Limits limits) : mLimits(std::move(limits)) {}

    void setLimits(Limits limits) { mLimits = std::move(limits); }
    [[nodiscard]] const Limits& limits() const noexcept { return mLimits; }

    /// Registers an attempt to call a tool and decides whether it may be executed.
    Decision check(const std::string& toolName, const std::string& arguments);

    /// Starts a new turn.
    void reset();

    [[nodiscard]] size_t executedCalls() const noexcept { return mExecuted; }
    [[nodiscard]] size_t refusedCalls() const noexcept { return mRefused; }

    /// Removes whitespace outside of JSON string literals so that equal arguments compare equal.
    static std::string normalizeArguments(const std::string& arguments);

private:
    Limits mLimits;
    size_t mExecuted = 0;
    size_t mRefused = 0;
    std::string mLastSignature;
    size_t mConsecutive = 0;
    std::unordered_map<std::string, size_t> mPerToolExecuted;

    Decision refuse(Verdict verdict, std::string message);
};

}   // namespace util
