#include "shutdown_signal.h"

#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstdlib>
#include <iostream>
#include <string_view>
#include <thread>

#ifndef _WIN32
#include <poll.h>
#include <unistd.h>
#endif

namespace {
volatile std::sig_atomic_t gSignalRequested = 0;

extern "C" void onSignal(int) {
    gSignalRequested = 1;
}
}   // namespace

namespace util::shutdown {

void installSignalHandlers() {
    std::signal(SIGINT, onSignal);
    std::signal(SIGTERM, onSignal);
}

bool signalRequested() noexcept {
    return gSignalRequested != 0;
}

void requestForTests() noexcept {
    gSignalRequested = 1;
}

void resetForTests() noexcept {
    gSignalRequested = 0;
}

bool enterToShutdownEnabled() {
    if (const char* v = std::getenv("KUNI_NO_ENTER"); v != nullptr && std::string_view(v) == "1") {
        return false;
    }
#ifdef _WIN32
    return true;
#else
    return isatty(0) != 0;
#endif
}

Reason waitForShutdown(const WaitOptions& options) {
#ifdef _WIN32
    // no poll() on stdin here: keep the original blocking behaviour
    if (options.readEnter) {
        std::cin.get();
        return Reason::ENTER;
    }
    while (!signalRequested()) {
        std::this_thread::sleep_for(options.pollInterval);
    }
    return Reason::SIGNAL;
#else
    bool readEnter = options.readEnter;
    const int timeoutMs = static_cast<int>(options.pollInterval.count());
    for (;;) {
        if (signalRequested()) {
            return Reason::SIGNAL;
        }
        if (!readEnter) {
            std::this_thread::sleep_for(options.pollInterval);
            continue;
        }
        pollfd pfd { .fd = options.stdinFd, .events = POLLIN, .revents = 0 };
        const int r = poll(&pfd, 1, timeoutMs);
        if (r > 0 && (pfd.revents & (POLLIN | POLLHUP | POLLERR | POLLNVAL))) {
            char buf[64];
            const ssize_t n = read(options.stdinFd, buf, sizeof buf);
            if (n > 0) {
                return Reason::ENTER;
            }
            if (n == 0 || (n < 0 && errno != EINTR && errno != EAGAIN)) {
                // EOF or a broken stdin: stop watching it, wait for signals only
                readEnter = false;
            }
        }
    }
#endif
}

}   // namespace util::shutdown
