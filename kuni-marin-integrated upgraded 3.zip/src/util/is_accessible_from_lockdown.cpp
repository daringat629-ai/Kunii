#include "is_accessible_from_lockdown.h"

#include "chat_allowlist.h"
#include "config.h"
#include "contacts_cache.h"

#include <range/v3/algorithm/contains.hpp>

AFuture<bool> util::isAccessibleFromLockdown(ITelegramClient& telegram, int64_t chatId) {
#ifdef AUI_TESTS_MODULE
    co_return config().papikChatId == chatId;
#else
    if (config().lockdown == Config::LockdownMode::NONE) {
        co_return true;
    }

    // Chats the owner explicitly allowed (general.allowed_chat_ids) are reachable in any lockdown mode. This is the
    // way to let Kuni into a particular group: "contacts_only" never admits groups, because it compares the chat id
    // with the ids of her contacts (users).
    if (util::ChatAllowlist::parse(config().allowedChatIds.toStdString()).contains(chatId)) {
        co_return true;
    }

    switch (config().lockdown) {
        case Config::LockdownMode::NONE: {
            co_return true;
        }

        case Config::LockdownMode::CONTACTS_ONLY: {
            // refreshed periodically: contacts added while Kuni is running become visible without a restart
            static util::ContactsCache contacts;
            if (!contacts.fresh()) {
                auto response = co_await telegram.sendQueryWithResult(ITelegramClient::toPtr(td::td_api::getContacts()));
                contacts.update(response->user_ids_);
            }
            if (contacts.contains(chatId)) {
                co_return true;
            }
            [[fallthrough]];
        }

        case Config::LockdownMode::PAPIK_ONLY: {
            if (chatId == config().papikChatId) {
                co_return true;
            }
            [[fallthrough]];
        }

        default: {
            co_return false;
        }
    }
#endif
}
