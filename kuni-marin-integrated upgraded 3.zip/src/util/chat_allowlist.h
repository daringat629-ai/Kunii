#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace util {

/**
 * @brief List of chat ids that are always accessible, regardless of the lockdown mode. Pure logic, no dependencies.
 * @details
 * Parsed from a string such as "-1001234567890, 42; 7" (separators: comma, semicolon, whitespace). Lets the owner
 * open a specific group while keeping everything else locked down.
 */
struct ChatAllowlist {
    std::vector<int64_t> ids;
    std::vector<std::string> invalid;   // tokens that are not integers

    static ChatAllowlist parse(const std::string& csv);

    [[nodiscard]] bool contains(int64_t chatId) const noexcept;
    [[nodiscard]] bool empty() const noexcept { return ids.empty(); }
};

}   // namespace util
