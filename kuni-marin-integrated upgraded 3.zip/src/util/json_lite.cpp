#include "json_lite.h"

#include <cerrno>
#include <charconv>
#include <cmath>
#include <cstdio>
#include <cstdlib>

namespace util::json {

namespace {

constexpr size_t MAX_INPUT = 4 * 1024 * 1024;
constexpr int MAX_DEPTH = 64;

class Parser {
public:
    explicit Parser(std::string_view text) : mText(text) {}

    ParseResult run() {
        ParseResult r;
        if (mText.size() > MAX_INPUT) {
            return fail("input is too large", 0);
        }
        skipWs();
        Value v;
        if (!parseValue(v, 0)) {
            return fail(mError, mPos);
        }
        skipWs();
        if (mPos != mText.size()) {
            return fail("unexpected data after the JSON value", mPos);
        }
        r.value = std::move(v);
        return r;
    }

private:
    std::string_view mText;
    size_t mPos = 0;
    std::string mError;

    static ParseResult fail(std::string msg, size_t at) {
        ParseResult r;
        r.error = std::move(msg);
        r.errorOffset = at;
        return r;
    }

    bool err(const char* msg) {
        mError = msg;
        return false;
    }

    void skipWs() {
        while (mPos < mText.size() && (mText[mPos] == ' ' || mText[mPos] == '\t' || mText[mPos] == '\n' || mText[mPos] == '\r')) {
            ++mPos;
        }
    }

    bool consume(std::string_view lit) {
        if (mText.substr(mPos, lit.size()) == lit) {
            mPos += lit.size();
            return true;
        }
        return false;
    }

    bool parseValue(Value& out, int depth) {
        if (depth > MAX_DEPTH) {
            return err("nesting is too deep");
        }
        if (mPos >= mText.size()) {
            return err("unexpected end of input");
        }
        const char c = mText[mPos];
        if (c == '{') {
            return parseObject(out, depth);
        }
        if (c == '[') {
            return parseArray(out, depth);
        }
        if (c == '"') {
            out.type = Value::Type::STRING;
            return parseString(out.string);
        }
        if (c == 't') {
            if (!consume("true")) return err("invalid literal");
            out.type = Value::Type::BOOL;
            out.boolean = true;
            return true;
        }
        if (c == 'f') {
            if (!consume("false")) return err("invalid literal");
            out.type = Value::Type::BOOL;
            out.boolean = false;
            return true;
        }
        if (c == 'n') {
            if (!consume("null")) return err("invalid literal");
            out.type = Value::Type::NUL;
            return true;
        }
        if (c == '-' || (c >= '0' && c <= '9')) {
            return parseNumber(out);
        }
        return err("unexpected character");
    }

    bool parseObject(Value& out, int depth) {
        out.type = Value::Type::OBJECT;
        ++mPos;   // {
        skipWs();
        if (mPos < mText.size() && mText[mPos] == '}') {
            ++mPos;
            return true;
        }
        for (;;) {
            skipWs();
            if (mPos >= mText.size() || mText[mPos] != '"') {
                return err("object key must be a string");
            }
            std::string key;
            if (!parseString(key)) return false;
            skipWs();
            if (mPos >= mText.size() || mText[mPos] != ':') {
                return err("expected ':' after the object key");
            }
            ++mPos;
            skipWs();
            Value v;
            if (!parseValue(v, depth + 1)) return false;
            bool replaced = false;
            for (auto& kv : out.object) {
                if (kv.first == key) {
                    kv.second = std::move(v);
                    replaced = true;
                    break;
                }
            }
            if (!replaced) {
                out.object.emplace_back(std::move(key), std::move(v));
            }
            skipWs();
            if (mPos >= mText.size()) return err("unterminated object");
            if (mText[mPos] == ',') {
                ++mPos;
                continue;
            }
            if (mText[mPos] == '}') {
                ++mPos;
                return true;
            }
            return err("expected ',' or '}' in object");
        }
    }

    bool parseArray(Value& out, int depth) {
        out.type = Value::Type::ARRAY;
        ++mPos;   // [
        skipWs();
        if (mPos < mText.size() && mText[mPos] == ']') {
            ++mPos;
            return true;
        }
        for (;;) {
            skipWs();
            Value v;
            if (!parseValue(v, depth + 1)) return false;
            out.array.push_back(std::move(v));
            skipWs();
            if (mPos >= mText.size()) return err("unterminated array");
            if (mText[mPos] == ',') {
                ++mPos;
                continue;
            }
            if (mText[mPos] == ']') {
                ++mPos;
                return true;
            }
            return err("expected ',' or ']' in array");
        }
    }

    static void appendUtf8(std::string& s, unsigned cp) {
        if (cp < 0x80) {
            s += static_cast<char>(cp);
        } else if (cp < 0x800) {
            s += static_cast<char>(0xC0 | (cp >> 6));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        } else if (cp < 0x10000) {
            s += static_cast<char>(0xE0 | (cp >> 12));
            s += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        } else {
            s += static_cast<char>(0xF0 | (cp >> 18));
            s += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
            s += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
            s += static_cast<char>(0x80 | (cp & 0x3F));
        }
    }

    bool hex4(unsigned& out) {
        if (mPos + 4 > mText.size()) return err("truncated \\u escape");
        unsigned v = 0;
        for (int i = 0; i < 4; ++i) {
            const char c = mText[mPos + i];
            v <<= 4;
            if (c >= '0' && c <= '9') v |= static_cast<unsigned>(c - '0');
            else if (c >= 'a' && c <= 'f') v |= static_cast<unsigned>(c - 'a' + 10);
            else if (c >= 'A' && c <= 'F') v |= static_cast<unsigned>(c - 'A' + 10);
            else return err("invalid \\u escape");
        }
        mPos += 4;
        out = v;
        return true;
    }

    bool parseString(std::string& out) {
        ++mPos;   // opening quote
        for (;;) {
            if (mPos >= mText.size()) return err("unterminated string");
            const auto c = static_cast<unsigned char>(mText[mPos]);
            if (c == '"') {
                ++mPos;
                return true;
            }
            if (c < 0x20) return err("control character in string");
            if (c != '\\') {
                out += static_cast<char>(c);
                ++mPos;
                continue;
            }
            ++mPos;
            if (mPos >= mText.size()) return err("unterminated escape");
            const char e = mText[mPos++];
            switch (e) {
                case '"': out += '"'; break;
                case '\\': out += '\\'; break;
                case '/': out += '/'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'n': out += '\n'; break;
                case 'r': out += '\r'; break;
                case 't': out += '\t'; break;
                case 'u': {
                    unsigned cp = 0;
                    if (!hex4(cp)) return false;
                    if (cp >= 0xD800 && cp <= 0xDBFF) {
                        if (!consume("\\u")) return err("lone high surrogate");
                        unsigned lo = 0;
                        if (!hex4(lo)) return false;
                        if (lo < 0xDC00 || lo > 0xDFFF) return err("invalid low surrogate");
                        cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                    } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
                        return err("lone low surrogate");
                    }
                    appendUtf8(out, cp);
                    break;
                }
                default: return err("invalid escape sequence");
            }
        }
    }

    bool parseNumber(Value& out) {
        const size_t start = mPos;
        if (mText[mPos] == '-') ++mPos;
        if (mPos >= mText.size()) return err("invalid number");
        if (mText[mPos] == '0') {
            ++mPos;
            if (mPos < mText.size() && mText[mPos] >= '0' && mText[mPos] <= '9') return err("leading zeros are not allowed");
        } else if (mText[mPos] >= '1' && mText[mPos] <= '9') {
            while (mPos < mText.size() && mText[mPos] >= '0' && mText[mPos] <= '9') ++mPos;
        } else {
            return err("invalid number");
        }
        bool integer = true;
        if (mPos < mText.size() && mText[mPos] == '.') {
            integer = false;
            ++mPos;
            if (mPos >= mText.size() || mText[mPos] < '0' || mText[mPos] > '9') return err("digits expected after '.'");
            while (mPos < mText.size() && mText[mPos] >= '0' && mText[mPos] <= '9') ++mPos;
        }
        if (mPos < mText.size() && (mText[mPos] == 'e' || mText[mPos] == 'E')) {
            integer = false;
            ++mPos;
            if (mPos < mText.size() && (mText[mPos] == '+' || mText[mPos] == '-')) ++mPos;
            if (mPos >= mText.size() || mText[mPos] < '0' || mText[mPos] > '9') return err("digits expected in exponent");
            while (mPos < mText.size() && mText[mPos] >= '0' && mText[mPos] <= '9') ++mPos;
        }
        const std::string literal(mText.substr(start, mPos - start));
        errno = 0;
        const double d = std::strtod(literal.c_str(), nullptr);
        if (!std::isfinite(d)) return err("number is out of range");
        out.type = Value::Type::NUMBER;
        out.number = d;
        out.integer = integer;
        return true;
    }
};

void dumpValue(const Value& v, std::string& out) {
    switch (v.type) {
        case Value::Type::NUL: out += "null"; break;
        case Value::Type::BOOL: out += v.boolean ? "true" : "false"; break;
        case Value::Type::NUMBER: {
            char buf[40];
            if (v.integer && std::fabs(v.number) < 9e15) {
                std::snprintf(buf, sizeof buf, "%lld", static_cast<long long>(v.number));
            } else {
                std::snprintf(buf, sizeof buf, "%.17g", v.number);
            }
            out += buf;
            break;
        }
        case Value::Type::STRING: out += quote(v.string); break;
        case Value::Type::ARRAY: {
            out += '[';
            for (size_t i = 0; i < v.array.size(); ++i) {
                if (i) out += ',';
                dumpValue(v.array[i], out);
            }
            out += ']';
            break;
        }
        case Value::Type::OBJECT: {
            out += '{';
            for (size_t i = 0; i < v.object.size(); ++i) {
                if (i) out += ',';
                out += quote(v.object[i].first);
                out += ':';
                dumpValue(v.object[i].second, out);
            }
            out += '}';
            break;
        }
    }
}

}   // namespace

const Value* Value::find(std::string_view key) const noexcept {
    if (type != Type::OBJECT) {
        return nullptr;
    }
    for (const auto& kv : object) {
        if (kv.first == key) {
            return &kv.second;
        }
    }
    return nullptr;
}

std::string Value::dump() const {
    std::string out;
    dumpValue(*this, out);
    return out;
}

ParseResult parse(std::string_view text) {
    return Parser(text).run();
}

std::string quote(std::string_view s) {
    std::string out = "\"";
    for (const char ch : s) {
        const auto c = static_cast<unsigned char>(ch);
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    std::snprintf(buf, sizeof buf, "\\u%04x", c);
                    out += buf;
                } else {
                    out += ch;
                }
        }
    }
    out += '"';
    return out;
}

}   // namespace util::json
