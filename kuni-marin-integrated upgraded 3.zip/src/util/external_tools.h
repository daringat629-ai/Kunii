#pragma once

#include "process_runner.h"

#include <cstddef>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace util::external {

/**
 * @brief External tools: tools provided by modules of the "Zero Core" manager (or by anything else that writes a catalog).
 * Pure C++, no dependencies.
 *
 * Catalog (JSON, version 1) is a single file written atomically by the manager, with all templates already expanded:
 * @code
 * {"version":1, "tools":[{
 *    "module":"demo", "name":"demo_echo", "description":"Echo text",
 *    "parameters":{"properties":{"text":{"type":"string","description":"what to echo"}}, "required":["text"]},
 *    "command":["python3","/abs/echo.py"], "cwd":"/abs", "env":{"ZEROCORE_API":"1"},
 *    "timeout_seconds":30, "max_output_bytes":8000 }]}
 * @endcode
 * Protocol: the process gets `{"tool":"<name>","arguments":{...}}` on stdin; its stdout is the result for the LLM;
 * a non-zero exit code is reported as an error.
 */

struct Param {
    std::string name;
    std::string type;   // string | integer | number | boolean
    std::string description;
};

struct Tool {
    std::string module;
    std::string name;
    std::string description;
    std::vector<Param> params;
    std::vector<std::string> required;
    std::vector<std::string> argv;
    std::string cwd;
    std::vector<std::pair<std::string, std::string>> env;
    int timeoutSeconds = 30;
    size_t maxOutputBytes = 8000;

    [[nodiscard]] const Param* param(std::string_view paramName) const noexcept;
};

struct Catalog {
    std::vector<Tool> tools;
    /// Problems found while reading: invalid entries are skipped, the rest is kept.
    std::vector<std::string> errors;
};

bool isValidToolName(std::string_view name) noexcept;

Catalog parseCatalog(std::string_view jsonText);

struct Prepared {
    bool ok = false;
    std::string error;          // text for the LLM when !ok
    std::string stdinPayload;   // {"tool":..., "arguments":{...}} when ok
};

/// Validates the arguments chosen by the LLM against the tool schema (lenient about types the models often get wrong:
/// "3" for an integer, 3 for a string) and builds the stdin payload.
Prepared prepareCall(const Tool& tool, std::string_view argumentsJson);

process::Options makeOptions(const Tool& tool, std::string stdinPayload);

/// Text for the LLM from a finished process.
std::string formatToolResult(const process::Result& result);

}   // namespace util::external
