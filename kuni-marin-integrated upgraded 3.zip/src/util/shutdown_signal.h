#pragma once

#include <chrono>

namespace util::shutdown {

enum class Reason {
    SIGNAL,   // SIGINT/SIGTERM was received
    ENTER,    // the operator pressed Enter
};

struct WaitOptions {
    int stdinFd = 0;
    /// Treat any data on stdin as a shutdown request ("press Enter"). On EOF stdin is ignored, never a request.
    bool readEnter = true;
    std::chrono::milliseconds pollInterval { 200 };
};

/// Installs SIGINT and SIGTERM handlers that only set a flag. Idempotent.
void installSignalHandlers();

[[nodiscard]] bool signalRequested() noexcept;

/// Pretends that a signal arrived (tests).
void requestForTests() noexcept;
void resetForTests() noexcept;

/// True if "press Enter to shut down" should be offered: stdin is a terminal and KUNI_NO_ENTER is not "1".
[[nodiscard]] bool enterToShutdownEnabled();

/**
 * @brief Blocks until a shutdown is requested: a signal arrives, or (if enabled) data appears on stdin.
 * @details
 * The previous implementation blocked in `std::cin.get()`: any stray Enter stopped the bot, and a closed stdin
 * (systemd, nohup) returned immediately and stopped it right after startup.
 */
Reason waitForShutdown(const WaitOptions& options);

}   // namespace util::shutdown
