#include "external.h"

#include "AUI/Thread/AThread.h"
#include "config.h"
#include "util/external_tools.h"

#include <cstdint>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <thread>

#ifndef _WIN32
#include <sys/stat.h>
#endif

static constexpr auto LOG_TAG = "tools::external";

namespace {

AString toA(const std::string& s) {
    return AString::fromUtf8(AStringView(s.data(), s.size()));
}

OpenAITools::Tool makeTool(util::external::Tool spec) {
    OpenAITools::Tool tool;
    tool.name = toA(spec.name);
    tool.description = toA(spec.description);
    for (const auto& p : spec.params) {
        OpenAITools::Tool::Parameters::Property property;
        property.type = toA(p.type);
        property.description = toA(p.description);
        tool.parameters.properties[toA(p.name)] = std::move(property);
    }
    for (const auto& r : spec.required) {
        tool.parameters.required << toA(r);
    }
    // "strict" function calling requires every property to be required
    tool.strict = spec.required.size() == spec.params.size();
    tool.handler = [spec = std::move(spec)](OpenAITools::Ctx ctx) -> AFuture<AString> {
        auto prepared = util::external::prepareCall(spec, AJson::toString(ctx.args).toStdString());
        if (!prepared.ok) {
            co_return toA(prepared.error);
        }
        ALogger::info(LOG_TAG) << "CALL " << toA(spec.module) << "/" << toA(spec.name);
        auto options = util::external::makeOptions(spec, std::move(prepared.stdinPayload));

        // The tool may run for a while. The UI thread drives Telegram and everything else, so it must never block:
        // run the process on a worker thread and resume here when it is done.
        AFuture<AString> result;
        std::thread([options = std::move(options), result] {
            auto text = util::external::formatToolResult(util::process::run(options));
            AThread::main()->enqueue([result, text = std::move(text)] { result.supplyValue(toA(text)); });
        }).detach();
        co_return co_await result;
    };
    return tool;
}

struct Cache {
    std::string path;
    std::filesystem::file_time_type mtime {};
    std::uintmax_t size = 0;
    bool loaded = false;
    AVector<OpenAITools::Tool> tools;
};
Cache gCache;   // touched from the UI thread only (updateTools)

void reload(const std::string& path, std::filesystem::file_time_type mtime, std::uintmax_t size) {
    gCache.path = path;
    gCache.mtime = mtime;
    gCache.size = size;
    gCache.loaded = true;   // remembered even on failure: a broken file is reported once, not on every call

#ifndef _WIN32
    struct stat st {};
    if (::stat(path.c_str(), &st) == 0 && (st.st_mode & S_IWOTH) != 0) {
        ALogger::err(LOG_TAG) << "Refusing to load the tools catalog " << toA(path) << ": it is world-writable";
        gCache.tools.clear();
        return;
    }
#endif
    std::ifstream in(path, std::ios::binary);
    if (!in) {
        ALogger::warn(LOG_TAG) << "Can't read the tools catalog " << toA(path);
        return;   // keep the tools loaded before
    }
    std::stringstream buffer;
    buffer << in.rdbuf();
    auto catalog = util::external::parseCatalog(buffer.str());
    for (const auto& e : catalog.errors) {
        ALogger::warn(LOG_TAG) << "catalog: " << toA(e);
    }
    if (catalog.tools.empty() && !catalog.errors.empty()) {
        return;   // unusable file: keep what worked before
    }
    AVector<OpenAITools::Tool> tools;
    std::string names;
    for (auto& t : catalog.tools) {
        names += (names.empty() ? "" : ", ") + t.name;
        tools << makeTool(std::move(t));
    }
    gCache.tools = std::move(tools);
    ALogger::info(LOG_TAG) << "Loaded " << catalog.tools.size() << " external tool(s): " << toA(names);
}

const AVector<OpenAITools::Tool>& currentTools() {
    static const AVector<OpenAITools::Tool> none;
    const std::string path = config().externalToolsCatalog.toStdString();
    if (path.empty()) {
        if (gCache.loaded) {
            gCache = {};
            ALogger::info(LOG_TAG) << "External tools are disabled";
        }
        return none;
    }
    std::error_code ec;
    const auto mtime = std::filesystem::last_write_time(path, ec);
    if (ec) {
        if (gCache.loaded) {
            ALogger::warn(LOG_TAG) << "The tools catalog is missing: " << toA(path);
            gCache = {};
        }
        return none;
    }
    std::error_code ec2;
    const auto size = std::filesystem::file_size(path, ec2);
    if (!gCache.loaded || gCache.path != path || gCache.mtime != mtime || gCache.size != size) {
        reload(path, mtime, ec2 ? 0 : size);
    }
    return gCache.tools;
}

}   // namespace

void tools::external::addTo(OpenAITools& actions) {
    const auto& tools = currentTools();
    if (tools.empty()) {
        return;
    }
    auto existing = actions.handlers();   // a copy: keep it alive while we use iterators into it
    for (const auto& tool : tools) {
        if (auto it = existing.contains(tool.name)) {
            // already inserted by us during a previous iteration of this turn: refresh. Otherwise it is a built-in
            // tool (or another source) with the same name: never replace it.
            if (it->second.description != tool.description) {
                ALOG_DEBUG(LOG_TAG) << "external tool \"" << tool.name << "\" is ignored: the name is already taken";
                continue;
            }
        }
        actions.insert(tool);
    }
}
