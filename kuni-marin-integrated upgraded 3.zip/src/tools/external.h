#pragma once
#include "OpenAITools.h"

namespace tools::external {

/**
 * @brief Adds tools from the external tools catalog (config.toml: misc.external_tools_catalog) to `actions`.
 * @details
 * The catalog is written by a module manager (e.g., "Zero Core") and describes tools implemented as separate
 * processes (see util/external_tools.h for the format and the protocol). The file is re-read when it changes, so
 * modules can be installed, updated, hot-swapped and removed while kuni is running; no rebuild is needed.
 *
 * A tool never replaces a built-in tool with the same name. Does nothing if the option is empty.
 */
void addTo(OpenAITools& actions);

}   // namespace tools::external
