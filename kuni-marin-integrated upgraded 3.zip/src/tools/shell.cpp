#include "shell.h"

#include "AUI/Thread/AThread.h"
#include "util/process_runner.h"

#include <chrono>
#include <cstdlib>
#include <string>
#include <thread>

static constexpr auto LOG_TAG = "tools::shell";

namespace {
long long envNumber(const char* name, long long fallback) {
    if (const char* v = std::getenv(name); v != nullptr && *v != '\0') {
        char* end = nullptr;
        const long long n = std::strtoll(v, &end, 10);
        if (end != v && *end == '\0' && n > 0) {
            return n;
        }
    }
    return fallback;
}
}   // namespace

OpenAITools::Tool tools::shell() {
    return {
        .name = "shell",
        .description = "Runs a bash command on your Ubuntu laptop (60s timeout, output truncated to 8000 bytes). "
                       "Each call is a separate process, so cd does not persist.",
        .parameters = {
            .properties = {
                {"command", {.type = "string", .description = "bash command to execute"}},
            },
            .required = {"command"},
        },
        .handler = [](OpenAITools::Ctx ctx) -> AFuture<AString> {
            auto cmd = ctx.args["command"].asStringOpt().valueOrException("command string is required");
            ALogger::warn(LOG_TAG) << "EXEC: " << cmd;

            util::process::Options options;
            options.command = cmd.toStdString();
            // If KUNI_SHELL_CONTAINER is set, commands run inside that docker container (sandbox), not on the host.
            if (const char* container = std::getenv("KUNI_SHELL_CONTAINER"); container != nullptr && *container) {
                options.dockerContainer = container;
            }
            // Optional overrides: KUNI_SHELL_TIMEOUT (seconds), KUNI_SHELL_MAX_OUTPUT (bytes).
            options.timeout = std::chrono::seconds(envNumber("KUNI_SHELL_TIMEOUT", 60));
            options.maxOutputBytes = static_cast<size_t>(envNumber("KUNI_SHELL_MAX_OUTPUT", 8000));

            // A command may take up to a minute. The UI thread drives Telegram and everything else, so it must never
            // block: run the command on a worker thread and resume here when it is done.
            AFuture<AString> result;
            std::thread([options = std::move(options), result] {
                auto text = util::process::formatForLlm(util::process::runBash(options));
                AThread::main()->enqueue([result, text = std::move(text)] {
                    result.supplyValue(AString::fromUtf8(AStringView(text.data(), text.size())));
                });
            }).detach();
            co_return co_await result;
        },
    };
}
