#pragma once
#include "OpenAITools.h"

namespace tools {
/**
 * @brief Runs a bash command on the host. Dangerous: enabled only when KUNI_ENABLE_SHELL=1 environment variable is set.
 */
OpenAITools::Tool shell();
}
