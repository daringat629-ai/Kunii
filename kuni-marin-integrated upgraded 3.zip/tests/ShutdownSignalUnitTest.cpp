#include "util/shutdown_signal.h"
#include <gmock/gmock.h>

#include <csignal>
#include <cstdlib>
#include <thread>

#ifndef _WIN32
#include <unistd.h>

using namespace std::chrono_literals;
using util::shutdown::Reason;
using util::shutdown::WaitOptions;

TEST(ShutdownSignalUnit, SignalSetsTheFlagAndWakesTheWaiter) {
    util::shutdown::resetForTests();
    util::shutdown::installSignalHandlers();
    EXPECT_FALSE(util::shutdown::signalRequested());
    std::raise(SIGTERM);
    EXPECT_TRUE(util::shutdown::signalRequested());
    WaitOptions o;
    o.readEnter = false;
    o.pollInterval = 10ms;
    EXPECT_EQ(util::shutdown::waitForShutdown(o), Reason::SIGNAL);
    util::shutdown::resetForTests();
    std::signal(SIGTERM, SIG_DFL);
    std::signal(SIGINT, SIG_DFL);
}

TEST(ShutdownSignalUnit, EnterOnStdinRequestsShutdown) {
    util::shutdown::resetForTests();
    int fds[2];
    ASSERT_EQ(pipe(fds), 0);
    ASSERT_EQ(write(fds[1], "\n", 1), 1);
    WaitOptions o;
    o.stdinFd = fds[0];
    o.pollInterval = 10ms;
    EXPECT_EQ(util::shutdown::waitForShutdown(o), Reason::ENTER);
    close(fds[0]);
    close(fds[1]);
}

TEST(ShutdownSignalUnit, ClosedStdinDoesNotShutDownTheBot) {
    // regression: std::cin.get() returned immediately on EOF and the bot stopped right after startup
    util::shutdown::resetForTests();
    int fds[2];
    ASSERT_EQ(pipe(fds), 0);
    close(fds[1]);   // EOF on the read side
    std::thread t([] {
        std::this_thread::sleep_for(400ms);
        util::shutdown::requestForTests();
    });
    WaitOptions o;
    o.stdinFd = fds[0];
    o.pollInterval = 10ms;
    const auto start = std::chrono::steady_clock::now();
    EXPECT_EQ(util::shutdown::waitForShutdown(o), Reason::SIGNAL);
    EXPECT_GE(std::chrono::steady_clock::now() - start, 300ms);
    t.join();
    close(fds[0]);
    util::shutdown::resetForTests();
}

TEST(ShutdownSignalUnit, EnterCanBeDisabledByEnvironment) {
    setenv("KUNI_NO_ENTER", "1", 1);
    EXPECT_FALSE(util::shutdown::enterToShutdownEnabled());
    unsetenv("KUNI_NO_ENTER");
}

#endif
