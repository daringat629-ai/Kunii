#include "util/json_lite.h"
#include <gmock/gmock.h>

using util::json::parse;
using util::json::Value;

namespace {
Value ok(std::string_view text) {
    auto r = parse(text);
    EXPECT_TRUE(r.value.has_value());
    EXPECT_EQ(r.error, "");
    return r.value ? *r.value : Value {};
}
bool bad(std::string_view text) {
    auto r = parse(text);
    return !r.value.has_value() && !r.error.empty();
}
}   // namespace

TEST(JsonLiteUnit, Scalars) {
    EXPECT_TRUE(ok("null").isNull());
    EXPECT_TRUE(ok("true").boolean);
    EXPECT_FALSE(ok("false").boolean);
    EXPECT_TRUE(ok("false").isBool());
    EXPECT_EQ(ok("12").number, 12.0);
    EXPECT_TRUE(ok("12").integer);
    EXPECT_EQ(ok("-0").number, 0.0);
    EXPECT_EQ(ok("-3.5").number, -3.5);
    EXPECT_FALSE(ok("-3.5").integer);
    EXPECT_EQ(ok("1e3").number, 1000.0);
    EXPECT_FALSE(ok("1e3").integer);
    EXPECT_EQ(ok("2.5E+2").number, 250.0);
    EXPECT_EQ(ok("7.576e+08").number, 757600000.0);
    EXPECT_EQ(ok("  \n\t 5 \r\n").number, 5.0);
}

TEST(JsonLiteUnit, StringsAndEscapes) {
    EXPECT_EQ(ok("\"hello\"").string, "hello");
    EXPECT_EQ(ok("\"a\\\"b\\\\c\\/d\\n\\t\\r\\b\\f\"").string, std::string("a\"b\\c/d\n\t\r\b\f"));
    EXPECT_EQ(ok("\"\\u00e9\"").string, "\xC3\xA9");                 // é
    EXPECT_EQ(ok("\"\\u20ac\"").string, "\xE2\x82\xAC");             // €
    EXPECT_EQ(ok("\"\\ud83d\\ude00\"").string, "\xF0\x9F\x98\x80");  // surrogate pair
    EXPECT_EQ(ok("\"привет\"").string, "привет");                     // raw UTF-8 passes through
    EXPECT_EQ(ok("\"\"").string, "");
}

TEST(JsonLiteUnit, ArraysObjectsAndLookup) {
    auto v = ok("{ \"a\": [1, 2, {\"b\": null}], \"c\": \"x\", \"e\": {}, \"f\": [] }");
    ASSERT_TRUE(v.isObject());
    ASSERT_TRUE(v.find("a") != nullptr);
    EXPECT_EQ(v.find("a")->array.size(), 3u);
    EXPECT_TRUE(v.find("a")->array[2].find("b")->isNull());
    EXPECT_EQ(v.find("c")->string, "x");
    EXPECT_TRUE(v.find("e")->object.empty());
    EXPECT_TRUE(v.find("f")->array.empty());
    EXPECT_TRUE(v.find("zzz") == nullptr);
    EXPECT_TRUE(ok("[1]").find("a") == nullptr);   // not an object
}

TEST(JsonLiteUnit, DuplicateKeysLastWins) {
    auto v = ok("{\"a\":1,\"b\":2,\"a\":3}");
    EXPECT_EQ(v.object.size(), 2u);
    EXPECT_EQ(v.find("a")->number, 3.0);
}

TEST(JsonLiteUnit, RejectsInvalidInput) {
    for (const char* text : { "", " ", "{", "[", "[1,]", "{\"a\":1,}", "'a'", "\"abc", "01", "1.", ".5", "+1", "-", "1e", "1e+",
                              "tru", "nul", "[1 2]", "{\"a\" 1}", "{1:2}", "{\"a\":}", "\"\\x\"", "\"\\u12\"", "\"\\u12zz\"",
                              "\"\\ud83d\"", "\"\\ude00\"", "\"\\ud83d\\u0041\"", "1 2", "{}{}", "[1,2", "\"a\nb\"", "1e999" }) {
        EXPECT_TRUE(bad(text));
    }
}

TEST(JsonLiteUnit, ErrorOffsetPointsNearTheProblem) {
    auto r = parse("{\"a\": 1, \"b\": }");
    ASSERT_FALSE(r.value.has_value());
    EXPECT_GE(r.errorOffset, 14u);
}

TEST(JsonLiteUnit, DepthLimit) {
    EXPECT_TRUE(parse(std::string(60, '[') + std::string(60, ']')).value.has_value());
    EXPECT_TRUE(bad(std::string(70, '[') + std::string(70, ']')));
}

TEST(JsonLiteUnit, SizeLimit) {
    EXPECT_TRUE(bad("\"" + std::string(5 * 1024 * 1024, 'x') + "\""));
}

TEST(JsonLiteUnit, DumpRoundTrip) {
    const std::string text = "{\"a\":[1,2.5,true,null,\"x\\ny\"],\"b\":{\"c\":\"\xD0\xBF\"},\"n\":-7}";
    EXPECT_EQ(ok(text).dump(), text);
    EXPECT_EQ(ok("{\"i\": 5, \"f\": 1.5, \"e\": 1e2}").dump(), "{\"i\":5,\"f\":1.5,\"e\":100}");
    EXPECT_EQ(util::json::quote("a\"b\\c\n\x01"), "\"a\\\"b\\\\c\\n\\u0001\"");
    EXPECT_EQ(util::json::quote(""), "\"\"");
    // what we print can always be parsed back
    std::string nasty;
    for (int c = 1; c < 128; ++c) {
        nasty += static_cast<char>(c);
    }
    auto back = parse(util::json::quote(nasty));
    ASSERT_TRUE(back.value.has_value());
    EXPECT_EQ(back.value->string, nasty);
}
