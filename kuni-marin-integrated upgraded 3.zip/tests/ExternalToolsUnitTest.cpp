#include "util/external_tools.h"
#include <gmock/gmock.h>

using namespace util::external;

namespace {
const char* GOOD = R"({"version":1,"tools":[
  {"module":"demo","name":"demo_echo","description":"Echo text",
   "parameters":{"properties":{"text":{"type":"string","description":"what to echo"}},"required":["text"]},
   "command":["python3","/abs/echo.py","--x"],"cwd":"/abs","env":{"ZEROCORE_API":"1","A_B":"v"},
   "timeout_seconds":12,"max_output_bytes":500},
  {"module":"demo","name":"demo_add","description":"Add numbers",
   "parameters":{"properties":{"a":{"type":"integer"},"b":{"type":"number"},"flag":{"type":"boolean"}},"required":["a","b"]},
   "command":["python3","/abs/add.py"]}]})";

Tool tool() {
    auto c = parseCatalog(GOOD);
    EXPECT_EQ(c.errors.size(), 0u);
    return c.tools.at(0);
}
Tool addTool() { return parseCatalog(GOOD).tools.at(1); }
}   // namespace

TEST(ExternalToolsUnit, ParsesAValidCatalog) {
    auto c = parseCatalog(GOOD);
    EXPECT_EQ(c.errors.size(), 0u);
    ASSERT_EQ(c.tools.size(), 2u);
    const auto& t = c.tools[0];
    EXPECT_EQ(t.module, "demo");
    EXPECT_EQ(t.name, "demo_echo");
    EXPECT_EQ(t.description, "Echo text");
    ASSERT_EQ(t.params.size(), 1u);
    EXPECT_EQ(t.params[0].name, "text");
    EXPECT_EQ(t.params[0].type, "string");
    EXPECT_EQ(t.params[0].description, "what to echo");
    EXPECT_EQ(t.required.size(), 1u);
    EXPECT_EQ(t.argv.size(), 3u);
    EXPECT_EQ(t.argv[1], "/abs/echo.py");
    EXPECT_EQ(t.cwd, "/abs");
    ASSERT_EQ(t.env.size(), 2u);
    EXPECT_EQ(t.env[0].first, "ZEROCORE_API");
    EXPECT_EQ(t.timeoutSeconds, 12);
    EXPECT_EQ(t.maxOutputBytes, 500u);
    // defaults
    EXPECT_EQ(c.tools[1].timeoutSeconds, 30);
    EXPECT_EQ(c.tools[1].maxOutputBytes, 8000u);
    EXPECT_EQ(c.tools[1].params.size(), 3u);
}

TEST(ExternalToolsUnit, CatalogLevelProblems) {
    EXPECT_FALSE(parseCatalog("").errors.empty());
    EXPECT_FALSE(parseCatalog("{broken").errors.empty());
    EXPECT_FALSE(parseCatalog("[]").errors.empty());
    EXPECT_FALSE(parseCatalog("{\"version\":2,\"tools\":[]}").errors.empty());
    EXPECT_FALSE(parseCatalog("{\"tools\":[]}").errors.empty());
    EXPECT_FALSE(parseCatalog("{\"version\":1}").errors.empty());
    auto empty = parseCatalog("{\"version\":1,\"tools\":[]}");
    EXPECT_TRUE(empty.errors.empty());
    EXPECT_TRUE(empty.tools.empty());
}

TEST(ExternalToolsUnit, InvalidEntriesAreSkippedAndTheRestIsKept) {
    const std::string text = R"({"version":1,"tools":[
      {"name":"Bad-Name","description":"x","command":["a"]},
      {"name":"no_desc","command":["a"]},
      {"name":"bad_type","description":"x","parameters":{"properties":{"p":{"type":"array"}}},"command":["a"]},
      {"name":"bad_param_name","description":"x","parameters":{"properties":{"Bad Name":{"type":"string"}}},"command":["a"]},
      {"name":"bad_required","description":"x","parameters":{"properties":{},"required":["zzz"]},"command":["a"]},
      {"name":"no_cmd","description":"x","command":[]},
      {"name":"cmd_types","description":"x","command":["a",1]},
      {"name":"empty_prog","description":"x","command":[""]},
      {"name":"bad_env","description":"x","command":["a"],"env":{"1BAD":"v"}},
      {"name":"env_value","description":"x","command":["a"],"env":{"OK":5}},
      {"name":"timeout0","description":"x","command":["a"],"timeout_seconds":0},
      {"name":"timeout_big","description":"x","command":["a"],"timeout_seconds":301},
      {"name":"timeout_frac","description":"x","command":["a"],"timeout_seconds":1.5},
      {"name":"out_small","description":"x","command":["a"],"max_output_bytes":50},
      "not an object",
      {"name":"fine_one","description":"ok","command":["a"]},
      {"name":"fine_one","description":"duplicate","command":["b"]}]})";
    auto c = parseCatalog(text);
    ASSERT_EQ(c.tools.size(), 1u);
    EXPECT_EQ(c.tools[0].name, "fine_one");
    EXPECT_EQ(c.tools[0].argv[0], "a");   // the first duplicate wins
    EXPECT_EQ(c.errors.size(), 16u);
}

TEST(ExternalToolsUnit, ToolNames) {
    EXPECT_TRUE(isValidToolName("ab"));
    EXPECT_TRUE(isValidToolName("demo_echo2"));
    for (const char* n : { "", "a", "1abc", "Abc", "a-b", "a b", "a.b", "\xD0\xBF\xD1\x80" }) {
        EXPECT_FALSE(isValidToolName(n));
    }
    EXPECT_FALSE(isValidToolName(std::string(65, 'a')));
    EXPECT_TRUE(isValidToolName(std::string(64, 'a')));
}

TEST(ExternalToolsUnit, PrepareCallBuildsThePayload) {
    auto p = prepareCall(tool(), "{\"text\":\"hi\"}");
    ASSERT_TRUE(p.ok);
    EXPECT_EQ(p.stdinPayload, "{\"tool\":\"demo_echo\",\"arguments\":{\"text\":\"hi\"}}");
    auto spaced = prepareCall(tool(), " { \"text\" : \"a b\" } ");
    ASSERT_TRUE(spaced.ok);
    EXPECT_EQ(spaced.stdinPayload, "{\"tool\":\"demo_echo\",\"arguments\":{\"text\":\"a b\"}}");
}

TEST(ExternalToolsUnit, PrepareCallEscapesSpecialCharacters) {
    auto p = prepareCall(tool(), "{\"text\":\"line1\\nq\\\"uote \\u043f\"}");
    ASSERT_TRUE(p.ok);
    EXPECT_EQ(p.stdinPayload, "{\"tool\":\"demo_echo\",\"arguments\":{\"text\":\"line1\\nq\\\"uote \xD0\xBF\"}}");
}

TEST(ExternalToolsUnit, PrepareCallRequiredAndUnknownArguments) {
    EXPECT_FALSE(prepareCall(tool(), "{}").ok);
    EXPECT_NE(prepareCall(tool(), "{}").error.find("missing required argument \"text\""), std::string::npos);
    EXPECT_NE(prepareCall(tool(), "").error.find("missing required"), std::string::npos);
    EXPECT_NE(prepareCall(tool(), "null").error.find("missing required"), std::string::npos);
    auto unknown = prepareCall(tool(), "{\"text\":\"x\",\"evil\":1}");
    EXPECT_FALSE(unknown.ok);
    EXPECT_NE(unknown.error.find("unknown argument \"evil\""), std::string::npos);
    EXPECT_NE(prepareCall(tool(), "{\"text\":null}").error.find("missing required"), std::string::npos);
}

TEST(ExternalToolsUnit, PrepareCallRejectsGarbage) {
    EXPECT_FALSE(prepareCall(tool(), "{not json").ok);
    EXPECT_NE(prepareCall(tool(), "{not json").error.find("not valid JSON"), std::string::npos);
    EXPECT_NE(prepareCall(tool(), "[1,2]").error.find("must be a JSON object"), std::string::npos);
    EXPECT_NE(prepareCall(tool(), "\"x\"").error.find("must be a JSON object"), std::string::npos);
}

TEST(ExternalToolsUnit, TypeCoercion) {
    auto t = addTool();
    auto a = prepareCall(t, "{\"a\":\"3\",\"b\":\"2.5\",\"flag\":\"true\"}");
    ASSERT_TRUE(a.ok);
    EXPECT_EQ(a.stdinPayload, "{\"tool\":\"demo_add\",\"arguments\":{\"a\":3,\"b\":2.5,\"flag\":true}}");
    auto sci = prepareCall(t, "{\"a\":7.576e+08,\"b\":1}");   // scientific notation for an integer (a known model quirk)
    ASSERT_TRUE(sci.ok);
    EXPECT_EQ(sci.stdinPayload, "{\"tool\":\"demo_add\",\"arguments\":{\"a\":757600000,\"b\":1}}");
    EXPECT_FALSE(prepareCall(t, "{\"a\":1.5,\"b\":1}").ok);
    EXPECT_NE(prepareCall(t, "{\"a\":1.5,\"b\":1}").error.find("must be an integer"), std::string::npos);
    EXPECT_FALSE(prepareCall(t, "{\"a\":\"abc\",\"b\":1}").ok);
    EXPECT_FALSE(prepareCall(t, "{\"a\":1,\"b\":\"\"}").ok);
    EXPECT_FALSE(prepareCall(t, "{\"a\":1,\"b\":2,\"flag\":\"maybe\"}").ok);
    EXPECT_FALSE(prepareCall(t, "{\"a\":[1],\"b\":2}").ok);
    auto strFromNumber = prepareCall(tool(), "{\"text\":5}");
    ASSERT_TRUE(strFromNumber.ok);
    EXPECT_EQ(strFromNumber.stdinPayload, "{\"tool\":\"demo_echo\",\"arguments\":{\"text\":\"5\"}}");
    EXPECT_FALSE(prepareCall(tool(), "{\"text\":{\"a\":1}}").ok);
    auto optionalNull = prepareCall(t, "{\"a\":1,\"b\":2,\"flag\":null}");
    ASSERT_TRUE(optionalNull.ok);
    EXPECT_EQ(optionalNull.stdinPayload, "{\"tool\":\"demo_add\",\"arguments\":{\"a\":1,\"b\":2}}");
}

TEST(ExternalToolsUnit, PrepareCallPayloadLimit) {
    auto p = prepareCall(tool(), "{\"text\":\"" + std::string(70000, 'x') + "\"}");
    EXPECT_FALSE(p.ok);
    EXPECT_NE(p.error.find("too large"), std::string::npos);
    EXPECT_TRUE(p.stdinPayload.empty());
}

TEST(ExternalToolsUnit, MakeOptionsMapsEveryField) {
    auto o = makeOptions(tool(), "PAYLOAD");
    EXPECT_EQ(o.argv.size(), 3u);
    EXPECT_EQ(o.cwd, "/abs");
    EXPECT_EQ(o.env.size(), 2u);
    EXPECT_EQ(o.stdinData, "PAYLOAD");
    EXPECT_EQ(o.timeout, std::chrono::seconds(12));
    EXPECT_EQ(o.maxOutputBytes, 500u);
}

TEST(ExternalToolsUnit, FormatToolResult) {
    using util::process::Result;
    Result r;
    r.exitCode = 0;
    r.output = "result\n\n";
    EXPECT_EQ(formatToolResult(r), "result");
    r.output = "";
    EXPECT_EQ(formatToolResult(r), "(no output)");
    r.output = "boom\n";
    r.exitCode = 2;
    EXPECT_EQ(formatToolResult(r), "error: the tool exited with code 2\nboom");
    r.output = "";
    EXPECT_EQ(formatToolResult(r), "error: the tool exited with code 2");
    Result t;
    t.exitCode = 143;
    t.timedOut = true;
    t.timeoutUsed = std::chrono::seconds(30);
    t.output = "partial";
    EXPECT_EQ(formatToolResult(t), "partial\n[timed out after 30 s; the process was killed]");
    Result tr;
    tr.exitCode = 0;
    tr.truncated = true;
    tr.output = "abc";
    EXPECT_EQ(formatToolResult(tr), "abc\n[output truncated]");
    Result f;
    f.spawnFailed = true;
    f.error = "python3: No such file or directory";
    EXPECT_EQ(formatToolResult(f), "error: failed to start the tool: python3: No such file or directory");
}
