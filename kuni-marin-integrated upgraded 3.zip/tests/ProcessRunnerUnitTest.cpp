#include "util/process_runner.h"
#include <gmock/gmock.h>

#include <chrono>
#include <cstdlib>

using namespace std::chrono_literals;
using util::process::Options;
using util::process::Result;

#ifndef _WIN32

namespace {
Result run(const std::string& cmd, std::chrono::milliseconds timeout = 5s, size_t maxOut = 8000) {
    Options o;
    o.command = cmd;
    o.timeout = timeout;
    o.maxOutputBytes = maxOut;
    o.killGrace = 500ms;
    return util::process::runBash(o);
}
}   // namespace

TEST(ProcessRunnerUnit, CapturesOutputAndExitCode) {
    auto r = run("echo hello; echo oops 1>&2; exit 3");
    EXPECT_EQ(r.output, "hello\noops\n");
    EXPECT_EQ(r.exitCode, 3);
    EXPECT_FALSE(r.timedOut);
    EXPECT_FALSE(r.truncated);
    EXPECT_FALSE(r.spawnFailed);
}

TEST(ProcessRunnerUnit, StdinIsDevNull) {
    auto start = std::chrono::steady_clock::now();
    auto r = run("cat; echo done");
    EXPECT_EQ(r.output, "done\n");
    EXPECT_LT(std::chrono::steady_clock::now() - start, 3s);
}

TEST(ProcessRunnerUnit, TimeoutKillsAndReturnsQuickly) {
    auto start = std::chrono::steady_clock::now();
    auto r = run("echo before; sleep 30", 400ms);
    EXPECT_TRUE(r.timedOut);
    EXPECT_EQ(r.output, "before\n");
    EXPECT_LT(std::chrono::steady_clock::now() - start, 4s);
}

TEST(ProcessRunnerUnit, TimeoutKillsTheWholeProcessGroup) {
    auto r = run("sleep 31.337 & sleep 31.337 & wait", 400ms);
    EXPECT_TRUE(r.timedOut);
    std::this_thread::sleep_for(300ms);
    // pgrep returns non-zero if nothing matches. "[s]leep" keeps the pattern from matching the sh that runs pgrep
    EXPECT_NE(std::system("pgrep -f '[s]leep 31.337' > /dev/null"), 0);
}

TEST(ProcessRunnerUnit, StubbornProcessIsKilledWithSigkill) {
    auto start = std::chrono::steady_clock::now();
    auto r = run("trap '' TERM; while true; do sleep 0.1; done", 300ms);
    EXPECT_TRUE(r.timedOut);
    EXPECT_LT(std::chrono::steady_clock::now() - start, 4s);
}

TEST(ProcessRunnerUnit, OutputIsCapped) {
    auto r = run("head -c 20000 /dev/zero | tr '\\0' a", 5s, 100);
    EXPECT_TRUE(r.truncated);
    EXPECT_EQ(r.output.size(), 100u);
}

TEST(ProcessRunnerUnit, CutInTheMiddleOfAUtf8CharacterIsTrimmed) {
    // each character is 2 bytes; the limit of 7 bytes would cut the 4th one in half
    auto r = run("for i in 1 2 3 4 5 6; do printf 'ж'; done", 5s, 7);
    EXPECT_TRUE(r.truncated);
    EXPECT_EQ(r.output, "жжж");
}

TEST(ProcessRunnerUnit, BackgroundJobDoesNotBlockTheCall) {
    auto start = std::chrono::steady_clock::now();
    auto r = run("(sleep 4 &) ; echo started", 10s);
    EXPECT_EQ(r.output, "started\n");
    EXPECT_FALSE(r.timedOut);
    EXPECT_LT(std::chrono::steady_clock::now() - start, 3s);
}

TEST(ProcessRunnerUnit, MissingDockerIsReportedNotThrown) {
    Options o;
    o.command = "true";
    o.dockerContainer = "kuni-test-no-such-container";
    o.timeout = 5s;
    auto r = util::process::runBash(o);
    // either docker is missing (spawn failure) or it exists and fails to find the container
    EXPECT_TRUE(r.spawnFailed || r.exitCode != 0);
}


TEST(ProcessRunnerUnit, ArgvModeRunsWithoutAShell) {
    Options o;
    o.command = "echo should-not-run";   // ignored when argv is set
    o.argv = { "printf", "%s-%s", "a", "$HOME" };
    auto r = util::process::run(o);
    EXPECT_EQ(r.output, "a-$HOME");   // no shell expansion
    EXPECT_EQ(r.exitCode, 0);
}

TEST(ProcessRunnerUnit, StdinDataReachesTheProcess) {
    Options o;
    o.argv = { "cat" };
    o.stdinData = "hello\nworld";
    auto r = util::process::run(o);
    EXPECT_EQ(r.output, "hello\nworld");
}

TEST(ProcessRunnerUnit, LargeStdinRoundTrip) {
    Options o;
    o.argv = { "cat" };
    o.stdinData = std::string(60000, 'x');
    o.maxOutputBytes = 100000;
    auto r = util::process::run(o);
    EXPECT_EQ(r.output.size(), 60000u);
    EXPECT_FALSE(r.truncated);
}

TEST(ProcessRunnerUnit, ProcessThatIgnoresStdinNeitherBlocksNorKillsUs) {
    Options o;
    o.argv = { "true" };
    o.stdinData = std::string(65536, 'x');
    auto start = std::chrono::steady_clock::now();
    auto r = util::process::run(o);
    EXPECT_EQ(r.exitCode, 0);
    EXPECT_LT(std::chrono::steady_clock::now() - start, 3s);
}

TEST(ProcessRunnerUnit, ExtraEnvironmentAddsAndOverrides) {
    setenv("KUNI_T_INHERIT", "kept", 1);
    setenv("KUNI_T_OVERRIDE", "old", 1);
    Options o;
    o.argv = { "sh", "-c", "echo $KUNI_T_INHERIT $KUNI_T_OVERRIDE $KUNI_T_NEW" };
    o.env = { { "KUNI_T_OVERRIDE", "new" }, { "KUNI_T_NEW", "added" } };
    auto r = util::process::run(o);
    EXPECT_EQ(r.output, "kept new added\n");
    unsetenv("KUNI_T_INHERIT");
    unsetenv("KUNI_T_OVERRIDE");
}

TEST(ProcessRunnerUnit, WorkingDirectory) {
    Options o;
    o.argv = { "pwd" };
    o.cwd = "/tmp";
    EXPECT_EQ(util::process::run(o).output, "/tmp\n");
    o.cwd = "/nonexistent-kuni-dir";
    auto r = util::process::run(o);
    EXPECT_NE(r.exitCode, 0);
}

TEST(ProcessRunnerUnit, ArgvWithMissingProgramReportsSpawnFailure) {
    Options o;
    o.argv = { "/nonexistent/kuni-program" };
    auto r = util::process::run(o);
    EXPECT_TRUE(r.spawnFailed || r.exitCode != 0);
}

TEST(ProcessRunnerUnit, ArgvTimeoutWithStdin) {
    Options o;
    o.argv = { "sh", "-c", "cat > /dev/null; sleep 30" };
    o.stdinData = "data";
    o.timeout = 400ms;
    o.killGrace = 300ms;
    auto start = std::chrono::steady_clock::now();
    auto r = util::process::run(o);
    EXPECT_TRUE(r.timedOut);
    EXPECT_LT(std::chrono::steady_clock::now() - start, 4s);
}

TEST(ProcessRunnerUnit, TrimIncompleteUtf8) {
    std::string a = "ab\xD0";   // first half of a 2-byte character
    util::process::trimIncompleteUtf8(a);
    EXPECT_EQ(a, "ab");
    std::string b = "\xE2\x82";   // 2 of 3 bytes
    util::process::trimIncompleteUtf8(b);
    EXPECT_EQ(b, "");
    std::string c = "ok\xD0\xB6";   // complete
    util::process::trimIncompleteUtf8(c);
    EXPECT_EQ(c, "ok\xD0\xB6");
    std::string d;
    util::process::trimIncompleteUtf8(d);
    EXPECT_EQ(d, "");
}

#endif

TEST(ProcessRunnerUnit, FormatForLlm) {
    Result r;
    r.exitCode = 0;
    EXPECT_EQ(util::process::formatForLlm(r), "(no output)");

    r.output = "hi\n";
    EXPECT_EQ(util::process::formatForLlm(r), "hi\n");

    r.exitCode = 2;
    EXPECT_EQ(util::process::formatForLlm(r), "hi\n\n[exit code 2]");

    r.timedOut = true;
    r.timeoutUsed = 60s;
    EXPECT_EQ(util::process::formatForLlm(r), "hi\n\n[timed out after 60 s; the process was killed]");

    Result t;
    t.exitCode = 0;
    t.output = "x";
    t.truncated = true;
    EXPECT_EQ(util::process::formatForLlm(t), "x\n[output truncated]");

    Result f;
    f.spawnFailed = true;
    f.error = "bash: No such file or directory";
    EXPECT_EQ(util::process::formatForLlm(f), "error: failed to start the shell: bash: No such file or directory");
}
