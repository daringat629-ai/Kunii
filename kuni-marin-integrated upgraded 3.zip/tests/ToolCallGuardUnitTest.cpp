#include "util/tool_call_guard.h"
#include <gmock/gmock.h>

using util::ToolCallGuard;
using Verdict = ToolCallGuard::Verdict;

TEST(ToolCallGuardUnit, AllowsDifferentCalls) {
    ToolCallGuard g;
    for (int i = 0; i < 20; ++i) {
        EXPECT_TRUE(g.check("shell", "{\"command\":\"ls " + std::to_string(i) + "\"}").allowed());
    }
    EXPECT_EQ(g.executedCalls(), 20u);
    EXPECT_EQ(g.refusedCalls(), 0u);
}

TEST(ToolCallGuardUnit, RefusesFourthIdenticalCallInARow) {
    ToolCallGuard g;   // maxConsecutiveIdentical = 3
    EXPECT_TRUE(g.check("query", "{\"text\":\"x\"}").allowed());
    EXPECT_TRUE(g.check("query", "{\"text\":\"x\"}").allowed());
    EXPECT_TRUE(g.check("query", "{\"text\":\"x\"}").allowed());
    auto d = g.check("query", "{\"text\":\"x\"}");
    EXPECT_FALSE(d.allowed());
    EXPECT_EQ(d.verdict, Verdict::REFUSE_IDENTICAL);
    EXPECT_NE(d.message.find("query"), std::string::npos);
}

TEST(ToolCallGuardUnit, DifferentCallResetsTheStreak) {
    ToolCallGuard g;
    for (int round = 0; round < 5; ++round) {
        EXPECT_TRUE(g.check("a", "{}").allowed());
        EXPECT_TRUE(g.check("a", "{}").allowed());
        EXPECT_TRUE(g.check("b", "{}").allowed());
    }
}

TEST(ToolCallGuardUnit, SameToolDifferentArgumentsIsNotIdentical) {
    ToolCallGuard g;
    for (int i = 0; i < 10; ++i) {
        EXPECT_TRUE(g.check("query", "{\"text\":\"" + std::to_string(i) + "\"}").allowed());
    }
}

TEST(ToolCallGuardUnit, JsonWhitespaceIsIgnoredButStringContentIsNot) {
    EXPECT_EQ(ToolCallGuard::normalizeArguments("{ \"a\" : 1,\n \"b\":  [1, 2] }"), "{\"a\":1,\"b\":[1,2]}");
    EXPECT_EQ(ToolCallGuard::normalizeArguments("{\"t\": \"a  b\"}"), "{\"t\":\"a  b\"}");
    EXPECT_EQ(ToolCallGuard::normalizeArguments("{\"t\": \"q\\\" x\"}"), "{\"t\":\"q\\\" x\"}");

    ToolCallGuard g;
    EXPECT_TRUE(g.check("t", "{\"a\": 1}").allowed());
    EXPECT_TRUE(g.check("t", "{\"a\":1}").allowed());
    EXPECT_TRUE(g.check("t", "{ \"a\":1 }").allowed());
    EXPECT_FALSE(g.check("t", "{\"a\" :1}").allowed());   // fourth in a row, whitespace differs only
}

TEST(ToolCallGuardUnit, PerTurnBudget) {
    ToolCallGuard::Limits l;
    l.maxCallsPerTurn = 5;
    l.perTool.clear();
    ToolCallGuard g(l);
    for (int i = 0; i < 5; ++i) {
        EXPECT_TRUE(g.check("t", "{\"i\":" + std::to_string(i) + "}").allowed());
    }
    auto d = g.check("t", "{\"i\":99}");
    EXPECT_EQ(d.verdict, Verdict::REFUSE_BUDGET);
}

TEST(ToolCallGuardUnit, PerToolBudgetForShellOnly) {
    ToolCallGuard::Limits l;
    l.perTool = { { "shell", 3 } };
    ToolCallGuard g(l);
    for (int i = 0; i < 3; ++i) {
        EXPECT_TRUE(g.check("shell", "{\"command\":\"c" + std::to_string(i) + "\"}").allowed());
    }
    EXPECT_EQ(g.check("shell", "{\"command\":\"c3\"}").verdict, Verdict::REFUSE_TOOL_BUDGET);
    EXPECT_TRUE(g.check("send_telegram_message", "{\"text\":\"hi\"}").allowed());
}

TEST(ToolCallGuardUnit, RefusedCallsDoNotConsumeTheBudget) {
    ToolCallGuard g;
    for (int i = 0; i < 3; ++i) {
        g.check("a", "{}");
    }
    for (int i = 0; i < 2; ++i) {
        EXPECT_FALSE(g.check("a", "{}").allowed());
    }
    EXPECT_EQ(g.executedCalls(), 3u);
    EXPECT_EQ(g.refusedCalls(), 2u);
}

TEST(ToolCallGuardUnit, AbortsTheTurnWhenTheLlmKeepsInsisting) {
    ToolCallGuard g;   // abortAfterRefusals = 3
    for (int i = 0; i < 3; ++i) {
        g.check("a", "{}");
    }
    EXPECT_FALSE(g.check("a", "{}").abortTurn);   // 1st refusal
    EXPECT_FALSE(g.check("a", "{}").abortTurn);   // 2nd
    auto d = g.check("a", "{}");                  // 3rd
    EXPECT_FALSE(d.allowed());
    EXPECT_TRUE(d.abortTurn);
}

TEST(ToolCallGuardUnit, ResetStartsANewTurn) {
    ToolCallGuard g;
    for (int i = 0; i < 6; ++i) {
        g.check("a", "{}");
    }
    EXPECT_GT(g.refusedCalls(), 0u);
    g.reset();
    EXPECT_EQ(g.executedCalls(), 0u);
    EXPECT_EQ(g.refusedCalls(), 0u);
    EXPECT_TRUE(g.check("a", "{}").allowed());
}

TEST(ToolCallGuardUnit, ZeroMeansUnlimited) {
    ToolCallGuard::Limits l;
    l.maxCallsPerTurn = 0;
    l.maxConsecutiveIdentical = 0;
    l.perTool = { { "shell", 0 } };
    l.abortAfterRefusals = 0;
    ToolCallGuard g(l);
    for (int i = 0; i < 500; ++i) {
        EXPECT_TRUE(g.check("shell", "{}").allowed());
    }
}
