#include "util/chat_allowlist.h"
#include <gmock/gmock.h>

using util::ChatAllowlist;

TEST(ChatAllowlistUnit, EmptyString) {
    auto a = ChatAllowlist::parse("");
    EXPECT_TRUE(a.empty());
    EXPECT_FALSE(a.contains(1));
    EXPECT_TRUE(a.invalid.empty());
}

TEST(ChatAllowlistUnit, ParsesSeparatorsAndNegativeGroupIds) {
    auto a = ChatAllowlist::parse(" -1001234567890, 42;7\n  -5 ");
    ASSERT_EQ(a.ids.size(), 4u);
    EXPECT_TRUE(a.contains(-1001234567890LL));
    EXPECT_TRUE(a.contains(42));
    EXPECT_TRUE(a.contains(7));
    EXPECT_TRUE(a.contains(-5));
    EXPECT_FALSE(a.contains(1001234567890LL));
    EXPECT_TRUE(a.invalid.empty());
}

TEST(ChatAllowlistUnit, ReportsInvalidTokensAndKeepsTheRest) {
    auto a = ChatAllowlist::parse("12, abc, 3x, -, 99999999999999999999, 8");
    EXPECT_EQ(a.ids.size(), 2u);
    EXPECT_TRUE(a.contains(12));
    EXPECT_TRUE(a.contains(8));
    EXPECT_EQ(a.invalid.size(), 4u);
}
