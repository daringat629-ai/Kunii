#include "util/contacts_cache.h"
#include <gmock/gmock.h>

using namespace std::chrono_literals;
using util::ContactsCache;

TEST(ContactsCacheUnit, EmptyCacheIsNotFresh) {
    ContactsCache c;
    EXPECT_FALSE(c.fresh());
    EXPECT_FALSE(c.contains(1));
}

TEST(ContactsCacheUnit, FreshWithinTtlAndStaleAfter) {
    ContactsCache c(60s);
    const auto t0 = ContactsCache::Clock::now();
    c.update({ 1, 2, 3 }, t0);
    EXPECT_TRUE(c.fresh(t0 + 59s));
    EXPECT_FALSE(c.fresh(t0 + 61s));
    EXPECT_TRUE(c.contains(2));
    EXPECT_FALSE(c.contains(4));
}

TEST(ContactsCacheUnit, UpdateReplacesTheListSoNewContactsAreSeen) {
    ContactsCache c(60s);
    const auto t0 = ContactsCache::Clock::now();
    c.update({ 1 }, t0);
    EXPECT_FALSE(c.contains(5));
    c.update({ 1, 5 }, t0 + 120s);
    EXPECT_TRUE(c.contains(5));
    EXPECT_TRUE(c.fresh(t0 + 150s));
}

TEST(ContactsCacheUnit, InvalidateForcesRefresh) {
    ContactsCache c;
    c.update({ 7 });
    EXPECT_TRUE(c.fresh());
    c.invalidate();
    EXPECT_FALSE(c.fresh());
}
