# Основная архитектура: kuni + «Нулевое ядро»

Одно дерево, две части, один контракт между ними. Часть на C++ (`src/`) делает бота; часть на Python (`zero_core/`) управляет модулями, показывает панель и живую схему архитектуры.

## Карта дерева

| Путь | Что это |
|---|---|
| `src/`, `tests/`, `CMakeLists.txt` | бот kuni (C++20, AUI, TDLib) с этапами A и B (см. `UPGRADE_CORE.md`) |
| `prompts/`, `marin_world/` | характер и мир Марин |
| `zero_core/zerocore/kernel/` | ядро: контракты манифеста, реестр возможностей, шина событий, транзакции состояния, жизненный цикл, здоровье, права |
| `zero_core/zerocore/module_manager/` | менеджер: установка, зависимости, горячая замена, откат, удаление |
| `zero_core/zerocore/admin/` | веб-панель: сервер, виджеты, граф архитектуры, живая активность, настройки |
| `zero_core/modules/` | модули: `kuni` (адаптер бота), `watchdog`, `world_v2`, `webview`, демо `demo_counter`, `demo_tools` |
| `zero_core/docs/` | `QUICKSTART.md`, `KIOSK.md` (панель на экране ноутбука), `ARCHITECTURE.md`, `WEBUI.md`, `TOOLS.md`, `CONTRACTS.md`, `KUNI_AUDIT.md` |
| `zero_core/preview/` | видео и картинки панели на демо-данных |
| `install_zero_core.sh` | установка и запуск одной командой |

## Как части связаны

```
 Telegram  ⇄  kuni (C++, src/)  ⇄  LLM
                │   ▲
   логи, события│   │tools.json (каталог инструментов, перечитывается при изменении)
                ▼   │
        Нулевое ядро (Python, zero_core/)
        менеджер ── реестр возможностей ── контракты ── шина событий
        модули:  kuni · watchdog · world_v2 · webview · demo_*
                │
                ▼
        веб-панель: виджеты · «Архитектура» (граф из реестра) · живые события по нитям
```

## Контракты между частями

| Контракт | Кто пишет | Кто читает | Где описан |
|---|---|---|---|
| манифест модуля (`manifest.json`: `provides`, `requires`, `widgets`, `tools`) | автор модуля | менеджер, панель | `zero_core/docs/CONTRACTS.md` |
| каталог инструментов `tools.json` (версия 1) | менеджер при каждом изменении набора модулей | бот: `src/tools/external.*`, `src/util/external_tools.*` | `zero_core/docs/TOOLS.md` |
| параметр бота `misc.external_tools_catalog` | `zerocore wire-kuni` | бот (`config.toml`, перечитывается сам) | `zero_core/docs/QUICKSTART.md` |
| логи бота (`logs/*query.json`, `/tmp/aui.*.log`) | бот | панель: статистика, «Генерация», «Тулы», живая активность | `zero_core/docs/ARCHITECTURE.md` |
| HTTP API панели (`/api/*`, токен в заголовке) | панель | браузер | `zero_core/docs/WEBUI.md` |

Контракт «менеджер ↔ код бота» проверяется сквозным тестом: каталог, записанный Python-менеджером, разбирается и выполняется настоящим кодом `src/util/*` (`zero_core/tests/test_cpp_contract.py`).

## Что изменено в боте (относительно загруженного дерева)

| Этап | Файлы |
|---|---|
| A: охранник вызовов инструментов, асинхронный `shell`, остановка по SIGTERM, контакты с TTL, список разрешённых чатов | `src/util/{tool_call_guard,process_runner,shutdown_signal,contacts_cache,chat_allowlist}.*`, `src/tools/shell.cpp`, `src/OpenAITools.*`, `src/main.cpp`, `src/config.*`, `src/util/is_accessible_from_lockdown.cpp` |
| B: внешние инструменты из каталога модулей | `src/util/{json_lite,external_tools}.*`, `src/tools/external.*`, `src/util/process_runner.*`, `src/config.*`, `src/main.cpp` |
| тесты | `tests/{ToolCallGuard,ProcessRunner,ShutdownSignal,ContactsCache,ChatAllowlist,JsonLite,ExternalTools}UnitTest.cpp` |

## Сборка, тесты, запуск

```
# бот (как раньше)
cmake -B build -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo && cmake --build build
cmake --build build --target Tests && ./build/bin/Tests --gtest_filter=-'*Integration*'

# «Нулевое ядро»: менеджер, панель, JS, контракт с кодом бота (нужны python3.12, node, g++)
cd zero_core && python3 -m unittest discover -s tests

# запуск на машине с ботом
./install_zero_core.sh --kuni-dir ~/kuni            # --wire-kuni, если бот собран с этапами A и B
```

## Что проверено, а что нет

Проверено: 168 тестов «Нулевого ядра» (включая JS и сквозной контракт с C++), 62 модульных теста нового кода бота без AUI, склейки бота запущены против заглушек AUI.
Не проверено: сборка бота целиком (нужна сеть и AUI) и работа на вашей машине; панель нарисована по настоящему коду на демо-данных, в реальном браузере не открывалась.
