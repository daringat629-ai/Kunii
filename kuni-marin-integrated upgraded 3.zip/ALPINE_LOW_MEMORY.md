# Alpine Linux / low-memory deployment profile

This profile targets a host with about 1.8 GiB total RAM and roughly 327 MiB
available at the time of measurement. That is a snapshot, not a fixed RAM cap.
The host already has swap in use, so avoid running local model inference or
GPU-oriented companion services on it.

## What changed

- Added `KUNI_BUILD_TESTS` so the server build can omit the test executable.
  The default remains ON for normal development builds.
- Added a single-job, `Release -O1 -g0` build script to reduce peak compiler
  memory and build-artifact size.
- Added a small runtime wrapper that limits common math-library thread counts
  and disables core dumps.
- Added an example config with bounded chat history, diary injection and
  video frame count; vision/audio/image generation are off in this profile.
- Put Ollama, Stable Diffusion, Whisper and OmniVoice behind the opt-in
  `local-ai` Docker Compose profile. Plain `docker compose up -d` will not
  start these heavy services; they can still be explicitly enabled with
  `docker compose --profile local-ai up -d`.

## Alpine packages

Install build prerequisites (package names can differ between Alpine
repositories/releases):

```sh
apk update
apk add --no-cache build-base cmake ninja git pkgconf linux-headers \
  openssl-dev zlib-dev curl-dev fontconfig-dev freetype-dev \
  libxcursor-dev libxi-dev libxrandr-dev libx11-dev glew-dev \
  mesa-dev pulseaudio-dev dbus-dev libepoxy-dev gperf
```

The project currently requires GCC 15+ or Clang 20+ for C++20 coroutine
support. Check `g++ --version` before building. The CMake configure step
downloads AUI, TDLib and other dependencies, so allow additional disk space
and network access.

## Build

```sh
chmod +x build_alpine_lowmem.sh run_alpine_lowmem.sh
BUILD_JOBS=1 ./build_alpine_lowmem.sh
```

Do not increase parallel jobs on this host unless you have measured sufficient
free RAM. Compilation can still temporarily use swap; one job reduces, but
does not guarantee a low peak.

## First run and configuration

Run `./build-alpine/bin/kuni` once to generate its default `config.toml`, then
stop it and merge the relevant settings from
`config.alpine-low-memory.example.toml`. Do not overwrite an existing config
or diary. Replace all placeholder API endpoint/model/key values and Telegram
credentials with your own. Keep `config.toml` private (`chmod 600 config.toml`).

For this machine, use a remote API for chat and embeddings. Do not install or
pull multi-billion-parameter Ollama models here. Enable image/audio services
only when hosted on a separate machine and configured by endpoint.

## Run

```sh
./run_alpine_lowmem.sh
```

The wrapper does not change application architecture or impose an arbitrary
memory limit. Monitor with `free -h` and `ps`; if memory pressure remains high,
reduce chat history/injected diary further or move the process to a host with
more available RAM.

## Important limitations

This is a deployment/build profile, not a claim that the source has been
compiled or integration-tested on your exact Alpine release. AUI/TDLib may
need additional Alpine packages or compiler fixes depending on repository
versions and CPU architecture. The C++ diary currently caches parsed entries
in memory; this profile bounds prompt/history settings but does not yet
convert the diary into a disk-paged index.
