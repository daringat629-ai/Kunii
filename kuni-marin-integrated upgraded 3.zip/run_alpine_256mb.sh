#!/bin/sh
set -eu
cd "$(dirname "$0")"
BIN="${KUNI_BIN:-./kuni}"
[ -x "$BIN" ] || BIN=./build-alpine/bin/kuni
[ -x "$BIN" ] || { echo "kuni binary not found" >&2; exit 1; }
ulimit -c 0 || true
ulimit -s 1024 || true   # меньше стек у потоков (musl берёт его как размер стека потока)
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
# musl не использует MALLOC_ARENA_MAX; отдельной настройки аллокатора не нужно.
exec "$BIN" "$@"
