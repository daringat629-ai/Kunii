#!/bin/bash
# Аварийная остановка: гасит песочницу Марин и (по желанию) бота.
#   ./kill_switch.sh        - остановить контейнер (shell перестанет работать)
#   ./kill_switch.sh all    - ещё и остановить бота
#   ./kill_switch.sh resume - снова запустить контейнер
case "$1" in
  resume) docker start marinka-box ;;
  all) docker stop marinka-box; pkill -x kuni && echo "бот остановлен" ;;
  *) docker stop marinka-box && echo "песочница остановлена" ;;
esac
