#!/bin/bash
# Запускать на ХОСТЕ (cron). Пишет состояние ноутбука в host.txt, который видна из контейнера.
OUT="$(dirname "$(readlink -f "$0")")/host.txt"
{
  echo "обновлено: $(date '+%Y-%m-%d %H:%M')"
  echo "аптайм: $(uptime -p)"
  echo "нагрузка: $(cut -d' ' -f1-3 /proc/loadavg)"
  free -h | awk 'NR==2{print "память: занято " $3 " из " $2}'
  df -h / | awk 'NR==2{print "диск /: занято " $3 " из " $2 " (" $5 ")"}'
  for z in /sys/class/thermal/thermal_zone*/temp; do [ -r "$z" ] && echo "температура: $(( $(cat $z) / 1000 )) C" && break; done
  command -v upower >/dev/null && upower -i "$(upower -e | grep -m1 BAT)" 2>/dev/null | grep -E "percentage|state" | sed 's/^ *//'
} > "$OUT" 2>/dev/null
