#!/bin/bash
# Запускать из папки с marin_world: bash marin_world/install.sh (на хосте, из ~/kuni)
set -e
cd "$(dirname "$(readlink -f "$0")")"
chmod +x world.py remind.py news.py hostinfo.sh kill_switch.sh show_exec.sh
mkdir -p notes
./hostinfo.sh
( crontab -l 2>/dev/null | grep -v hostinfo.sh; echo "*/10 * * * * $(pwd)/hostinfo.sh" ) | crontab -
python3 world.py look | head -3
echo "Готово. Мир, напоминания, новости и хост-инфо установлены."
