#!/bin/sh
# Запуск от root. Для 256 МБ ОЗУ: zram (сжатый своп в ОЗУ) + небольшой своп-файл на диске.
set -eu
if modprobe zram 2>/dev/null && [ -e /sys/block/zram0 ]; then
  echo zstd > /sys/block/zram0/comp_algorithm 2>/dev/null || true
  echo 192M > /sys/block/zram0/disksize
  mkswap /dev/zram0 && swapon -p 100 /dev/zram0
  echo "[OK] zram 192M"
fi
if [ ! -f /swapfile ]; then
  dd if=/dev/zero of=/swapfile bs=1M count=512 && chmod 600 /swapfile && mkswap /swapfile
fi
swapon -p 10 /swapfile 2>/dev/null || true
sysctl -w vm.swappiness=60 vm.vfs_cache_pressure=200 >/dev/null
free -m
