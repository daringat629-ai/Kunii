#!/bin/sh
# Устанавливает и запускает «Нулевое ядро» из этого дерева. Все аргументы передаются команде `zerocore up`.
#   ./install_zero_core.sh --kuni-dir ~/kuni            # модули, панель в tmux, адрес для телефона
#   ./install_zero_core.sh --kuni-dir ~/kuni --wire-kuni  # плюс подключить каталог инструментов к конфигу бота
cd "$(dirname "$0")/zero_core" || exit 1
exec python3 zerocore.py up --demo --theme black --tmux "$@"
