#!/usr/bin/env python3
"""Рисует картинку панели по дереву элементов из render_dump.js. Это приближение вида в браузере (свой шрифт и отступы),
а не снимок экрана; раскладка и содержимое посчитаны настоящим кодом панели.
  python3 render_png.py dump.json out.png [масштаб] [макс_высота_css_px]"""
import json
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONOB = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
SANS = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
KIND_RGB = {"dep": (61, 220, 132), "tools": (255, 183, 77), "widgets": (199, 146, 234), "ext": (255, 183, 77), "kuni": (199, 146, 234)}
GROUP_COLOR = {"kernel": "#6ea8ff", "manager": "#9b8cff", "module": "#3ddc84", "kuni": "#c792ea", "external": "#ffb74d"}
SYMBOLS = set("⚙⟳✕▸＋●—→")
THEMES = {
    "dark": dict(bg="#070b1c", panel="#0d1430", panel2="#111a3d", line="#26357a", fg="#cdd6ff", dim="#7f8bc4", acc="#7aa2ff",
                 ok="#58d68d", warn="#f5b041", bad="#ec7063", grid="#101a44"),
    "black": dict(bg="#000000", panel="#08080c", panel2="#101018", line="#262633", fg="#e8e8f2", dim="#8b8fa6", acc="#6ea8ff",
                  ok="#3ddc84", warn="#ffb74d", bad="#ff6b6b", grid="#0c0c12"),
    "light": dict(bg="#eef1fb", panel="#ffffff", panel2="#f3f5ff", line="#b8c3ee", fg="#1b2250", dim="#59629a", acc="#2f55d4",
                  ok="#1e8e4e", warn="#b9770e", bad="#c0392b", grid="#e1e6fa"),
}


def cls(n):
    return set((n.get("cls") or "").split())


def text_of(n):
    if n["tag"] == "#text":
        return n["text"]
    return (n.get("text") or "") + "".join(text_of(c) for c in n["children"])


def px(v, default=0.0):
    try:
        return float(str(v).replace("px", ""))
    except (TypeError, ValueError):
        return default


class Painter:
    def __init__(self, scale, theme):
        self.s, self.c, self._f = scale, THEMES[theme], {}

    def font(self, size, bold=False, sans=False):
        key = (round(size * self.s), bold, sans)
        if key not in self._f:
            self._f[key] = ImageFont.truetype(SANS if sans else (MONOB if bold else MONO), key[0])
        return self._f[key]

    def width(self, text, size, bold=False):
        return sum(self.font(size, bold, ch in SYMBOLS).getlength(ch) for ch in text) / self.s

    def text(self, d, x, y, text, size=13, fill=None, bold=False, spacing=0.0):
        fill = fill or self.c["fg"]
        cx = x
        for ch in text:
            ch = "+" if ch == "＋" else ch   # в браузере подставится системный глиф
            f = self.font(size, bold, ch in SYMBOLS)
            d.text((cx * self.s, y * self.s), ch, font=f, fill=fill)
            cx += f.getlength(ch) / self.s + spacing
        return cx

    def trunc(self, text, size, maxw, bold=False):
        if self.width(text, size, bold) <= maxw:
            return text
        while text and self.width(text + "…", size, bold) > maxw:
            text = text[:-1]
        return text + "…"

    def wrap(self, text, size, maxw):
        out, cur = [], ""
        for ch in text:
            if self.width(cur + ch, size) > maxw and cur:
                out.append(cur)
                cur = ch
            else:
                cur += ch
        return out + ([cur] if cur or not out else [])

    def rect(self, d, x0, y0, x1, y1, fill=None, outline=None, r=4):
        d.rounded_rectangle([x0 * self.s, y0 * self.s, x1 * self.s, y1 * self.s], radius=r * self.s, fill=fill, outline=outline,
                            width=max(1, round(self.s)))

    def button(self, d, x, y, label, size=12):
        w = self.width(label, size) + 16
        self.rect(d, x, y, x + w, y + 20, fill=self.c["panel2"], outline=self.c["line"])
        self.text(d, x + 8, y + 3, label, size)
        return w


FRAME_SOURCE = None   # список исходных строк кадров (для целей курсора вида {"hit": ..., "at": N})
_HITS_CACHE = {}


class Page:
    def __init__(self, dump, scale, max_h, viewport_h=None):
        self.dump, self.S, self.max_h, self.viewport_h = dump, scale, max_h, viewport_h
        self.p = Painter(scale, dump["theme"])
        self.c = self.p.c
        self.hits = {}          # ключ -> (x0, y0, x1, y1) в CSS-пикселях страницы: куда можно «кликнуть мышкой»
        self.origin = (0, 0)    # смещение содержимого текущего виджета на странице

    def hit(self, key, x, y, w, h):
        ox, oy = self.origin
        self.hits[key] = (ox + x, oy + y, ox + x + w, oy + y + h)

    # ---------- содержимое виджета ----------
    def body(self, node, width, avail):
        """Рисует содержимое на высоком временном холсте. Возвращает (изображение, использованная высота)."""
        p, c, S = self.p, self.c, self.S
        img = Image.new("RGB", (round(width * S), round(2600 * S)), c["panel"])
        d = ImageDraw.Draw(img)
        y = 0.0
        for n in node["children"]:
            y = self.child(d, n, y, width, avail)
        return img, y

    def child(self, d, n, y, w, avail):
        p, c = self.p, self.c
        k = cls(n)
        if n["tag"] == "table" and "kv" in k:
            for tr in n["children"]:
                kk, vv = text_of(tr["children"][0]), text_of(tr["children"][1])
                kw = p.width(kk, 13) + 10
                lines = p.wrap(vv, 13, w - kw) or [""]
                p.text(d, 0, y, kk, 13, c["dim"])
                for i, line in enumerate(lines):
                    p.text(d, w - p.width(line, 13), y + i * 16, line, 13)
                y += len(lines) * 16 + 3
            return y
        if "row" in k:
            return self.row(d, n, y, w)
        if "counter-value" in k:
            t = text_of(n)
            p.text(d, (w - p.width(t, 40)) / 2, y, t, 40, c["acc"])
            return y + 54
        if "counter-label" in k:
            t = text_of(n)
            p.text(d, (w - p.width(t, 13)) / 2, y, t, 13, c["dim"])
            return y + 22
        if "actions" in k:
            ws = [p.width(text_of(b), 12) + 16 for b in n["children"]]
            x = (w - sum(ws) - 6 * (len(ws) - 1)) / 2
            for b in n["children"]:
                self.hit("act:" + text_of(b), x, y, p.width(text_of(b), 12) + 16, 20)
                x += p.button(d, x, y, text_of(b)) + 6
            return y + 28
        if "note" in k:
            t = text_of(n)
            p.text(d, (w - p.width(t, 11)) / 2, y, t, 11, c["dim"])
            return y + 18
        if "logbar" in k:
            sel = n["children"][0]["children"][0] if n["children"] and n["children"][0]["children"] else None
            label = text_of(sel) if sel else "all"
            bw = p.width(label, 12) + 30
            p.rect(d, 0, y, bw, y + 22, fill=c["panel2"], outline=c["line"])
            p.text(d, 6, y + 3, label, 12)
            p.text(d, bw - 16, y + 3, "v", 12, c["dim"])
            return y + 28
        if "loglines" in k:
            return self.log(d, n, y, w, avail)
        if n["tag"] == "canvas":
            hgt = 70
            for path in n.get("paths") or []:
                pts = [(x * (w / 600.0), y + yy * (hgt / 100.0)) for x, yy in path["pts"]]
                if len(pts) > 1:
                    d.line([(a * self.S, b * self.S) for a, b in pts], fill=path["color"], width=round(2 * self.S), joint="curve")
            return y + hgt + 4
        if "legend" in k:
            for line in p.wrap(text_of(n), 11, w):
                p.text(d, 0, y, line, 11, c["dim"])
                y += 15
            return y + 2
        dot = [ch for ch in n["children"] if ch["tag"] == "span" and "dot" in cls(ch)]
        t = "".join(text_of(ch) for ch in n["children"] if ch not in dot) if dot else text_of(n)
        color = c["bad"] if "err" in k else c["dim"] if "dim" in k else c["fg"]
        x = 0
        if dot:
            self.dot(d, 0, y, cls(dot[0]))
            x = 14
        for line in p.wrap(t, 13, w - x):
            p.text(d, x, y, line, 13, color)
            y += 17
        return y + 2

    def dot(self, d, x, y, k):
        col = self.c["ok"] if "ok" in k else self.c["warn"] if "warn" in k else self.c["bad"] if "bad" in k else self.c["dim"]
        d.ellipse([x * self.S, (y + 5) * self.S, (x + 8) * self.S, (y + 13) * self.S], fill=col)

    def row(self, d, n, y, w):
        p, c = self.p, self.c
        kids = n["children"]
        dots = [k for k in kids if k["tag"] == "span" and "dot" in cls(k)]
        btn_group = [k for k in kids if k["tag"] == "span" and any(ch["tag"] == "button" for ch in k["children"])]
        dim = [k for k in kids if "dim" in cls(k)]
        main = [k for k in kids if k not in dots + btn_group + dim]
        right = w
        h = 22
        if btn_group:
            h = 26
            labels = [text_of(b) for b in btn_group[0]["children"]]
            owner = (n.get("attrs") or {}).get("data-owner") or (text_of(main[0]).split()[0] if main and text_of(main[0]).split() else "")
            for lab in reversed(labels):
                bw = p.width(lab, 12) + 16
                right -= bw
                self.hit(f"plug:{owner}:{lab}", right, y, bw, 20)
                p.button(d, right, y, lab)
                right -= 6
        if dim:
            t = text_of(dim[0])
            right -= p.width(t, 11)
            p.text(d, right, y + 3, t, 11, c["dim"])
            right -= 10
        x = 0
        if dots:
            self.dot(d, 0, y + (2 if btn_group else 0), cls(dots[0]))
            x = 14
        t = "".join(text_of(m) for m in main)
        p.text(d, x, y + (3 if btn_group else 0), p.trunc(t, 13, max(20, right - x)), 13)
        return y + h

    def log(self, d, n, y, w, avail):
        p, c = self.p, self.c
        rows = []
        for ln in n["children"]:
            k = cls(ln)
            kids = ln["children"]
            ts, tx = text_of(kids[0]), "".join(text_of(x) for x in kids[1:])
            color = c["bad"] if "bad" in k else c["warn"] if "warn" in k else c["acc"] if "core" in k else c["fg"]
            tsw = p.width(ts, 11) + 6
            wrapped = p.wrap(tx, 11, w - tsw)
            rows.append((ts, wrapped, color, tsw))
        total = sum(len(r[1]) for r in rows) * 14
        room = max(14, avail - y)
        skip = max(0, total - room)   # прокручено вниз: видны последние строки
        yy = y - skip
        for ts, wrapped, color, tsw in rows:
            for i, line in enumerate(wrapped):
                if yy >= y - 1:
                    if i == 0:
                        p.text(d, 0, yy, ts, 11, c["dim"])
                    p.text(d, tsw, yy, line, 11, color)
                yy += 14
        return y + min(total, room)

    # ---------- страница ----------
    def widget(self, img, n, x, y, w, h, stacked):
        p, c, S = self.p, self.c, self.S
        d = ImageDraw.Draw(img)
        head, body = n["children"][0], n["children"][1]
        title = text_of(head["children"][0]).upper()
        cw = w - 2 - 16
        avail = (h - 26 - 14) if h else (self.max_h * 0.7 - 26 - 14)
        self.origin = (x + 9, y + 26 + 6)
        bimg, used = self.body(body, cw, avail)
        if h is None:
            h = min(26 + 12 + used + 6, self.max_h * 0.7)
        dragging = "dragging" in cls(n) or "flash" in cls(n)   # вспышка узла от события выглядит как поднятый виджет
        if dragging:   # поднятый виджет: светящаяся рамка
            p.rect(d, x - 3, y - 3, x + w + 3, y + h + 3, outline=self.mix(c["acc"], c["bg"], 0.55), r=6)
        p.rect(d, x, y, x + w, y + h, fill=c["panel"], outline=c["acc"] if dragging else c["line"])
        group = next((k[4:] for k in cls(n) if k.startswith("grp-")), None)
        if group in GROUP_COLOR:
            d.line([(x + 4) * S, (y + 1) * S, (x + w - 4) * S, (y + 1) * S], fill=GROUP_COLOR[group], width=max(2, round(2 * S)))
        d.line([(x + 1) * S, (y + 26) * S, (x + w - 1) * S, (y + 26) * S], fill=c["line"], width=max(1, round(S)))
        p.text(d, x + 8, y + 6, p.trunc(title, 11, w - 40), 11, c["acc"], spacing=1.0)
        p.text(d, x + w - 20, y + 5, "✕", 12, c["dim"])
        crop_h = max(1, round((h - 26 - 12) * S))
        img.paste(bimg.crop((0, 0, bimg.width, min(bimg.height, crop_h))), (round((x + 9) * S), round((y + 26 + 6) * S)))
        if not stacked:
            d.polygon([((x + w - 1) * S, (y + h - 14) * S), ((x + w - 1) * S, (y + h - 1) * S), ((x + w - 14) * S, (y + h - 1) * S)], fill=c["line"])
        if "off" in cls(n):   # выключенный узел: приглушён
            box = (max(0, round((x - 1) * S)), max(0, round((y - 1) * S)), min(img.width, round((x + w + 1) * S)), min(img.height, round((y + h + 1) * S)))
            if box[2] > box[0] and box[3] > box[1]:
                region = img.crop(box)
                img.paste(Image.blend(region, Image.new("RGB", region.size, c["bg"]), 0.52), box[:2])
        return h

    def topbar(self, img, W):
        p, c, S = self.p, self.c, self.S
        d = ImageDraw.Draw(img)
        x, y, rowh = 12, 10, 28
        items = []
        for n in self.dump["topbar"]["children"]:
            items.append((cls(n), n["tag"], text_of(n)))
        status = [i for i in items if "status" in i[0]]
        for k, tag, t in items:
            if "status" in k:
                continue
            if "brand" in k:
                x = p.text(d, x, y + 4, t, 14, c["fg"], bold=True) + 10
            elif "badge" in k:
                bw = p.width(t, 11) + 12
                p.rect(d, x, y + 4, x + bw, y + 22, outline=c["line"])
                p.text(d, x + 6, y + 6, t, 11, c["acc"])
                x += bw + 10
            else:
                bw = p.width(t, 13) + 16
                self.origin = (0, 0)
                self.hit("top:" + t, x, y + 1, bw, 24)
                active = "active" in k
                p.rect(d, x, y + 1, x + bw, y + 25, fill=c["panel"] if active else c["panel2"], outline=c["acc"] if active else c["line"])
                p.text(d, x + 8, y + 4, t, 13, c["acc"] if active else None)
                x += bw + 8
        if status:
            t = status[0][2]
            if W - 12 - p.width(t, 12) > x + 8:
                p.text(d, W - 12 - p.width(t, 12), y + 5, t, 12, c["dim"])
            else:
                rowh = 52
                p.text(d, W - 12 - p.width(t, 12), y + 33, t, 12, c["dim"])
        d.line([0, (rowh + 14) * S, W * S, (rowh + 14) * S], fill=c["line"], width=max(1, round(S)))
        return rowh + 15

    @staticmethod
    def mix(a, b, t):
        pa, pb = [int(a[i:i + 2], 16) for i in (1, 3, 5)], [int(b[i:i + 2], 16) for i in (1, 3, 5)]
        return "#" + "".join(f"{round(x * t + y * (1 - t)):02x}" for x, y in zip(pa, pb))

    def render_base(self):
        S, c, dump = self.S, self.c, self.dump
        W = dump["width"] + 20   # ширина окна = ширина доски + поля по 10 px
        stacked = dump["boardClass"] == "stack"
        widgets = [n for n in dump["widgets"] if n["tag"] == "section"]   # слой нитей (canvas) пропускаем
        top_h = 44
        if stacked:
            sizes = []
            for n in widgets:   # сначала измеряем высоты
                bimg, used = self.body(n["children"][1], W - 20 - 18, self.max_h * 0.7)
                sizes.append(min(26 + 12 + used + 6, self.max_h * 0.7))
            total = top_h + 12 + sum(sizes) + 8 * len(sizes) + 10
        else:
            board_h = px(dump["boardStyle"].get("height"), 600)
            total = top_h + 10 + board_h + 10
        H = self.viewport_h or (min(total, self.max_h) if self.max_h else total)
        fancy = dump.get("background") == "space" and not stacked
        img = self.fancy_background(W, H) if fancy else Image.new("RGB", (round(W * S), round(H * S)), c["bg"])
        top_h = self.topbar(img, W)
        d = ImageDraw.Draw(img)
        if stacked:
            y = top_h + 10
            for n in widgets:
                if y > H:
                    break
                y += self.widget(img, n, 10, y, W - 20, None, True) + 8
        else:
            ox, oy, cell = 10, top_h + 10, dump["cellW"]
            self.board_xy = (ox, oy)
            if not fancy:
                gx = 0.0
                while gx < W - 20:
                    d.line([(ox + gx) * S, oy * S, (ox + gx) * S, H * S], fill=c["grid"], width=1)
                    gx += cell
                gy = 0.0
                while oy + gy < H:
                    d.line([ox * S, (oy + gy) * S, (W - 10) * S, (oy + gy) * S], fill=c["grid"], width=1)
                    gy += 30
            drag_id = next((n["id"][2:] for n in widgets if "dragging" in cls(n)), None)
            img = self.draw_threads(img, ox, oy, drag_id)
            self.widget_hits = {}
            ordered = sorted(widgets, key=lambda n: "dragging" in cls(n))   # поднятый виджет рисуется поверх остальных
            for n in ordered:
                st = n["style"]
                self.widget(img, n, ox + px(st.get("left")), oy + px(st.get("top")), px(st.get("width")), px(st.get("height")), False)
        ov = dump.get("overlay")
        if ov and not ov.get("hidden") and ov["children"]:
            img = self.modal(img, ov["children"][0], W, H)
        return img

    def render(self):
        img = self.render_base()
        self.cursor(img, img.width / self.S, img.height / self.S)
        return img

    def modal(self, img, node, W, H):
        p, c, S = self.p, self.c, self.S
        dim = Image.new("RGBA", img.size, (0, 0, 0, 150))
        img = Image.alpha_composite(img.convert("RGBA"), dim).convert("RGB")
        d = ImageDraw.Draw(img)
        kids = node["children"]
        title = text_of(kids[0]).upper()
        buttons = [b for b in (kids[-1]["children"] if cls(kids[-1]) & {"buttons"} else [])]
        content = [k for k in kids[1:] if not (cls(k) & {"buttons"})]
        mw = 340
        lines = []
        for k in content:
            lines += p.wrap(text_of(k), 13, mw - 28)
        mh = 14 + 20 + len(lines) * 18 + 10 + 30 + 14
        x0, y0 = (W - mw) / 2, (H - mh) / 2
        p.rect(d, x0, y0, x0 + mw, y0 + mh, fill=c["panel"], outline=c["line"], r=6)
        p.text(d, x0 + 14, y0 + 12, title, 13, c["acc"], spacing=1.0)
        yy = y0 + 38
        for line in lines:
            p.text(d, x0 + 14, yy, line, 13)
            yy += 18
        right = x0 + mw - 14
        for b in reversed(buttons):
            lab = text_of(b)
            bw = p.width(lab, 12) + 16
            right -= bw
            self.hits["modal:" + lab] = (right, yy + 12, right + bw, yy + 32)
            p.rect(d, right, yy + 12, right + bw, yy + 32, fill=c["panel2"], outline=c["line"])
            p.text(d, right + 8, yy + 15, lab, 12)
            right -= 8
        return img

    def fancy_background(self, W, H):
        """Большой фон: мягкое свечение в центре, точечная сетка, виньетка по краям."""
        S, c = self.S, self.c
        size = (round(W * S), round(H * S))
        img = Image.new("RGB", size, c["bg"])
        grad = Image.radial_gradient("L").resize(size, Image.BILINEAR)   # чёрный центр, белые края
        img.paste(Image.new("RGB", size, self.mix(c["acc"], c["bg"], 0.10)), (0, 0), ImageOps.invert(grad).point(lambda v: int(v * 0.55)))
        d = ImageDraw.Draw(img)
        dot = self.mix(c["dim"], c["bg"], 0.35)
        for gx in range(18, round(W), 30):
            for gy in range(18, round(H), 30):
                d.point((gx * S, gy * S), fill=dot)
                if S >= 1.5:
                    d.point((gx * S + 1, gy * S), fill=dot)
        img.paste((0, 0, 0), (0, 0, size[0], size[1]), grad.point(lambda v: int(max(0, v - 100) * 0.55)))
        return img

    @staticmethod
    def sample(p, n=48):
        pts = []
        for i in range(n + 1):
            t = i / n
            u = 1 - t
            a, b, c3, d4 = u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t
            pts.append((a * p[0][0] + b * p[1][0] + c3 * p[2][0] + d4 * p[3][0], a * p[0][1] + b * p[1][1] + c3 * p[2][1] + d4 * p[3][1]))
        return pts

    @staticmethod
    def rgb(h):
        return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))

    def draw_threads(self, img, ox, oy, dragging_id):
        """Светящиеся нити между виджетами (бегущие импульсы рисуются отдельно, поверх, для каждого кадра)."""
        ths = self.dump.get("threads") or []
        if not ths:
            return img
        S, c = self.S, self.c
        glow = Image.new("RGBA", img.size, (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow)
        lines = []
        for th in ths:
            hot = dragging_id and dragging_id in (th["a"], th["b"])
            off = th.get("off")
            col = KIND_RGB.get(th["kind"]) or self.rgb(c["ok"] if th["kind"] == "module" else c["acc"])
            pts = [((ox + x) * S, (oy + y) * S) for x, y in self.sample(th["p"])]
            gd.line(pts, fill=col + (14 if off else 120 if hot else 62,), width=round((11 if hot else 7) * S), joint="curve")
            lines.append((pts, col, hot, off, th))
        glow = glow.filter(ImageFilter.GaussianBlur(3 * S))
        img = Image.alpha_composite(img.convert("RGBA"), glow).convert("RGB")
        d = ImageDraw.Draw(img)
        for pts, col, hot, off, th in lines:
            line_col = self.mix("#%02x%02x%02x" % col, c["bg"], 0.95 if hot else 0.22 if off else 0.62)
            d.line(pts, fill=line_col, width=max(1, round((2.2 if hot else 1.5) * S)), joint="curve")
            for x, y in (pts[0], pts[-1]):
                r = 3.2 * S
                d.ellipse([x - r, y - r, x + r, y + r], fill=line_col)
        for pts, col, hot, off, th in lines:   # подписи связей поверх всех нитей
            label = th.get("label")
            if label and not off and th.get("kind") != "manage":
                mx, my = pts[len(pts) // 2]
                w = self.p.width(label, 10) + 8
                d.rectangle([mx - w / 2 * S, my - 8 * S, mx + w / 2 * S, my + 6 * S], fill=c["bg"])
                self.p.text(d, mx / S - w / 2 + 4, my / S - 7, label, 10, self.mix(c["fg"], c["bg"], 0.7))
        return img

    def resolve(self, spec):
        if not spec:
            return None
        if "abs" in spec:
            return tuple(spec["abs"])
        hits = self.hits
        if "at" in spec and FRAME_SOURCE is not None:   # курсор остаётся там, где был клик, даже если кнопка исчезла
            if spec["at"] not in _HITS_CACHE:
                page = Page(json.loads(FRAME_SOURCE[spec["at"]]), self.S, 100000, self.viewport_h)
                page.render()
                _HITS_CACHE[spec["at"]] = page.hits
            hits = _HITS_CACHE[spec["at"]]
        box = hits.get(spec["hit"])
        return ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2) if box else None

    def cursor(self, img, W, H):
        cur = self.dump.get("cursor")
        if not cur:
            return
        a, b = self.resolve(cur.get("from")), self.resolve(cur.get("to"))
        a = a or b
        b = b or a
        if not a:
            return
        t = cur.get("t", 1.0)
        e = t * t * (3 - 2 * t)   # плавное начало и конец движения
        x, y = a[0] + (b[0] - a[0]) * e, a[1] + (b[1] - a[1]) * e
        S, d = self.S, ImageDraw.Draw(img)
        rip = self.dump.get("ripple")
        if rip is not None:   # круг от клика
            r = 6 + rip * 18
            col = self.mix(self.c["acc"], self.c["bg"], 1 - rip)
            d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], outline=col, width=max(2, round(2 * S)))
        shape = [(0, 0), (0, 17), (4.2, 13.2), (7.4, 20), (10.2, 18.8), (7.1, 12.2), (12.5, 12.2)]
        pts = [((x + px_) * S, (y + py_) * S) for px_, py_ in shape]
        d.polygon([(px_ + 1.2 * S, py_ + 1.4 * S) for px_, py_ in pts], fill="#000000")   # тень
        d.polygon(pts, fill="#ffffff", outline="#000000")
        if cur.get("down"):
            d.ellipse([(x - 3) * S, (y - 3) * S, (x + 3) * S, (y + 3) * S], fill=self.c["acc"])


def render_frame(dump, scale=1.0, viewport_h=None):
    return Page(dump, scale, 100000, viewport_h).render()


def main():
    dump = json.load(open(sys.argv[1], encoding="utf-8"))
    scale = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
    max_h = float(sys.argv[4]) if len(sys.argv) > 4 else 0
    img = Page(dump, scale, max_h or 100000).render()
    img.save(sys.argv[2])
    print(f"{sys.argv[2]}: {img.width}x{img.height}")


if __name__ == "__main__":
    main()
