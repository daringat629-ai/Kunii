// Запускает настоящий код панели (app.js + layout.js) на демо-данных и печатает дерево элементов с позициями в JSON.
//   node render_dump.js <ширина_px> <dark|light> <ru|en>  > dump.json
process.env.TZ = 'Asia/Bishkek';
const path = require('path');
const { Document, Node } = require('../tests/js/dom_stub.js');
const L = require('../zerocore/admin/web/layout.js');
const app = require('../zerocore/admin/web/app.js');

const width = parseInt(process.argv[2] || '1440', 10), theme = process.argv[3] || 'dark', lang = process.argv[4] || 'ru';

// canvas: записываем линии, чтобы нарисовать график
Node.prototype.getContext = function () {
  const self = this; self.paths = self.paths || []; let cur = null;   // холст хранит нарисованное между вызовами
  self.width = Number(self.attrs.width) || 300; self.height = Number(self.attrs.height) || 150;   // в браузере свойства отражают атрибуты
  const ctx = { strokeStyle: '#fff', lineWidth: 1,
    beginPath() { cur = { color: ctx.strokeStyle, w: ctx.lineWidth, pts: [] }; self.paths.push(cur); },
    moveTo(x, y) { cur.pts.push([x, y]); }, lineTo(x, y) { cur.pts.push([x, y]); }, stroke() {} };
  return new Proxy(ctx, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } });
};

const base = Date.UTC(2026, 9, 9, 7, 52, 0) / 1000;   // 2026-10-09 13:52 по Бишкеку
const series = Array.from({ length: 72 }, (_, i) => ({ t: base - (72 - i) * 5,
  load1: +(0.35 + 0.25 * Math.sin(i / 6) + (i > 50 ? 0.55 * Math.sin((i - 50) / 3) ** 2 : 0)).toFixed(2),
  mem: +(41 + 3 * Math.sin(i / 9) + i * 0.04).toFixed(1), rss: 612 + Math.round(8 * Math.sin(i / 5)) }));
const logs = [
  [0, 'core', 'module.started {"module": "kuni"}'], [3, 'kuni', '[13:47:12][UI thread][App][INFO]: Bot is up and running. Press enter (or send SIGINT/SIGTERM) to shutdown gracefully.'],
  [70, 'kuni', '[13:48:22][UI thread][tools::external][INFO]: Loaded 2 external tool(s): demo_echo, demo_add'],
  [95, 'core', 'tools.exported {"count": 2, "problems": 0}'], [140, 'kuni', '[13:50:03][UI thread][tools::shell][WARN]: EXEC: date'],
  [141, 'kuni', '[13:50:04][UI thread][send_telegram_message][INFO]: Synthetic typing delay: 1200ms'],
  [190, 'kuni', '[13:51:00][UI thread][tools::external][INFO]: CALL demo_tools/demo_add'],
  [230, 'kuni', '[13:51:40][UI thread][OpenAITools][WARN]: tool call refused: Refused: you have called `query` with exactly the same arguments 4 times in a row.'],
  [232, 'kuni', '[13:51:41][UI thread][OpenAIChat][WARN]: chatStreaming: status=HTTP_429_TOO_MANY_REQUESTS'],
  [260, 'core', 'job.failed {"module": "watchdog", "rc": 1}'], [300, 'core', 'config.changed {"module": "kuni"}'],
  [320, 'kuni', '[13:52:10][UI thread][App][INFO]: Processing notification: You received a direct message']].map(([dt, src, text]) => ({ t: base - 330 + dt, src, text }));
const tools = ['ask', 'demo_add', 'demo_echo', 'edit_message_text', 'forward_message', 'get_chat_photo', 'get_telegram_chats', 'open_chat_by_id',
  'pause', 'react_with_emoji', 'record_audio', 'remove_and_ban_chat', 'remove_message', 'search_chats', 'send_telegram_message', 'shell',
  'sticker_list', 'sticker_save', 'sticker_send', 'take_photo'].map(n => ({ name: n, description: n }));
const mod = (name, version, kind, enabled, running, health, widgets = []) => ({ name, version, kind, enabled, running, health, detail: '', provides: [], widgets });
const modules = [
  mod('demo_counter', '1.0.0', 'library', true, false, 'unknown', [{ id: 'counter', title: 'Demo counter', kind: 'counter', refresh: 5, size: { w: 6, h: 6 } }]),
  mod('demo_tools', '1.0.0', 'library', true, false, 'unknown'), mod('kuni', '0.0.2', 'external', true, true, 'healthy'),
  mod('watchdog', '2.0.0', 'job', true, false, 'healthy', [{ id: 'status', title: 'Предохранитель', kind: 'kv', refresh: 10, size: { w: 8, h: 6 } }]),
  mod('webview', '1.0.0', 'service', false, false, 'unhealthy'), mod('world_v2', '2.0.0', 'library', true, false, 'healthy')];
const data = {
  '/api/system': { zerocore: '0.1.0', python: '3.12.3', os: 'Linux (x86_64)', pid: 4120, home: '/home/marinka/zero_core_home', uptime: 18720, modules: 6, enabled: 5, integrity: [], host: { load1: 0.62, mem_pct: 43.5 } },
  '/api/llm': { available: true, provider: 'openrouter', model: 'deepseek/deepseek-v4-flash', host: 'https://openrouter.ai', embedding_model: 'qwen3-embedding', embedding_host: 'http://localhost:11434', lockdown: 'none' },
  '/api/transports': [{ name: 'kuni', capability: 'telegram.bot', running: true, health: 'healthy' }],
  '/api/stats': { llm_requests_today: 214, shell_commands: 3, messages_sent: 41, external_calls: 7, guard_refusals: 1, llm_http_errors: 1, errors: 0 },
  '/api/generation': { known: true, active: false, last_seconds: 4.2, ago: 38 }, '/api/metrics': series, '/api/tools': tools, '/api/log': logs, '/api/modules': modules,
  '/api/widget/demo_counter/counter': { ok: true, kind: 'counter', title: 'Demo counter', data: { value: 229, label: 'кликов' }, actions: [{ id: 'plus10', label: '+10' }, { id: 'reset', label: 'Сброс' }], note: '+10 → 229' },
  '/api/widget/watchdog/status': { ok: true, kind: 'kv', title: 'Предохранитель', data: { items: [['последний запуск', '41 с назад'], ['код возврата', '0'], ['остановок бота', '2'], ['последняя остановка', '2026-10-09 09:14:02 зацикливание: 15 запусков shell за 180 с']] }, actions: [], note: null },
};
const doc = new Document();
doc.board.rect.width = width;
const settings = { language: lang, theme, log_lines: 200, layout: {}, hidden: [] };
const fetch = async (p, init) => {
  const reply = (s, b) => ({ status: s, ok: s < 400, json: async () => b });
  if (p === '/api/settings') return reply(200, settings);
  if (p.startsWith('/api/log')) return reply(200, data['/api/log']);
  return data[p] ? reply(200, data[p]) : reply(404, { error: 'nf' });
};
const env = { document: doc, fetch, storage: { getItem: () => 'tok', setItem() {} }, setInterval: () => 0, setTimeout: () => 0, clearTimeout() {},
  confirm: () => true, Layout: L, window: { addEventListener() {} } };
(async () => {
  const a = app.boot(env); await a.started; for (let i = 0; i < 20; i++) await new Promise(r => setImmediate(r));
  const ser = n => n.tag === '#text' ? { tag: '#text', text: n._text } : { tag: n.tag, cls: n.className, id: n.id, text: n._text, style: n.style, attrs: n.attrs, hidden: n.hidden,
    paths: n.paths || null, children: n.children.map(ser) };
  process.stdout.write(JSON.stringify({ width, theme, lang, bodyClass: doc.body.className, boardClass: doc.board.className, boardStyle: doc.board.style,
    cellW: a.S.cellW, topbar: ser(doc.topbar), widgets: doc.board.children.map(ser) }));
})();
