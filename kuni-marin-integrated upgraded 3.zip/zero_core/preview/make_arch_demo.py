#!/usr/bin/env python3
"""Демо-данные архитектуры: настоящий architecture.build на настоящих манифестах репозитория; подменено только состояние процессов.
  python3 make_arch_demo.py > arch_demo.json"""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from zerocore.admin import architecture  # noqa: E402
from zerocore.kernel.contracts import Manifest  # noqa: E402

# что «запущено» в демо: имя -> (включён, работает, здоровье)
STATE = {"kuni": (True, True, "healthy"), "watchdog": (True, False, "healthy"), "world_v2": (True, False, "healthy"),
         "webview": (False, False, "unknown"), "demo_counter": (True, False, "unknown"), "demo_tools": (True, False, "unknown")}


class Bus:
    def recent(self, n):
        return [{}] * 128


class FakeManager:
    def __init__(self, tmp):
        self.mans = {}
        for p in sorted((ROOT / "modules").glob("*/manifest.json")):
            m = Manifest.from_dict(json.loads(p.read_text(encoding="utf-8")))
            self.mans[m.name] = m
        self.bus = Bus()
        self._tools = Path(tmp) / "tools.json"
        self._tools.write_text(json.dumps({"version": 1, "tools": [{"name": "demo_echo"}, {"name": "demo_add"}]}))

    def status(self):
        rows = []
        for n, m in sorted(self.mans.items()):
            en, run, health = STATE[n]
            rows.append({"name": n, "version": m.version, "enabled": en, "versions": [m.version], "kind": m.kind, "provides": m.provides,
                         "running": run, "health": health, "detail": ""})
        return rows

    def enabled_names(self):
        return [n for n, st in STATE.items() if st[0]]

    def manifest(self, name):
        return self.mans[name]

    def check_integrity(self):
        return []

    def tools_path(self):
        return self._tools


with tempfile.TemporaryDirectory() as tmp:
    cfg = Path(tmp) / "config.toml"
    cfg.write_text('[general]\nlockdown = "papik_only"\n[general.llm]\nmodel = "deepseek/deepseek-v4-flash"\nendpoint.baseUrl = "https://openrouter.ai/api/v1/"\n')
    graph = architecture.build(FakeManager(tmp), str(cfg))
print(json.dumps(graph, ensure_ascii=False))
