#!/usr/bin/env python3
"""Видео на 60 кадров/с из render_video60_dump.js.
Основа страницы (фон, нити, виджеты) рисуется один раз на каждое состояние и кэшируется; на каждый кадр накладываются
бегущие импульсы, эффект клика и курсор, кадры идут прямо в ffmpeg.
  python3 render_video60.py frames.jsonl prepare [секунд_на_запуск]      # основы состояний (можно повторять)
  python3 render_video60.py frames.jsonl frame N out.png                  # один кадр для проверки
  python3 render_video60.py frames.jsonl encode out.mp4                   # собрать видео
Переменные: ZC_CACHE (папка кэша, по умолчанию /tmp/zc60), ZC_SCALE (1.0), ZC_VIEWPORT (1080)."""
import json
import math
import os
import subprocess
import sys
import time

from PIL import Image, ImageDraw

import render_png as rp

CACHE = os.environ.get("ZC_CACHE", "/tmp/zc60")
SCALE = float(os.environ.get("ZC_SCALE", "1.0"))
VIEWPORT = int(os.environ.get("ZC_VIEWPORT", "1080"))
FPS = 60


class Store:
    def __init__(self, path):
        self.states, self.frames = {}, []
        for line in open(path, encoding="utf-8"):
            if not line.strip():
                continue
            o = json.loads(line)
            if o["k"] == "s":
                self.states[o["id"]] = o["dom"]
            else:
                self.frames.append(o)
        os.makedirs(CACHE, exist_ok=True)
        self._hits, self._img = {}, {}

    def png(self, sid):
        return os.path.join(CACHE, f"s{sid:04d}.png")

    def meta(self, sid):
        return os.path.join(CACHE, f"s{sid:04d}.json")

    def ready(self, sid):
        return os.path.exists(self.png(sid)) and os.path.exists(self.meta(sid))

    def build(self, sid):
        page = rp.Page(self.states[sid], SCALE, 100000, VIEWPORT)
        img = page.render_base()
        img.save(self.png(sid) + ".tmp", format="PNG", compress_level=1)
        os.replace(self.png(sid) + ".tmp", self.png(sid))
        with open(self.meta(sid), "w") as f:
            json.dump({"hits": page.hits, "origin": list(getattr(page, "board_xy", (10, 53)))}, f)

    def hits(self, sid):
        if sid not in self._hits:
            self._hits[sid] = json.load(open(self.meta(sid)))
        return self._hits[sid]

    def base(self, sid):
        if sid not in self._img:
            if len(self._img) > 4:
                self._img.clear()
            self._img[sid] = Image.open(self.png(sid)).convert("RGB")
        return self._img[sid]


def ease(t):
    return t * t * (3 - 2 * t)


def resolve(store, spec, sid):
    if not spec:
        return None
    if "abs" in spec:
        return tuple(spec["abs"])
    box = store.hits(spec.get("state", sid))["hits"].get(spec["hit"])
    return ((box[0] + box[2]) / 2, (box[1] + box[3]) / 2) if box else None


def bezier(p, t):
    u = 1 - t
    a, b, c, d = u * u * u, 3 * u * u * t, 3 * u * t * t, t * t * t
    return (a * p[0][0] + b * p[1][0] + c * p[2][0] + d * p[3][0], a * p[0][1] + b * p[1][1] + c * p[2][1] + d * p[3][1])


def over(img, box, draw_fn):
    """Рисует полупрозрачное на маленьком участке: draw_fn получает RGBA-слой размером с участок и его смещение."""
    x0, y0, x1, y1 = [int(round(v)) for v in box]
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(img.width, x1), min(img.height, y1)
    if x1 <= x0 or y1 <= y0:
        return
    layer = Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(layer), x0, y0)
    region = img.crop((x0, y0, x1, y1)).convert("RGBA")
    region.alpha_composite(layer)
    img.paste(region.convert("RGB"), (x0, y0))


def glow_dot(img, x, y, core, glow, color, strong=1.0):
    S = SCALE
    R = glow * S

    def fn(d, ox, oy):
        cx, cy = x * S - ox, y * S - oy
        steps = 7
        for i in range(steps, 0, -1):
            r = core * S + (R - core * S) * i / steps
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color + (int(55 * strong * (1 - i / steps) + 10),))
        r = core * S
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(255, 255, 255, 235))
    over(img, ((x - glow - 2) * S, (y - glow - 2) * S, (x + glow + 2) * S, (y + glow + 2) * S), fn)


def draw_pulses(img, store, frame, dom, origin):
    c = rp.THEMES[dom["theme"]]
    ox, oy = origin
    drag = next((n["id"][2:] for n in dom["widgets"] if n["tag"] == "section" and "dragging" in (n.get("cls") or "")), None)
    for i, th in enumerate(dom.get("threads") or []):
        if th.get("off"):
            continue   # у выключенного модуля импульсов нет
        hot = drag and drag in (th["a"], th["b"])
        col = rp.KIND_RGB.get(th["kind"]) or rp.Page.rgb(c["ok"] if th["kind"] == "module" else c["acc"])
        for k in (0, 1):
            t = ((frame["t"] * 0.16) + i * 0.31 + k * 0.5) % 1
            x, y = bezier(th["p"], t)
            glow_dot(img, ox + x, oy + y, 2.0 if not hot else 2.8, 9 if not hot else 13, col, 1.6 if hot else 1.0)


def draw_bursts(img, frame, dom, origin):
    """Яркие «кометы» настоящих событий: бегут по нити в направлении события, красные для ошибок."""
    ox, oy = origin
    for bu in frame.get("bursts") or []:
        th = next((t for t in dom.get("threads") or [] if t["a"] == bu["a"] and t["b"] == bu["b"]), None)
        if not th:
            continue
        col = (255, 107, 107) if bu["level"] == "error" else (200, 225, 255)
        for k in range(3, -1, -1):
            tt = bu["age"] - k * 0.05
            if tt < 0:
                continue
            x, y = bezier(th["p"], tt if bu["forward"] else 1 - tt)
            glow_dot(img, ox + x, oy + y, 4.6 if k == 0 else 3.4 - k * 0.6, 17 if k == 0 else 9, col, 3.2 if k == 0 else 1.2)


def draw_caption(img, frame, dom):
    text = frame.get("caption")
    if not text:
        return
    c = rp.THEMES[dom["theme"]]
    page = rp.Page(dom, SCALE, 100000, VIEWPORT)
    w = page.p.width(text, 16) + 36
    W, H = img.width / SCALE, img.height / SCALE
    x0, y0 = (W - w) / 2, H - 58
    d = ImageDraw.Draw(img)
    page.p.rect(d, x0, y0, x0 + w, y0 + 34, fill=c["panel"], outline=c["line"], r=8)
    page.p.text(d, x0 + 18, y0 + 8, text, 16, c["fg"])


def draw_fx(img, store, frame, sid, dom, origin):
    S = SCALE
    c = rp.THEMES[dom["theme"]]
    acc = rp.Page.rgb(c["acc"])
    ox, oy = origin
    for fx in frame.get("fx") or []:
        pos = resolve(store, fx["pos"], sid)
        if not pos:
            continue
        age = fx["age"]
        x, y = pos
        if fx.get("hit") and fx.get("hstate"):   # вспышка на нажатой кнопке
            box = store.hits(fx["hstate"])["hits"].get(fx["hit"])
            if box:
                a = int(130 * (1 - age) ** 2)
                over(img, ((box[0] - 8) * S, (box[1] - 8) * S, (box[2] + 8) * S, (box[3] + 8) * S),
                     lambda d, bx, by: d.rounded_rectangle([(box[0] - 3) * S - bx, (box[1] - 3) * S - by, (box[2] + 3) * S - bx, (box[3] + 3) * S - by],
                                                           radius=7 * S, outline=acc + (a,), width=max(2, round(2.5 * S)), fill=acc + (a // 4,)))
        for j in (0, 1):   # два расходящихся кольца
            a_j = age - 0.14 * j
            if 0 < a_j < 1:
                r = (8 + a_j * (80 + 24 * j)) * S
                alpha = int(235 * (1 - a_j) ** 1.6)
                over(img, (x * S - r - 6, y * S - r - 6, x * S + r + 6, y * S + r + 6),
                     lambda d, bx, by, r=r, alpha=alpha: d.ellipse([x * S - r - bx, y * S - r - by, x * S + r - bx, y * S + r - by],
                                                                    outline=acc + (alpha,), width=max(2, round(2.6 * S))))
        # искры
        reach = (12 + age * 64) * S
        over(img, (x * S - reach - 30, y * S - reach - 30, x * S + reach + 30, y * S + reach + 30),
             lambda d, bx, by: [d.line([(x * S + math.cos(a_) * reach - bx, y * S + math.sin(a_) * reach - by),
                                        (x * S + math.cos(a_) * (reach + 11 * (1 - age) * S) - bx, y * S + math.sin(a_) * (reach + 11 * (1 - age) * S) - by)],
                                       fill=(255, 255, 255, int(240 * (1 - age))), width=max(1, round(2 * S)))
                                for a_ in [(i / 10) * 2 * math.pi + 0.35 for i in range(10)]])
        # волна по нитям виджета, по которому нажали
        wid = fx.get("wid")
        if wid:
            for th in dom.get("threads") or []:
                if wid in (th["a"], th["b"]):
                    s = min(1.0, age * 1.15)
                    tt = s if th["a"] == wid else 1 - s
                    px_, py_ = bezier(th["p"], tt)
                    if th.get("off"):
                        continue
                    col = rp.KIND_RGB.get(th["kind"]) or rp.Page.rgb(c["ok"] if th["kind"] == "module" else c["acc"])
                    glow_dot(img, ox + px_, oy + py_, 4.2, 15, col, 2.4 * (1 - age) + 0.4)


def draw_cursor(img, store, frame, sid, dom):
    cur = frame.get("cur")
    if not cur:
        return
    a, b = resolve(store, cur.get("from"), sid), resolve(store, cur.get("to"), sid)
    a, b = a or b, b or a
    if not a:
        return
    e = ease(cur.get("t", 1.0))
    x, y = a[0] + (b[0] - a[0]) * e, a[1] + (b[1] - a[1]) * e
    S = SCALE
    d = ImageDraw.Draw(img)
    shape = [(0, 0), (0, 17), (4.2, 13.2), (7.4, 20), (10.2, 18.8), (7.1, 12.2), (12.5, 12.2)]
    k = 0.9 if cur.get("down") else 1.0
    pts = [((x + px_ * k) * S, (y + py_ * k) * S) for px_, py_ in shape]
    d.polygon([(px_ + 1.2 * S, py_ + 1.4 * S) for px_, py_ in pts], fill="#000000")
    d.polygon(pts, fill="#ffffff", outline="#000000")
    if cur.get("down"):
        d.ellipse([(x - 3.5) * S, (y - 3.5) * S, (x + 3.5) * S, (y + 3.5) * S], fill=rp.THEMES[dom["theme"]]["acc"])


def render_frame(store, frame):
    sid = frame["s"]
    dom = store.states[sid]
    img = store.base(sid).copy()
    origin = tuple(store.hits(sid)["origin"])
    draw_pulses(img, store, frame, dom, origin)
    draw_fx(img, store, frame, sid, dom, origin)
    draw_bursts(img, frame, dom, origin)
    draw_cursor(img, store, frame, sid, dom)
    draw_caption(img, frame, dom)
    return img


def cmd_prepare(store, budget):
    t0 = time.time()
    todo = [sid for sid in sorted(store.states) if not store.ready(sid)]
    done = 0
    for sid in todo:
        if time.time() - t0 > budget:
            break
        store.build(sid)
        done += 1
    left = len(todo) - done
    print(f"основ отрисовано: {done}, осталось: {left} из {len(store.states)}")
    if left:
        print("запустите prepare ещё раз")


def cmd_encode(store, out):
    missing = [sid for sid in store.states if not store.ready(sid)]
    if missing:
        sys.exit(f"не готовы основы состояний: {len(missing)}; сначала prepare")
    first = store.base(store.frames[0]["s"])
    w, h = first.size
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}", "-r", str(FPS), "-i", "-",
           "-c:v", "libx264", "-preset", os.environ.get("ZC_PRESET", "veryfast"), "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", out]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t0 = time.time()
    for i, fr in enumerate(store.frames):
        proc.stdin.write(render_frame(store, fr).tobytes())
        if i % 200 == 0:
            print(f"кадр {i}/{len(store.frames)} ({time.time() - t0:.0f} с)", flush=True)
    proc.stdin.close()
    proc.wait()
    print(out, round(os.path.getsize(out) / 1e6, 2), "МБ")


def main():
    store = Store(sys.argv[1])
    cmd = sys.argv[2]
    if cmd == "prepare":
        cmd_prepare(store, float(sys.argv[3]) if len(sys.argv) > 3 else 40.0)
    elif cmd == "frame":
        n = int(sys.argv[3])
        sid = store.frames[n]["s"]
        if not store.ready(sid):
            store.build(sid)
        for s in {store.frames[n]["s"]} | {fx["hstate"] for fx in (store.frames[n].get("fx") or []) if fx.get("hstate")} | \
                 {v["state"] for v in (store.frames[n]["cur"] or {}).values() if isinstance(v, dict) and "state" in v}:
            if not store.ready(s):
                store.build(s)
        render_frame(store, store.frames[n]).save(sys.argv[4])
        print(sys.argv[4])
    elif cmd == "encode":
        cmd_encode(store, sys.argv[3])


if __name__ == "__main__":
    main()
