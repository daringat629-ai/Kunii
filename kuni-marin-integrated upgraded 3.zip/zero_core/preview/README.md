# Предпросмотр панели

Рисует картинку веб-панели без браузера: настоящий код панели (`app.js`, `layout.js`) запускается в node на демо-данных, а получившееся дерево
элементов с позициями рисуется скриптом на PIL. Это приближение (свой шрифт и отступы), а не снимок экрана браузера.

```
node render_dump.js 1440 dark ru > dump.json        # ширина доски, тема dark|light, язык ru|en
python3 render_png.py dump.json panel.png           # масштаб и максимальная высота необязательны
node render_dump.js 400 dark ru > phone.json && python3 render_png.py phone.json phone.png 2 1500   # вид для телефона
```

## Демонстрационное видео

`render_video_dump.js` проигрывает сценарий на настоящем коде панели («мышь» перетаскивает виджеты, меняет размер, включает и выключает модули,
подтверждает действие в окне, нажимает кнопки плагина) и печатает по кадру на строку; `render_video.py` рисует кадры и собирает MP4 (нужен ffmpeg).
```
node render_video_dump.js black ru > frames.jsonl            # тема dark|light|black, язык ru|en
python3 render_video.py frames.jsonl demo.mp4 1.5 800        # масштаб, высота окна
```
Рендер можно продолжать частями: `ZC_FRAMES_DIR=/tmp/frames ZC_BATCH=60 python3 render_video.py ...` (повторять до сообщения о готовом файле).

## Видео на 60 кадров/с с нитями и эффектом клика

Сценарий на холсте 1920×1080 (виджеты расставлены свободно, нити, бегущие импульсы, эффект клика). Основа страницы рисуется один раз на состояние и кэшируется,
на каждый кадр накладываются импульсы, эффект клика и курсор; кадры идут прямо в ffmpeg.
```
node render_video60_dump.js black ru > frames60.jsonl
python3 render_video60.py frames60.jsonl prepare 40       # основы состояний; повторять, пока не напишет «осталось: 0»
python3 render_video60.py frames60.jsonl frame 725 f.png  # один кадр для проверки
python3 render_video60.py frames60.jsonl encode demo.mp4  # ZC_PRESET=medium для лучшего сжатия
```

## Видео «Архитектура» (60 кадров/с)

```
python3 make_arch_demo.py > arch_demo.json                       # граф настоящим построителем на манифестах репозитория
node render_arch60_dump.js black ru arch_demo.json > frames_arch.jsonl
ZC_CACHE=/tmp/zcarch python3 render_video60.py frames_arch.jsonl prepare 50     # повторять до «осталось: 0»
ZC_CACHE=/tmp/zcarch python3 render_video60.py frames_arch.jsonl encode arch.mp4
```

## Видео «Живая архитектура» (события приходят сами, без мыши)

```
node render_live60_dump.js black ru arch_demo.json > frames_live.jsonl
ZC_CACHE=/tmp/zclive python3 render_video60.py frames_live.jsonl prepare 50
ZC_CACHE=/tmp/zclive python3 render_video60.py frames_live.jsonl encode live.mp4
```
