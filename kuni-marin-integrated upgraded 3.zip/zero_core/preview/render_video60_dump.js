// Сценарий на 60 кадров/с: «мышь» двигает виджеты (нити следуют за ними), включает и выключает модули, жмёт кнопки плагина.
// Печатает JSON-строки двух видов: состояние страницы {"k":"s",...} (только когда оно изменилось) и кадр {"k":"f",...}.
//   node render_video60_dump.js [тема] [язык] > frames60.jsonl
process.env.TZ = 'Asia/Bishkek';
const { Document, Node } = require('../tests/js/dom_stub.js');
const L = require('../zerocore/admin/web/layout.js');
const app = require('../zerocore/admin/web/app.js');
const theme = process.argv[2] || 'black', lang = process.argv[3] || 'ru';
const PAGE_W = 1920, BOARD_W = PAGE_W - 20, BOARD_X = 10, BOARD_Y = 53, CELL = BOARD_W / 24, ROW = 30, FPS = 60, DT = 1 / FPS;

Node.prototype.getContext = function () {
  const self = this;
  if (self.className === 'threads') return new Proxy({}, { get: () => () => {}, set: () => true });   // нити рисуются из данных S.threads
  self.paths = self.paths || [];
  self.width = Number(self.attrs.width) || self.width || 300; self.height = Number(self.attrs.height) || self.height || 150;
  const ctx = { strokeStyle: '#fff', lineWidth: 1, beginPath() { self.paths.push({ color: ctx.strokeStyle, w: ctx.lineWidth, pts: [] }); },
    moveTo(x, y) { self.paths[self.paths.length - 1].pts.push([x, y]); }, lineTo(x, y) { self.paths[self.paths.length - 1].pts.push([x, y]); }, stroke() {}, clearRect() { } };
  return new Proxy(ctx, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } });
};

// ---------- демо-данные и «сервер» ----------
let fakeNow = Date.UTC(2026, 9, 9, 7, 52, 0);
Date.now = () => fakeNow;
const base = fakeNow / 1000;
const series = Array.from({ length: 72 }, (_, i) => ({ t: base - (72 - i) * 5,
  load1: +(0.35 + 0.25 * Math.sin(i / 6) + (i > 50 ? 0.55 * Math.sin((i - 50) / 3) ** 2 : 0)).toFixed(2), mem: +(41 + 3 * Math.sin(i / 9) + i * 0.04).toFixed(1), rss: 612 }));
const logs = [[0, 'core', 'module.started {"module": "kuni"}'], [3, 'kuni', '[13:47:12][UI thread][App][INFO]: Bot is up and running.'],
  [70, 'kuni', '[13:48:22][UI thread][tools::external][INFO]: Loaded 2 external tool(s): demo_echo, demo_add'], [95, 'core', 'tools.exported {"count": 2, "problems": 0}'],
  [140, 'kuni', '[13:50:03][UI thread][tools::shell][WARN]: EXEC: date'], [190, 'kuni', '[13:51:00][UI thread][tools::external][INFO]: CALL demo_tools/demo_add'],
  [232, 'kuni', '[13:51:41][UI thread][OpenAIChat][WARN]: chatStreaming: status=HTTP_429_TOO_MANY_REQUESTS'], [300, 'core', 'config.changed {"module": "kuni"}'],
  [320, 'kuni', '[13:52:10][UI thread][App][INFO]: Processing notification: You received a direct message']].map(([dt, src, text]) => ({ t: base - 330 + dt, src, text }));
const M = (name, version, kind, enabled, running, health) => ({ name, version, kind, enabled, running, health, detail: '', provides: [] });
const mods = [M('demo_counter', '1.0.0', 'library', true, false, 'unknown'), M('demo_tools', '1.0.0', 'library', true, false, 'unknown'),
  M('kuni', '0.0.2', 'external', true, true, 'healthy'), M('watchdog', '2.0.0', 'job', true, false, 'healthy'),
  M('webview', '1.0.0', 'service', false, false, 'unknown'), M('world_v2', '2.0.0', 'library', true, false, 'healthy')];
const widgetsOf = m => m.name === 'demo_counter' ? [{ id: 'counter', title: 'Demo counter', kind: 'counter', refresh: 5, size: { w: 6, h: 8 } }]
  : m.name === 'watchdog' ? [{ id: 'status', title: 'Предохранитель', kind: 'kv', refresh: 10, size: { w: 6, h: 7 } }] : [];
let counter = 229, lastNote = '+10 → 229';
const settings = { language: lang, theme, log_lines: 200, gap: 28, hidden: ['llm', 'generation', 'tools'],
  layout: { system: { x: 1, y: 1, w: 6, h: 8 }, stats: { x: 9, y: 0, w: 6, h: 7 }, transports: { x: 17, y: 1, w: 6, h: 5 },
            'm:watchdog:status': { x: 0, y: 12, w: 6, h: 7 }, plugins: { x: 8, y: 10, w: 8, h: 9 }, 'm:demo_counter:counter': { x: 17, y: 10, w: 6, h: 8 },
            log: { x: 1, y: 22, w: 9, h: 8 }, load: { x: 14, y: 22, w: 9, h: 8 } } };
const data = {
  '/api/system': { zerocore: '0.1.0', python: '3.12.3', os: 'Linux (x86_64)', pid: 4120, home: '/home/marinka/zero_core_home', uptime: 18720, modules: 6, enabled: 5, integrity: [], host: { load1: 0.62, mem_pct: 43.5 } },
  '/api/stats': { llm_requests_today: 214, shell_commands: 3, messages_sent: 41, external_calls: 7, guard_refusals: 1, llm_http_errors: 1, errors: 0 },
  '/api/transports': [{ name: 'kuni', capability: 'telegram.bot', running: true, health: 'healthy' }],
  '/api/metrics': series, '/api/tools': [], '/api/log': logs, '/api/llm': { available: false }, '/api/generation': { known: false },
  '/api/widget/watchdog/status': { ok: true, kind: 'kv', title: 'Предохранитель', data: { items: [['последний запуск', '41 с назад'], ['код возврата', '0'], ['остановок бота', '2'], ['последняя остановка', '09:14:02 зацикливание: 15 запусков shell за 180 с']] }, actions: [], note: null } };
const fetch = async (p, init) => {
  const reply = (s, b) => ({ status: s, ok: s < 400, json: async () => b });
  if (p === '/api/settings') { if (init.method === 'POST') Object.assign(settings, JSON.parse(init.body)); return reply(200, settings); }
  if (p === '/api/modules') return reply(200, mods.map(m => Object.assign({}, m, { widgets: m.enabled ? widgetsOf(m) : [] })));
  const am = p.match(/^\/api\/modules\/([a-z_0-9]+)\/(\w+)$/);
  if (am) {
    const m = mods.find(x => x.name === am[1]), a = am[2];
    if (a === 'enable') { m.enabled = true; if (m.kind === 'service' || m.kind === 'external') { m.running = true; m.health = 'healthy'; } }
    else if (a === 'disable') { m.enabled = false; m.running = false; m.health = 'unknown'; }
    else if (a === 'stop') { m.running = false; m.health = 'stopped'; } else if (a === 'start' || a === 'restart') { m.running = true; m.health = 'healthy'; }
    return reply(200, { ok: true });
  }
  if (p === '/api/widget/demo_counter/counter' || p.startsWith('/api/widget/demo_counter/counter/action/')) {
    if (p.endsWith('/plus10')) { counter += 10; lastNote = '+10 → ' + counter; }
    return reply(200, { ok: true, kind: 'counter', title: 'Demo counter', data: { value: counter, label: 'кликов' }, actions: [{ id: 'plus10', label: '+10' }, { id: 'reset', label: 'Сброс' }], note: lastNote });
  }
  if (p.startsWith('/api/log')) return reply(200, logs);
  return data[p] !== undefined ? reply(200, data[p]) : reply(404, { error: 'nf' });
};

// ---------- приложение ----------
const doc = new Document();
doc.board.rect.width = BOARD_W;
const env = { document: doc, fetch, storage: { getItem: () => 'tok', setItem() {} }, setInterval: () => 0, setTimeout: () => 0, clearTimeout() {},
  Layout: L, window: { addEventListener() {} }, now: () => fakeNow };
const flush = async (n = 30) => { for (let i = 0; i < n; i++) await new Promise(r => setImmediate(r)); };
const ser = n => n.tag === '#text' ? { tag: '#text', text: n._text } : { tag: n.tag, cls: n.className, id: n.id, text: n._text, style: n.style, attrs: n.attrs,
  hidden: n.hidden, paths: n.paths || null, children: n.children.map(ser) };
let appRef = null, T = 0, frameNo = 0, nextState = 0;
const seen = new Map();
function currentState() {
  const dom = { width: BOARD_W, theme, lang, background: 'space', bodyClass: doc.body.className, boardClass: doc.board.className, boardStyle: doc.board.style, cellW: CELL,
    topbar: ser(doc.topbar), widgets: doc.board.children.map(ser), overlay: ser(doc.overlay), threads: appRef.S.threads };
  const key = JSON.stringify(dom);
  if (!seen.has(key)) { seen.set(key, ++nextState); process.stdout.write(JSON.stringify({ k: 's', id: nextState, dom }) + '\n'); }
  return seen.get(key);
}
function emit(cursor, fx) {
  fakeNow += Math.round(DT * 1000); T += DT; frameNo++;
  process.stdout.write(JSON.stringify({ k: 'f', t: +T.toFixed(4), s: currentState(), cur: cursor, fx: fx || null }) + '\n');
}
const A = (x, y) => ({ abs: [x, y] }), H = key => ({ hit: key });
const ease = t => t * t * (3 - 2 * t);
const px = v => parseFloat(String(v).replace('px', ''));
const geom = id => { const st = doc.board.byId('w-' + id).style; return { x: BOARD_X + px(st.left), y: BOARD_Y + px(st.top), w: px(st.width), h: px(st.height) }; };
const hold = (frames, spec, down = false) => { for (let i = 0; i < frames; i++) emit({ from: spec, to: spec, t: 1, down }); };
async function move(from, to, frames, down, onStep) {
  for (let i = 1; i <= frames; i++) { const t = i / frames; if (onStep) await onStep(ease(t)); emit({ from, to, t, down }); }
}
function widgetIdOf(node) { for (let n = node; n; n = n.parent) if (n.id && n.id.indexOf('w-') === 0) return n.id.slice(2); return null; }
async function click(spec, node) {
  const before = currentState(), live = { hit: spec.hit, state: before }, wid = widgetIdOf(node);
  hold(8, live, true);                      // кнопка нажата
  node.dispatch('click', {});
  await flush();
  for (let i = 1; i <= 48; i++) emit({ from: live, to: live, t: 1, down: false }, [{ pos: live, age: i / 48, hit: spec.hit, hstate: before, wid }]);
  return live;
}
function pluginButton(moduleName, label) {
  const row = doc.board.byId('w-plugins').byClass('row').filter(r => r.textContent.startsWith(moduleName + ' '))[0];
  return row.buttons(label)[0];
}
let cursorSpec = A(960, 600);
async function drag(id, dx, dy) {
  const g = geom(id), node = doc.board.byId('w-' + id);
  const start = [g.x + 80, g.y + 13], end = [start[0] + dx, start[1] + dy];
  await move(cursorSpec, A(...start), 60, false);
  cursorSpec = A(...start);
  node.byClass('wh')[0].dispatch('pointerdown', { clientX: start[0], clientY: start[1] });
  hold(12, cursorSpec, true);
  await move(A(...start), A(...end), 110, true, e => { doc.dispatch('pointermove', { clientX: start[0] + dx * e, clientY: start[1] + dy * e }); });
  hold(24, A(...end), true);
  doc.dispatch('pointerup', {});
  await flush();
  cursorSpec = A(...end);
  hold(48, cursorSpec, false);
}

(async () => {
  appRef = app.boot(env); await appRef.started; await flush();
  hold(90, cursorSpec);
  await drag('load', -4 * CELL, -2 * ROW);          // «Нагрузка» в свободное место: нити тянутся за ней
  await drag('transports', -4 * CELL, 7 * ROW);     // «Транспорты» на «Плагины»: те сдвигаются вниз, нити перестраиваются
  hold(36, cursorSpec);
  await move(cursorSpec, H('plug:demo_counter:выключить'), 70, false); cursorSpec = H('plug:demo_counter:выключить');
  cursorSpec = await click(cursorSpec, pluginButton('demo_counter', 'выключить'));
  hold(36, cursorSpec);
  await move(cursorSpec, H('modal:Выполнить'), 40, false); cursorSpec = H('modal:Выполнить');
  cursorSpec = await click(cursorSpec, doc.overlay.byId('confirm-yes'));
  hold(70, cursorSpec);                              // виджет и его нить исчезли
  await move(cursorSpec, H('plug:demo_counter:включить'), 60, false); cursorSpec = H('plug:demo_counter:включить');
  cursorSpec = await click(cursorSpec, pluginButton('demo_counter', 'включить'));
  hold(70, cursorSpec);                              // вернулись и виджет, и нить
  await move(cursorSpec, H('act:+10'), 60, false); cursorSpec = H('act:+10');
  cursorSpec = await click(cursorSpec, doc.board.buttons('+10')[0]);
  hold(20, cursorSpec);
  cursorSpec = await click(cursorSpec, doc.board.buttons('+10')[0]);
  hold(40, cursorSpec);
  await move(cursorSpec, H('plug:webview:включить'), 70, false); cursorSpec = H('plug:webview:включить');
  cursorSpec = await click(cursorSpec, pluginButton('webview', 'включить'));
  hold(100, cursorSpec);
})();
