// Сценарий демонстрации: «мышь» двигает виджеты и включает/выключает модули. Настоящий код панели (app.js + layout.js) получает
// настоящие события указателя; на каждом шаге печатается один кадр (JSON в строке) с деревом элементов и положением курсора.
//   node render_video_dump.js [тема] [язык] > frames.jsonl
process.env.TZ = 'Asia/Bishkek';
const { Document, Node } = require('../tests/js/dom_stub.js');
const L = require('../zerocore/admin/web/layout.js');
const app = require('../zerocore/admin/web/app.js');
const theme = process.argv[2] || 'black', lang = process.argv[3] || 'ru';
const PAGE_W = 1280, BOARD_W = PAGE_W - 20, BOARD_X = 10, BOARD_Y = 53, CELL = BOARD_W / 24, ROW = 30;

Node.prototype.getContext = function () {
  const self = this; self.paths = self.paths || []; let cur = null;
  self.width = Number(self.attrs.width) || 300; self.height = Number(self.attrs.height) || 150;
  const ctx = { strokeStyle: '#fff', lineWidth: 1, beginPath() { cur = { color: ctx.strokeStyle, w: ctx.lineWidth, pts: [] }; self.paths.push(cur); },
    moveTo(x, y) { cur.pts.push([x, y]); }, lineTo(x, y) { cur.pts.push([x, y]); }, stroke() {} };
  return new Proxy(ctx, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } });
};

// ---------- демо-данные и «сервер» ----------
let fakeNow = Date.UTC(2026, 9, 9, 7, 52, 0);   // 13:52:00 по Бишкеку
Date.now = () => fakeNow;
const base = fakeNow / 1000;
const series = Array.from({ length: 72 }, (_, i) => ({ t: base - (72 - i) * 5,
  load1: +(0.35 + 0.25 * Math.sin(i / 6) + (i > 50 ? 0.55 * Math.sin((i - 50) / 3) ** 2 : 0)).toFixed(2), mem: +(41 + 3 * Math.sin(i / 9) + i * 0.04).toFixed(1), rss: 612 }));
const logs = [[0, 'core', 'module.started {"module": "kuni"}'], [3, 'kuni', '[13:47:12][UI thread][App][INFO]: Bot is up and running.'],
  [70, 'kuni', '[13:48:22][UI thread][tools::external][INFO]: Loaded 2 external tool(s): demo_echo, demo_add'], [95, 'core', 'tools.exported {"count": 2, "problems": 0}'],
  [140, 'kuni', '[13:50:03][UI thread][tools::shell][WARN]: EXEC: date'], [190, 'kuni', '[13:51:00][UI thread][tools::external][INFO]: CALL demo_tools/demo_add'],
  [232, 'kuni', '[13:51:41][UI thread][OpenAIChat][WARN]: chatStreaming: status=HTTP_429_TOO_MANY_REQUESTS'], [300, 'core', 'config.changed {"module": "kuni"}'],
  [320, 'kuni', '[13:52:10][UI thread][App][INFO]: Processing notification: You received a direct message']].map(([dt, src, text]) => ({ t: base - 330 + dt, src, text }));
const M = (name, version, kind, enabled, running, health) => ({ name, version, kind, enabled, running, health, detail: '', provides: [], base: [] });
const mods = [M('demo_counter', '1.0.0', 'library', true, false, 'unknown'), M('demo_tools', '1.0.0', 'library', true, false, 'unknown'),
  M('kuni', '0.0.2', 'external', true, true, 'healthy'), M('watchdog', '2.0.0', 'job', true, false, 'healthy'),
  M('webview', '1.0.0', 'service', false, false, 'unknown'), M('world_v2', '2.0.0', 'library', true, false, 'healthy')];
const widgetsOf = m => m.name === 'demo_counter' ? [{ id: 'counter', title: 'Demo counter', kind: 'counter', refresh: 5, size: { w: 8, h: 8 } }]
  : m.name === 'watchdog' ? [{ id: 'status', title: 'Предохранитель', kind: 'kv', refresh: 10, size: { w: 12, h: 6 } }] : [];
let counter = 229, lastNote = '+10 → 229';
const settings = { language: lang, theme, log_lines: 200, hidden: ['llm', 'transports', 'generation', 'tools'],
  layout: { system: { x: 0, y: 0, w: 8, h: 8 }, stats: { x: 8, y: 0, w: 8, h: 8 }, 'm:demo_counter:counter': { x: 16, y: 0, w: 8, h: 8 },
            plugins: { x: 0, y: 8, w: 12, h: 8 }, log: { x: 12, y: 8, w: 12, h: 8 }, load: { x: 0, y: 16, w: 12, h: 6 }, 'm:watchdog:status': { x: 12, y: 16, w: 12, h: 6 } } };
const data = {
  '/api/system': { zerocore: '0.1.0', python: '3.12.3', os: 'Linux (x86_64)', pid: 4120, home: '/home/marinka/zero_core_home', uptime: 18720, modules: 6, enabled: 5, integrity: [], host: { load1: 0.62, mem_pct: 43.5 } },
  '/api/stats': { llm_requests_today: 214, shell_commands: 3, messages_sent: 41, external_calls: 7, guard_refusals: 1, llm_http_errors: 1, errors: 0 },
  '/api/metrics': series, '/api/tools': [], '/api/log': logs, '/api/llm': { available: false }, '/api/transports': [], '/api/generation': { known: false },
  '/api/widget/watchdog/status': { ok: true, kind: 'kv', title: 'Предохранитель', data: { items: [['последний запуск', '41 с назад'], ['код возврата', '0'], ['остановок бота', '2'], ['последняя остановка', '09:14:02 зацикливание: 15 запусков shell за 180 с']] }, actions: [], note: null } };
const calls = [];
const fetch = async (p, init) => {
  const reply = (s, b) => ({ status: s, ok: s < 400, json: async () => b });
  calls.push(p);
  if (p === '/api/settings') { if (init.method === 'POST') Object.assign(settings, JSON.parse(init.body)); return reply(200, settings); }
  if (p === '/api/modules') return reply(200, mods.map(m => Object.assign({}, m, { widgets: m.enabled ? widgetsOf(m) : [] })));
  const am = p.match(/^\/api\/modules\/([a-z_0-9]+)\/(\w+)$/);
  if (am) {
    const m = mods.find(x => x.name === am[1]), a = am[2];
    if (a === 'enable') { m.enabled = true; if (m.kind === 'service' || m.kind === 'external') { m.running = true; m.health = 'healthy'; } }
    else if (a === 'disable') { m.enabled = false; m.running = false; m.health = 'unknown'; }
    else if (a === 'stop') { m.running = false; m.health = 'stopped'; } else if (a === 'start' || a === 'restart') { m.running = true; m.health = 'healthy'; }
    return reply(200, { ok: true });
  }
  if (p === '/api/widget/demo_counter/counter' || p.startsWith('/api/widget/demo_counter/counter/action/')) {
    if (p.endsWith('/plus10')) { counter += 10; lastNote = '+10 → ' + counter; }
    return reply(200, { ok: true, kind: 'counter', title: 'Demo counter', data: { value: counter, label: 'кликов' }, actions: [{ id: 'plus10', label: '+10' }, { id: 'reset', label: 'Сброс' }], note: lastNote });
  }
  if (p.startsWith('/api/log')) return reply(200, logs);
  return data[p] !== undefined ? reply(200, data[p]) : reply(404, { error: 'nf' });
};

// ---------- приложение ----------
const doc = new Document();
doc.board.rect.width = BOARD_W;
const env = { document: doc, fetch, storage: { getItem: () => 'tok', setItem() {} }, setInterval: () => 0, setTimeout: () => 0, clearTimeout() {},
  Layout: L, window: { addEventListener() {} } };
const flush = async (n = 30) => { for (let i = 0; i < n; i++) await new Promise(r => setImmediate(r)); };
const ser = n => n.tag === '#text' ? { tag: '#text', text: n._text } : { tag: n.tag, cls: n.className, id: n.id, text: n._text, style: n.style, attrs: n.attrs,
  hidden: n.hidden, paths: n.paths || null, children: n.children.map(ser) };

let frameNo = 0;
function emit(duration, cursor, ripple = null) {
  frameNo++;
  fakeNow += Math.round(duration * 1000);
  const fr = { width: BOARD_W, theme, lang, bodyClass: doc.body.className, boardClass: doc.board.className, boardStyle: doc.board.style, cellW: CELL,
    topbar: ser(doc.topbar), widgets: doc.board.children.map(ser), overlay: ser(doc.overlay), cursor, ripple, duration };
  process.stdout.write(JSON.stringify(fr) + '\n');
}
const A = (x, y) => ({ abs: [x, y] }), H = key => ({ hit: key });
const ease = t => t * t * (3 - 2 * t);
const px = v => parseFloat(String(v).replace('px', ''));
const geom = id => { const st = doc.board.byId('w-' + id).style; return { x: BOARD_X + px(st.left), y: BOARD_Y + px(st.top), w: px(st.width), h: px(st.height) }; };
const hold = (dur, spec, down = false) => emit(dur, { from: spec, to: spec, t: 1, down });
async function move(from, to, n, dt, down, onStep) {
  for (let i = 1; i <= n; i++) {
    const t = i / n;
    if (onStep) { await onStep(ease(t)); }
    emit(dt, { from, to, t, down });
  }
}
async function click(spec, node) {
  const live = { hit: spec.hit };
  const at = frameNo;   // индекс первого кадра клика: в нём кнопка ещё на месте
  hold(0.12, live, true);
  if (node) node.dispatch('click', {});
  const stay = { hit: spec.hit, at };   // дальше курсор остаётся там, где был клик
  for (const r of [0.15, 0.4, 0.7, 0.95]) emit(0.05, { from: stay, to: stay, t: 1, down: false }, r);
  await flush();
  return stay;
}
function pluginButton(moduleName, label) {
  const row = doc.board.byId('w-plugins').byClass('row').filter(r => r.textContent.startsWith(moduleName + ' '))[0];
  return row.buttons(label)[0];
}
async function drag(id, dx, dy, part = 'head') {
  const g = geom(id), node = doc.board.byId('w-' + id);
  const start = part === 'head' ? [g.x + 70, g.y + 13] : [g.x + g.w - 6, g.y + g.h - 6];
  const end = [start[0] + dx, start[1] + dy];
  await move(cursorSpec, A(...start), 14, 0.04, false);
  cursorSpec = A(...start);
  const grab = part === 'head' ? node.byClass('wh')[0] : node.byClass('rh')[0];
  grab.dispatch('pointerdown', { clientX: start[0], clientY: start[1] });
  hold(0.18, cursorSpec, true);
  await move(A(...start), A(...end), 28, 0.04, true, e => { doc.dispatch('pointermove', { clientX: start[0] + dx * e, clientY: start[1] + dy * e }); });
  hold(0.25, A(...end), true);
  doc.dispatch('pointerup', {});
  await flush();
  cursorSpec = A(...end);
  hold(0.5, cursorSpec, false);
}
let cursorSpec = A(640, 470);

(async () => {
  const a = app.boot(env); await a.started; await flush();
  hold(1.4, cursorSpec);
  // 1) «Нагрузка» вверх на место «Плагинов»: плагины сдвигаются вниз
  await drag('load', 0, -8 * ROW);
  hold(0.6, cursorSpec);
  // 2) «Живой лог» выше: нижний виджет сдвигается
  await drag('log', 0, 2 * ROW, 'resize');
  hold(0.7, cursorSpec);
  // 3) выключить demo_counter (окно подтверждения), затем включить
  await move(cursorSpec, H('plug:demo_counter:выключить'), 22, 0.04, false); cursorSpec = H('plug:demo_counter:выключить');
  cursorSpec = await click(cursorSpec, pluginButton('demo_counter', 'выключить'));
  hold(0.9, cursorSpec);
  await move(cursorSpec, H('modal:Выполнить'), 14, 0.04, false); cursorSpec = H('modal:Выполнить');
  cursorSpec = await click(cursorSpec, doc.overlay.byId('confirm-yes'));
  hold(1.3, cursorSpec);
  await move(cursorSpec, H('plug:demo_counter:включить'), 18, 0.04, false); cursorSpec = H('plug:demo_counter:включить');
  cursorSpec = await click(cursorSpec, pluginButton('demo_counter', 'включить'));
  hold(1.1, cursorSpec);
  // 4) кнопка плагина «+10» дважды
  await move(cursorSpec, H('act:+10'), 22, 0.04, false); cursorSpec = H('act:+10');
  cursorSpec = await click(cursorSpec, doc.board.buttons('+10')[0]);
  hold(0.4, cursorSpec);
  cursorSpec = await click(cursorSpec, doc.board.buttons('+10')[0]);
  hold(0.8, cursorSpec);
  // 5) включить webview (служба запускается)
  await move(cursorSpec, H('plug:webview:включить'), 22, 0.04, false); cursorSpec = H('plug:webview:включить');
  cursorSpec = await click(cursorSpec, pluginButton('webview', 'включить'));
  hold(2.0, cursorSpec);
})();
