#!/usr/bin/env python3
"""Кадры из render_video_dump.js -> PNG -> MP4 (ffmpeg).
  python3 render_video.py frames.jsonl out.mp4 [масштаб] [высота_окна_css_px]
  python3 render_video.py frames.jsonl --only 0,60,120 [масштаб] [высота]   # только указанные кадры в /tmp/frame_N.png"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from multiprocessing import Pool

import render_png
from render_png import render_frame

SCALE, VIEWPORT = 1.0, 800


def _render(args):
    i, line, folder = args
    render_frame(json.loads(line), SCALE, VIEWPORT).save(os.path.join(folder, f"f{i:05d}.png"))
    return i


def main():
    global SCALE, VIEWPORT
    src = sys.argv[1]
    lines = [l for l in open(src, encoding="utf-8") if l.strip()]
    render_png.FRAME_SOURCE = lines
    if sys.argv[2] == "--only":
        idx = [int(x) for x in sys.argv[3].split(",")]
        SCALE = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
        VIEWPORT = int(sys.argv[5]) if len(sys.argv) > 5 else 800
        for i in idx:
            render_frame(json.loads(lines[i]), SCALE, VIEWPORT).save(f"/tmp/frame_{i}.png")
            print(f"/tmp/frame_{i}.png")
        return
    out = sys.argv[2]
    SCALE = float(sys.argv[3]) if len(sys.argv) > 3 else 1.0
    VIEWPORT = int(sys.argv[4]) if len(sys.argv) > 4 else 800
    # ZC_FRAMES_DIR: постоянная папка кадров (рендер можно продолжать); ZC_BATCH: сколько новых кадров отрисовать за запуск
    folder = os.environ.get("ZC_FRAMES_DIR") or tempfile.mkdtemp(prefix="zc_frames_")
    os.makedirs(folder, exist_ok=True)
    batch = int(os.environ.get("ZC_BATCH", "0")) or len(lines)
    todo = [i for i in range(len(lines)) if not os.path.exists(os.path.join(folder, f"f{i:05d}.png"))][:batch]
    try:
        with Pool(max(1, (os.cpu_count() or 2))) as pool:
            for k, _ in enumerate(pool.imap_unordered(_render, [(i, lines[i], folder) for i in todo], chunksize=2)):
                if k % 40 == 0:
                    print(f"отрисовано {k}/{len(todo)} (в этом запуске)", flush=True)
        left = [i for i in range(len(lines)) if not os.path.exists(os.path.join(folder, f"f{i:05d}.png"))]
        if left:
            print(f"осталось кадров: {len(left)}; запустите команду ещё раз", flush=True)
            return
        durations = [json.loads(l)["duration"] for l in lines]
        listing = os.path.join(folder, "list.txt")
        with open(listing, "w") as f:
            for i, d in enumerate(durations):
                f.write(f"file 'f{i:05d}.png'\nduration {d:.3f}\n")
            f.write(f"file 'f{len(durations) - 1:05d}.png'\n")
        cmd = ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", listing,
               "-vf", "fps=25,pad=ceil(iw/2)*2:ceil(ih/2)*2,format=yuv420p", "-c:v", "libx264", "-preset", "medium", "-crf", "20",
               "-movflags", "+faststart", out]
        subprocess.run(cmd, check=True)
        print(out, round(os.path.getsize(out) / 1e6, 2), "МБ")
        if not os.environ.get("ZC_FRAMES_DIR"):
            shutil.rmtree(folder, ignore_errors=True)
    except BaseException:
        if not os.environ.get("ZC_FRAMES_DIR"):
            shutil.rmtree(folder, ignore_errors=True)
        raise


if __name__ == "__main__":
    main()
