"""Помощники для модулей на Python. Контракт среды: ZEROCORE_API, ZEROCORE_HOME, ZEROCORE_MODULE, ZEROCORE_DATA_DIR,
ZEROCORE_STAGING (1 при проверочном запуске новой версии). Модули на других языках читают те же переменные."""
import os
from pathlib import Path


def data_dir():
    return Path(os.environ["ZEROCORE_DATA_DIR"])


def module_name():
    return os.environ.get("ZEROCORE_MODULE", "")


def is_staging():
    return os.environ.get("ZEROCORE_STAGING") == "1"


def publish(topic, payload=None):
    from .kernel.event_bus import EventBus
    EventBus(Path(os.environ["ZEROCORE_HOME"]) / "zerocore.db").publish(topic, payload, producer=module_name())
