"""Изоляция данных: модуль видит только свой каталог данных; чужие общие данные только по объявленному праву read."""
import os
from pathlib import Path

from .errors import PermissionDenied


def _inside(base, target):
    base, target = os.path.realpath(base), os.path.realpath(target)
    return target == base or target.startswith(base + os.sep)


def resolve_data_path(home, module, rel):
    base = Path(home) / "data" / module
    target = base / rel
    if not _inside(base, target):
        raise PermissionDenied(f"{module}: путь {rel!r} выходит за пределы каталога данных")
    return target


def resolve_shared_path(home, reader, owner, rel):
    """reader, owner: Manifest. Чтение разрешено, если в reader.permissions.read есть возможность, которую даёт owner."""
    allowed = set(reader.permissions.get("read", [])) & set(owner.provides)
    if not allowed:
        raise PermissionDenied(f"{reader.name} не объявил право read на возможности модуля {owner.name}")
    base = Path(home) / "data" / owner.name / "shared"
    target = base / rel
    if not _inside(base, target):
        raise PermissionDenied(f"{reader.name}: путь {rel!r} выходит за пределы shared/ модуля {owner.name}")
    return target
