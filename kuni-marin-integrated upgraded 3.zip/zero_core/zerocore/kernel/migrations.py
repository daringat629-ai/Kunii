"""Миграции общей базы: каждая в своей транзакции, при сбое откат, повторный запуск безопасен."""
import re
import sqlite3
import time
from pathlib import Path

from .errors import MigrationError


def _statements(sql):
    buf = ""
    for line in sql.splitlines(keepends=True):
        buf += line
        if sqlite3.complete_statement(buf):
            yield buf.strip()
            buf = ""
    if buf.strip():
        yield buf.strip()


def apply(db_path, migrations_dir, timeout=5.0):
    files = sorted(p for p in Path(migrations_dir).glob("*.sql") if re.match(r"^\d+_", p.name))
    try:
        conn = sqlite3.connect(str(db_path), timeout=timeout, isolation_level=None)
        conn.execute("CREATE TABLE IF NOT EXISTS schema_migrations(version TEXT PRIMARY KEY, applied REAL NOT NULL)")
    except sqlite3.OperationalError as ex:
        raise MigrationError(f"база недоступна: {ex}")
    applied = []
    try:
        done = {r[0] for r in conn.execute("SELECT version FROM schema_migrations")}
        for f in files:
            if f.name in done:
                continue
            try:
                conn.execute("BEGIN IMMEDIATE")
                for st in _statements(f.read_text(encoding="utf-8")):
                    conn.execute(st)
                conn.execute("INSERT INTO schema_migrations(version,applied) VALUES(?,?)", (f.name, time.time()))
                conn.execute("COMMIT")
            except sqlite3.Error as ex:
                try:
                    conn.execute("ROLLBACK")
                except sqlite3.Error:
                    pass
                raise MigrationError(f"миграция {f.name} не применена и откатана: {ex}")
            applied.append(f.name)
    finally:
        conn.close()
    return applied
