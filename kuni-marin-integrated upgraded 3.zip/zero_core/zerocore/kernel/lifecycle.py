"""Запуск и остановка процессов модулей. Группа процессов, SIGTERM, затем SIGKILL, без фоновых хвостов."""
import os
import resource
import signal
import subprocess
import time
from pathlib import Path

from .errors import LifecycleError


def _limiter(limits):
    if not limits:
        return None

    def apply():
        if "memory_mb" in limits:
            b = limits["memory_mb"] * 1024 * 1024
            resource.setrlimit(resource.RLIMIT_AS, (b, b))
        if "cpu_seconds" in limits:
            resource.setrlimit(resource.RLIMIT_CPU, (limits["cpu_seconds"], limits["cpu_seconds"]))
        if "open_files" in limits:
            resource.setrlimit(resource.RLIMIT_NOFILE, (limits["open_files"], limits["open_files"]))
    return apply


def wait_until(predicate, timeout, interval=0.05):
    end = time.time() + timeout
    while time.time() < end:
        if predicate():
            return True
        time.sleep(interval)
    return bool(predicate())


class ProcessRunner:
    def __init__(self, run_dir):
        self.run_dir = Path(run_dir)
        self.run_dir.mkdir(parents=True, exist_ok=True)
        self._children = {}

    def pidfile(self, name, suffix=""):
        return self.run_dir / f"{name}{suffix}.pid"

    def logfile(self, name):
        return self.run_dir / f"{name}.log"

    def _alive(self, pid):
        child = self._children.get(pid)
        if child is not None:
            return child.poll() is None
        try:
            if os.waitpid(pid, os.WNOHANG)[0] == pid:
                return False
        except ChildProcessError:
            pass
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        except PermissionError:
            return True
        try:
            with open(f"/proc/{pid}/stat") as f:
                if f.read().rsplit(")", 1)[1].split()[0] == "Z":
                    return False
        except OSError:
            pass
        return True

    def pid(self, name, suffix=""):
        pf = self.pidfile(name, suffix)
        try:
            pid = int(pf.read_text().strip())
        except (OSError, ValueError):
            return None
        if self._alive(pid):
            return pid
        self._children.pop(pid, None)
        try:
            pf.unlink()
        except OSError:
            pass
        return None

    def start(self, name, argv, cwd, env, limits=None, suffix=""):
        if self.pid(name, suffix):
            raise LifecycleError(f"{name}: уже запущен")
        log = open(self.logfile(name), "ab")
        try:
            proc = subprocess.Popen(argv, cwd=str(cwd), env=env, stdin=subprocess.DEVNULL, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=_limiter(limits))
        except OSError as ex:
            raise LifecycleError(f"{name}: не удалось запустить {argv[0]}: {ex}")
        finally:
            log.close()
        self._children[proc.pid] = proc
        self.pidfile(name, suffix).write_text(str(proc.pid))
        return proc.pid

    def stop(self, name, timeout=10.0, suffix=""):
        pid = self.pid(name, suffix)
        if pid is None:
            return "not_running"
        result = "graceful"
        try:
            os.killpg(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        if not wait_until(lambda: not self._alive(pid), timeout):
            result = "killed"
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if not wait_until(lambda: not self._alive(pid), 5.0):
                raise LifecycleError(f"{name}: процесс {pid} не завершился даже после SIGKILL")
        self._children.pop(pid, None)
        try:
            self.pidfile(name, suffix).unlink()
        except OSError:
            pass
        return result

    def promote(self, name, from_suffix, to_suffix=""):
        os.replace(self.pidfile(name, from_suffix), self.pidfile(name, to_suffix))

    def log_tail(self, name, n=600):
        try:
            return self.logfile(name).read_bytes()[-n:].decode("utf-8", "ignore")
        except OSError:
            return ""
