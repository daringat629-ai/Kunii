"""Проверки состояния модулей. Состояния: healthy, unhealthy, stopped, unknown."""
import os
import subprocess
import time
import urllib.request
from dataclasses import dataclass


@dataclass
class Health:
    state: str
    detail: str = ""


def _run(argv, timeout=5):
    try:
        return subprocess.run(argv, capture_output=True, timeout=timeout).returncode
    except (OSError, subprocess.TimeoutExpired):
        return None


def check(spec, runner=None, name=None, suffix="", runtime=None, now=None, interval=None):
    t = spec.get("type", "none")
    now = now or time.time()
    if t == "none":
        return Health("unknown", "проверка не настроена")
    if t == "process":
        return Health("healthy") if runner and runner.pid(name, suffix) else Health("stopped", "процесса нет")
    if t == "pgrep":
        rc = _run(["pgrep", "-x", spec["process"]])
        return Health("healthy") if rc == 0 else Health("stopped", f"процесс {spec['process']} не найден")
    if t == "command":
        rc = _run(spec["command"], spec.get("timeout", 5))
        return Health("healthy") if rc == 0 else Health("unhealthy", f"команда проверки завершилась кодом {rc}")
    if t == "http":
        try:
            with urllib.request.urlopen(spec["url"], timeout=spec.get("timeout", 2)) as r:
                return Health("healthy") if 200 <= r.status < 400 else Health("unhealthy", f"HTTP {r.status}")
        except Exception as ex:
            return Health("unhealthy", f"HTTP недоступен: {type(ex).__name__}")
    if t == "file_fresh":
        try:
            age = now - os.path.getmtime(spec["path"])
        except OSError:
            return Health("unhealthy", "файл не найден")
        if age > spec["max_age_seconds"]:
            return Health("unhealthy", f"файл не обновлялся {int(age)} с")
        return Health("healthy")
    if t == "job":
        last = (runtime or {}).get("last_run")
        if last is None:
            return Health("unknown", "ещё не запускалась")
        if (runtime or {}).get("last_rc") not in (0, None):
            return Health("unhealthy", f"последний запуск завершился кодом {runtime['last_rc']}")
        if interval and now - last > interval * 3 + 5:
            return Health("unhealthy", "задача давно не выполнялась")
        return Health("healthy")
    return Health("unknown", f"неизвестный тип проверки {t}")
