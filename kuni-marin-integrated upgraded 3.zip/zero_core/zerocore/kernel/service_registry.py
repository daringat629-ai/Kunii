"""Реестр возможностей: кто что предоставляет. Две реализации одной возможности запрещены."""
from .errors import ConflictError


class Registry:
    def __init__(self, manifests):
        self.providers = {}
        for m in manifests.values():
            for cap in m.provides:
                self.providers.setdefault(cap, []).append(m.name)
        dup = {c: n for c, n in self.providers.items() if len(n) > 1}
        if dup:
            raise ConflictError("; ".join(f"возможность {c} предоставляют несколько модулей: {', '.join(sorted(n))}"
                                          for c, n in sorted(dup.items())))

    def provider(self, capability):
        names = self.providers.get(capability)
        return names[0] if names else None

    def capabilities(self):
        return sorted(self.providers)
