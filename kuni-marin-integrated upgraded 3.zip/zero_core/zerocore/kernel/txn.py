"""Единый менеджер транзакций конфигурации. Все изменения системы (CLI, панель) идут через него:
  1) блокировка flock (одновременные изменения выстраиваются в очередь);
  2) журнал отката пишется до изменений (процесс умер посреди операции, при следующем входе всё откатывается);
  3) при ошибке откат состояния и всех зарегистрированных действий в обратном порядке."""
import copy
import fcntl
import json
import os
import shutil
import time
from pathlib import Path

from .errors import TxnError


def _atomic_write(path, text):
    path = Path(path)
    tmp = path.with_name(path.name + f".tmp{os.getpid()}")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


class StateStore:
    def __init__(self, home, filename="state.json", default=None):
        self.path = Path(home) / filename
        self.default = default if default is not None else {"modules": {}}

    def load(self):
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return copy.deepcopy(self.default)

    def save(self, state):
        _atomic_write(self.path, json.dumps(state, ensure_ascii=False, indent=1, sort_keys=True))


def _do_undo(action):
    kind, args = action[0], action[1:]
    try:
        if kind == "rm":
            Path(args[0]).unlink(missing_ok=True)
        elif kind == "rmtree":
            shutil.rmtree(args[0], ignore_errors=True)
        elif kind == "mv":
            if os.path.lexists(args[0]):
                Path(args[1]).parent.mkdir(parents=True, exist_ok=True)
                os.replace(args[0], args[1])
        elif kind == "symlink":
            link, target = Path(args[0]), args[1]
            if os.path.lexists(link):
                link.unlink()
            if target is not None:
                os.symlink(target, link)
        elif kind == "restore_file":
            p = Path(args[0])
            if args[1] is None:
                p.unlink(missing_ok=True)
            else:
                _atomic_write(p, args[1])
    except OSError:
        pass  # откат не должен падать из-за уже отсутствующего файла


class ConfigTransaction:
    def __init__(self, home, label, store, timeout=30.0):
        self.home = Path(home)
        self.label = label
        self.store = store
        self.timeout = timeout
        self.journal = self.home / "txn.journal.json"
        self._lock = None
        self._j = None

    # --- блокировка ---
    def _acquire(self):
        self.home.mkdir(parents=True, exist_ok=True)
        self._lock = open(self.home / "config.lock", "a+")
        end = time.time() + self.timeout
        while True:
            try:
                fcntl.flock(self._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return
            except BlockingIOError:
                if time.time() > end:
                    self._lock.close()
                    raise TxnError(f"не удалось получить блокировку конфигурации за {self.timeout} с")
                time.sleep(0.01)

    def _release(self):
        try:
            fcntl.flock(self._lock, fcntl.LOCK_UN)
        finally:
            self._lock.close()

    def _recover_locked(self):
        if not self.journal.exists():
            return False
        try:
            j = json.loads(self.journal.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self.journal.unlink(missing_ok=True)
            return False
        for action in reversed(j.get("undo", [])):
            _do_undo(action)
        self.store.save(j["state_before"])
        self.journal.unlink(missing_ok=True)
        return True

    # --- API ---
    def __enter__(self):
        self._acquire()
        try:
            self._recover_locked()
            self._j = {"label": self.label, "pid": os.getpid(), "ts": time.time(),
                       "state_before": copy.deepcopy(self.store.load()), "undo": []}
            _atomic_write(self.journal, json.dumps(self._j, ensure_ascii=False))
        except BaseException:
            self._release()
            raise
        return self

    def add_undo(self, *action):
        self._j["undo"].append(list(action))
        _atomic_write(self.journal, json.dumps(self._j, ensure_ascii=False))

    def __exit__(self, et, ev, tb):
        try:
            if et is not None:
                for action in reversed(self._j["undo"]):
                    _do_undo(action)
                self.store.save(self._j["state_before"])
            self.journal.unlink(missing_ok=True)
        finally:
            self._release()
        return False


def recover(home, store):
    """Вызывается при старте менеджера: откатывает операцию, прерванную смертью процесса."""
    home = Path(home)
    if not (home / "txn.journal.json").exists():
        return False
    tx = ConfigTransaction(home, "recover", store)
    tx._acquire()
    try:
        return tx._recover_locked()
    finally:
        tx._release()
