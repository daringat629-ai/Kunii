"""Контракт модуля: манифест manifest.json. Строгий: неизвестные поля считаются ошибкой."""
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from .errors import ContractError

API_VERSION = "1"
KINDS = ("service", "job", "external", "library")
HEALTH_TYPES = ("none", "process", "pgrep", "command", "http", "file_fresh", "job")
DATA_POLICIES = ("keep", "delete")
TOP_KEYS = {"api", "name", "version", "kind", "description", "run", "provides", "requires", "depends", "conflicts",
            "permissions", "health", "data_policy", "limits", "config", "widgets", "tools"}
WIDGET_KINDS = ("kv", "table", "text", "counter")
WIDGET_KEYS = {"id", "title", "kind", "command", "refresh_seconds", "actions", "size"}
WIDGET_ID_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")
TOOL_KEYS = {"name", "description", "parameters", "required", "command", "timeout_seconds", "max_output_bytes"}
TOOL_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,63}$")
TOOL_PARAM_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")
TOOL_PARAM_TYPES = ("string", "integer", "number", "boolean")
RUN_KEYS = {"command", "cwd", "env", "stop_timeout", "start_timeout", "schedule_seconds", "timeout", "handoff",
            "restart", "autostart", "start_command", "stop_command", "kill_command"}
PERM_KEYS = {"network", "shell", "read", "secrets"}
LIMIT_KEYS = {"memory_mb", "cpu_seconds", "open_files"}
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
CAP_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$")
VER_RE = re.compile(r"^\d+(\.\d+){0,2}$")
CONS_RE = re.compile(r"^(==|>=|<=|>|<|!=)\s*(\d+(\.\d+){0,2})$")


def parse_version(v):
    parts = [int(x) for x in str(v).split(".")]
    return tuple(parts + [0] * (3 - len(parts)))


def satisfies(version, constraint):
    for part in constraint.split(","):
        m = CONS_RE.match(part.strip())
        if not m:
            raise ContractError(f"неверное ограничение версии: {constraint!r}")
        op, ref = m.group(1), m.group(2)
        a, b = parse_version(version), parse_version(ref)
        if not {"==": a == b, ">=": a >= b, "<=": a <= b, ">": a > b, "<": a < b, "!=": a != b}[op]:
            return False
    return True


def _strlist(v):
    return isinstance(v, list) and v and all(isinstance(x, str) and x for x in v)


def _validate_widgets(widgets):
    if not isinstance(widgets, list):
        return ["widgets: список описаний виджетов"]
    errs, seen = [], set()
    for i, w in enumerate(widgets):
        p = f"widgets[{i}]"
        if not isinstance(w, dict):
            errs.append(f"{p}: объект")
            continue
        for k in w:
            if k not in WIDGET_KEYS:
                errs.append(f"{p}: неизвестное поле {k}")
        wid = w.get("id")
        if not isinstance(wid, str) or not WIDGET_ID_RE.match(wid):
            errs.append(f"{p}.id: строчные буквы, цифры и _, до 32 символов")
        elif wid in seen:
            errs.append(f"{p}.id: повтор {wid}")
        else:
            seen.add(wid)
        if not isinstance(w.get("title"), str) or not w.get("title"):
            errs.append(f"{p}.title: непустая строка")
        if w.get("kind") not in WIDGET_KINDS:
            errs.append(f"{p}.kind: одно из {WIDGET_KINDS}")
        if not _strlist(w.get("command")):
            errs.append(f"{p}.command: непустой список строк")
        rs = w.get("refresh_seconds", 10)
        if not (isinstance(rs, int) and not isinstance(rs, bool) and 1 <= rs <= 3600):
            errs.append(f"{p}.refresh_seconds: целое от 1 до 3600")
        size = w.get("size", {"w": 6, "h": 6})
        if not (isinstance(size, dict) and set(size) <= {"w", "h"} and all(
                isinstance(v, int) and not isinstance(v, bool) and 2 <= v <= 40 for v in size.values())):
            errs.append(f"{p}.size: {{w, h}} целые от 2 до 40")
        acts = w.get("actions", [])
        if not isinstance(acts, list):
            errs.append(f"{p}.actions: список")
            continue
        aseen = set()
        for j, a in enumerate(acts):
            q = f"{p}.actions[{j}]"
            if not isinstance(a, dict) or set(a) - {"id", "label", "command"}:
                errs.append(f"{q}: объект с полями id, label, command")
                continue
            if not isinstance(a.get("id"), str) or not WIDGET_ID_RE.match(a.get("id", "")) or a["id"] in aseen:
                errs.append(f"{q}.id: уникальный идентификатор")
            else:
                aseen.add(a["id"])
            if not isinstance(a.get("label"), str) or not a.get("label"):
                errs.append(f"{q}.label: непустая строка")
            if not _strlist(a.get("command")):
                errs.append(f"{q}.command: непустой список строк")
    return errs


def _int_in(v, lo, hi):
    return isinstance(v, int) and not isinstance(v, bool) and lo <= v <= hi


def _validate_tools(tools):
    """Инструменты для LLM: правила совпадают с разбором каталога на стороне ядра kuni (C++)."""
    if not isinstance(tools, list):
        return ["tools: список описаний инструментов"]
    errs, seen = [], set()
    for i, t in enumerate(tools):
        p = f"tools[{i}]"
        if not isinstance(t, dict):
            errs.append(f"{p}: объект")
            continue
        for k in t:
            if k not in TOOL_KEYS:
                errs.append(f"{p}: неизвестное поле {k}")
        name = t.get("name")
        if not isinstance(name, str) or not TOOL_NAME_RE.match(name):
            errs.append(f"{p}.name: строчные буквы, цифры и _, 2-64 символа, начинается с буквы")
        elif name in seen:
            errs.append(f"{p}.name: повтор {name}")
        else:
            seen.add(name)
        desc = t.get("description")
        if not isinstance(desc, str) or not desc or len(desc) > 2000:
            errs.append(f"{p}.description: непустая строка до 2000 символов")
        params = t.get("parameters", {})
        if not isinstance(params, dict) or len(params) > 32:
            errs.append(f"{p}.parameters: объект {{имя: {{type, description}}}}, до 32 параметров")
            params = {}
        for pn, spec in params.items():
            if not TOOL_PARAM_RE.match(pn):
                errs.append(f"{p}.parameters.{pn}: недопустимое имя")
            if not isinstance(spec, dict) or spec.get("type") not in TOOL_PARAM_TYPES or set(spec) - {"type", "description"}:
                errs.append(f"{p}.parameters.{pn}: {{type: {'|'.join(TOOL_PARAM_TYPES)}, description}}")
        req = t.get("required", [])
        if not isinstance(req, list) or not all(isinstance(r, str) and r in params for r in req):
            errs.append(f"{p}.required: список имён объявленных параметров")
        cmd = t.get("command")
        if not _strlist(cmd) or len(cmd) > 64 or not cmd[0]:
            errs.append(f"{p}.command: непустой список строк (до 64), программа не пустая")
        if "timeout_seconds" in t and not _int_in(t["timeout_seconds"], 1, 300):
            errs.append(f"{p}.timeout_seconds: целое от 1 до 300")
        if "max_output_bytes" in t and not _int_in(t["max_output_bytes"], 100, 65536):
            errs.append(f"{p}.max_output_bytes: целое от 100 до 65536")
    return errs


def validate_manifest(d):
    """Возвращает список ошибок (пустой список = манифест корректен)."""
    e = []
    if not isinstance(d, dict):
        return ["манифест должен быть объектом JSON"]
    for k in d:
        if k not in TOP_KEYS:
            e.append(f"неизвестное поле: {k}")
    if d.get("api") != API_VERSION:
        e.append(f"api должен быть {API_VERSION!r}")
    if not isinstance(d.get("name"), str) or not NAME_RE.match(d.get("name", "")):
        e.append("name: строчные буквы, цифры и _, 2–32 символа, начинается с буквы")
    if not isinstance(d.get("version"), str) or not VER_RE.match(d.get("version", "")):
        e.append("version: формат 1, 1.2 или 1.2.3")
    kind = d.get("kind")
    if kind not in KINDS:
        e.append(f"kind: одно из {KINDS}")
    run = d.get("run", {})
    if not isinstance(run, dict):
        e.append("run должен быть объектом")
        run = {}
    for k in run:
        if k not in RUN_KEYS:
            e.append(f"run: неизвестное поле {k}")
    if kind in ("service", "job") and not _strlist(run.get("command")):
        e.append("run.command: непустой список строк обязателен для service и job")
    if kind == "job" and not (isinstance(run.get("schedule_seconds"), int) and run["schedule_seconds"] >= 10):
        e.append("run.schedule_seconds: целое число не меньше 10 обязательно для job")
    if kind == "external" and not _strlist(run.get("start_command")):
        e.append("run.start_command обязателен для external")
    if run.get("handoff", "parallel") not in ("parallel", "stop_first"):
        e.append("run.handoff: parallel или stop_first")
    if run.get("restart", "never") not in ("never", "on-failure"):
        e.append("run.restart: never или on-failure")
    for k in ("provides", "requires", "conflicts"):
        v = d.get(k, [])
        if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
            e.append(f"{k}: список строк")
    for cap in list(d.get("provides", [])) + list(d.get("requires", [])):
        if isinstance(cap, str) and not CAP_RE.match(cap):
            e.append(f"возможность {cap!r}: формат группа.имя")
    deps = d.get("depends", {})
    if not isinstance(deps, dict):
        e.append("depends: объект имя -> ограничение версии")
    else:
        for n, c in deps.items():
            try:
                satisfies("0", c)
            except ContractError:
                e.append(f"depends.{n}: неверное ограничение {c!r}")
    perms = d.get("permissions", {})
    if not isinstance(perms, dict) or set(perms) - PERM_KEYS:
        e.append(f"permissions: допустимы только {sorted(PERM_KEYS)}")
    health = d.get("health", {"type": "none"})
    if not isinstance(health, dict) or health.get("type") not in HEALTH_TYPES:
        e.append(f"health.type: одно из {HEALTH_TYPES}")
    else:
        t = health["type"]
        if t == "pgrep" and not isinstance(health.get("process"), str):
            e.append("health.process обязателен для pgrep")
        if t == "command" and not _strlist(health.get("command")):
            e.append("health.command обязателен для command")
        if t == "http" and not isinstance(health.get("url"), str):
            e.append("health.url обязателен для http")
        if t == "file_fresh" and not (isinstance(health.get("path"), str) and isinstance(health.get("max_age_seconds"), int)):
            e.append("health.path и health.max_age_seconds обязательны для file_fresh")
    if d.get("data_policy", "keep") not in DATA_POLICIES:
        e.append(f"data_policy: одно из {DATA_POLICIES}")
    limits = d.get("limits", {})
    if not isinstance(limits, dict) or set(limits) - LIMIT_KEYS or not all(isinstance(v, int) and v > 0 for v in limits.values()):
        e.append(f"limits: положительные целые, ключи из {sorted(LIMIT_KEYS)}")
    if not isinstance(d.get("config", {}), dict):
        e.append("config: объект значений по умолчанию")
    if "widgets" in d:
        e.extend(_validate_widgets(d["widgets"]))
    if "tools" in d:
        e.extend(_validate_tools(d["tools"]))
    return e


@dataclass
class Manifest:
    name: str
    version: str
    kind: str
    description: str = ""
    run: dict = field(default_factory=dict)
    provides: list = field(default_factory=list)
    requires: list = field(default_factory=list)
    depends: dict = field(default_factory=dict)
    conflicts: list = field(default_factory=list)
    permissions: dict = field(default_factory=dict)
    health: dict = field(default_factory=lambda: {"type": "none"})
    data_policy: str = "keep"
    limits: dict = field(default_factory=dict)
    config: dict = field(default_factory=dict)
    widgets: list = field(default_factory=list)
    tools: list = field(default_factory=list)

    @classmethod
    def from_dict(cls, d):
        errs = validate_manifest(d)
        if errs:
            raise ContractError("; ".join(errs))
        return cls(**{k: v for k, v in d.items() if k != "api"})

    @classmethod
    def load(cls, path):
        path = Path(path)
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as ex:
            raise ContractError(f"{path}: не удалось прочитать манифест: {ex}")
        return cls.from_dict(data)
