class ZeroCoreError(Exception):
    """Базовая ошибка. Любая ошибка модуля или менеджера не должна валить ядро."""


class ContractError(ZeroCoreError):
    pass


class DependencyError(ZeroCoreError):
    pass


class ConflictError(ZeroCoreError):
    pass


class PermissionDenied(ZeroCoreError):
    pass


class LifecycleError(ZeroCoreError):
    pass


class TxnError(ZeroCoreError):
    pass


class MigrationError(ZeroCoreError):
    pass
