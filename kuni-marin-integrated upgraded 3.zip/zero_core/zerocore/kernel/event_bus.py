"""Шина событий на SQLite: журнал + курсоры потребителей, ограниченная очередь."""
import json
import sqlite3
import time

from .errors import ZeroCoreError

MAX_EVENTS = 10000
MAX_PAYLOAD = 65536


class EventBus:
    def __init__(self, db_path, max_events=MAX_EVENTS):
        self.db_path = str(db_path)
        self.max_events = max_events

    def _conn(self):
        c = sqlite3.connect(self.db_path, timeout=10)
        c.row_factory = sqlite3.Row
        return c

    def publish(self, topic, payload=None, producer="kernel"):
        data = json.dumps(payload or {}, ensure_ascii=False)
        if len(data.encode("utf-8")) > MAX_PAYLOAD:
            raise ZeroCoreError(f"событие {topic}: полезная нагрузка больше {MAX_PAYLOAD} байт")
        c = self._conn()
        try:
            with c:
                cur = c.execute("INSERT INTO events(ts,topic,producer,payload) VALUES(?,?,?,?)",
                                (time.time(), topic, producer, data))
                c.execute("DELETE FROM events WHERE id <= ?", (cur.lastrowid - self.max_events,))
            return cur.lastrowid
        finally:
            c.close()

    def poll(self, consumer, topics=None, limit=100, ack=True):
        c = self._conn()
        try:
            row = c.execute("SELECT last_id FROM cursors WHERE consumer=?", (consumer,)).fetchone()
            last = row["last_id"] if row else 0
            rows = c.execute("SELECT * FROM events WHERE id>? ORDER BY id LIMIT ?", (last, limit * 5)).fetchall()
            out = [r for r in rows if not topics or any(r["topic"].startswith(t) for t in topics)][:limit]
            if ack and out:
                with c:
                    c.execute("INSERT INTO cursors(consumer,last_id) VALUES(?,?) ON CONFLICT(consumer) "
                              "DO UPDATE SET last_id=excluded.last_id", (consumer, out[-1]["id"]))
            return [{"id": r["id"], "ts": r["ts"], "topic": r["topic"], "producer": r["producer"],
                     "payload": json.loads(r["payload"])} for r in out]
        finally:
            c.close()

    def recent(self, n=20):
        c = self._conn()
        try:
            rows = c.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (n,)).fetchall()
            return [{"id": r["id"], "ts": r["ts"], "topic": r["topic"], "producer": r["producer"],
                     "payload": json.loads(r["payload"])} for r in reversed(rows)]
        finally:
            c.close()
