"""Архитектура системы как граф: ядро «Нулевое ядро», модули из реестра, процесс kuni и внешние системы.
Узлы и связи строятся из живых данных (реестр модулей, манифесты, состояние), а не рисуются вручную.
Каждый узел получает рекомендованное место на сетке 24 колонки (слоями сверху вниз), панель может его переопределить."""
import time

from . import providers

STEP = 5   # шаг сетки по колонкам и строкам: узел 4x4 клетки и 1 клетка зазора
SLOTS = [10, 5, 15, 0, 20]   # порядок заполнения слотов в ряду; центр занимает главный модуль

# (id, заголовок, строки описания). Динамические значения подставляются в build().
KUNI_INTERNALS = [
    ("k_telegram", "Telegram-клиент", ["TDLib: чаты, сообщения, медиа", "src/telegram, src/llmui"]),
    ("k_memory", "Память", ["дневник + поиск по смыслу (RAG)", "Diary, #ask"]),
    ("k_cognition", "Цикл ходов", ["AppBase: ход, охранник вызовов", "OpenAIChat, prompts"]),
    ("k_tools", "Инструменты LLM", ["shell, сообщения, внешние", "src/tools"]),
    ("k_media", "Зрение и голос", ["изображения, видео, TTS", "llmui, speech"]),
]
# (a, b, подпись, вид)
STATIC_EDGES = [
    ("telegram", "k_telegram", "TDLib", "ext"), ("llm", "k_cognition", "OpenAI API", "ext"),
    ("k_telegram", "k_cognition", "события", "kuni"), ("k_cognition", "k_memory", "RAG", "kuni"),
    ("k_cognition", "k_tools", "вызовы", "kuni"), ("k_cognition", "k_media", "медиа", "kuni"),
    ("kuni", "k_cognition", "процесс", "kuni"), ("k_tools", "catalog", "tools.json", "tools"),
    ("manager", "contracts", "манифест", "core"), ("manager", "solver", "зависимости", "core"),
    ("manager", "installer", "замена версий", "core"), ("manager", "state", "транзакции", "core"),
    ("manager", "lifecycle", "запуск", "core"), ("manager", "events", "события", "core"),
    ("manager", "catalog", "каталог", "core"), ("registry", "manager", "возможности", "core"),
    ("solver", "registry", "provides/requires", "core"), ("panel", "manager", "управление", "core"),
    ("panel", "events", "журнал", "core"),
]


def _node(nid, title, group, status, lines, **extra):
    n = {"id": nid, "title": title, "group": group, "status": status, "lines": lines}
    n.update(extra)
    return n


def build(manager, kuni_config_toml=None):
    rows = {r["name"]: r for r in manager.status()}
    enabled = set(manager.enabled_names())
    manifests = {}
    for name in rows:
        try:
            manifests[name] = manager.manifest(name)
        except Exception:
            manifests[name] = None
    problems = manager.check_integrity()
    tools = []
    try:
        import json
        tools = json.loads(manager.tools_path().read_text(encoding="utf-8")).get("tools", []) if manager.tools_path().exists() else []
    except (OSError, ValueError):
        pass
    kuni_row = rows.get("kuni")
    kuni_up = bool(kuni_row and kuni_row["enabled"] and kuni_row["running"])
    nodes, edges = [], []

    # ----- модули -----
    names = sorted(rows, key=lambda n: (n != "kuni", n))   # kuni первым: он займёт центральный слот
    mod_rows = max(1, -(-len(names) // len(SLOTS)))
    for i, name in enumerate(names):
        r, m = rows[name], manifests[name]
        row_i, col_i = divmod(i, len(SLOTS))
        slots = SLOTS if row_i == 0 else SLOTS[1:] + SLOTS[:1]
        health = r["health"]
        status = "off" if not r["enabled"] else "bad" if health in ("unhealthy", "broken") else "ok" if (r["running"] or health == "healthy") else "idle"
        lines = []
        if m:
            if m.provides:
                lines.append("даёт: " + ", ".join(m.provides))
            if m.requires:
                lines.append("требует: " + ", ".join(m.requires))
            if m.tools:
                lines.append(f"инструментов: {len(m.tools)}")
            if m.widgets:
                lines.append(f"виджетов: {len(m.widgets)}")
        nodes.append(_node("mod_" + name, name, "module", status, lines, module=name, version=r["version"], kind=r["kind"], enabled=r["enabled"],
                           running=r["running"], health=health, pos={"x": slots[col_i], "y": 2 * STEP + row_i * STEP, "w": 4, "h": 4}))
    base_y = 2 * STEP + mod_rows * STEP   # ниже модулей: ядро

    # ----- внешние системы и процесс kuni -----
    llm = providers.parse_llm(kuni_config_toml) if kuni_config_toml else {"available": False}
    nodes.append(_node("telegram", "Telegram", "external", "ok" if kuni_up else "off", ["сеть Telegram (MTProto)", "через TDLib"], pos={"x": 0, "y": 0, "w": 4, "h": 4}))
    host = (llm.get("host") or "").split("://")[-1]
    nodes.append(_node("llm", "LLM", "external", "ok" if llm.get("available") else "warn",
                       [llm.get("model") or "—", f"{llm.get('provider', '?')} · {host}" if host else str(llm.get("provider", ""))] if llm.get("available")
                       else ["конфигурация не найдена"], pos={"x": 20, "y": 0, "w": 4, "h": 4}))
    xs = [0, 5, 10, 15, 20]
    for x, (nid, title, lines) in zip(xs, KUNI_INTERNALS):
        nodes.append(_node(nid, title, "kuni", "ok" if kuni_up else "off", lines, pos={"x": x, "y": STEP, "w": 4, "h": 4}))

    # ----- ядро и менеджер -----
    caps = sum(len(manifests[n].provides) for n in enabled if manifests.get(n))
    running = sum(1 for n in enabled if rows[n]["running"])
    events_n = len(manager.bus.recent(1000))
    versions_n = sum(len(r["versions"]) for r in rows.values())
    widgets_n = sum(len(manifests[n].widgets) for n in enabled if manifests.get(n))
    kernel = [
        ("state", "Состояние", "kernel", "ok", [f"модулей: {len(rows)}, включено: {len(enabled)}", "kernel/txn.py"], 0, 0),
        ("registry", "Реестр возможностей", "kernel", "ok", [f"возможностей: {caps}", "kernel/service_registry.py"], 1, 0),
        ("manager", "Менеджер модулей", "manager", "ok", [f"установлено: {len(rows)}", "module_manager/manager.py"], 2, 0),
        ("panel", "Веб-панель", "manager", "ok", ["WebUI, API с токеном", "admin/server.py"], 3, 0),
        ("catalog", "Каталог инструментов", "manager", "ok" if tools or manager.tools_path().exists() else "idle",
         [f"инструментов: {len(tools)}", "tools.json → kuni"], 4, 0),
        ("contracts", "Контракты", "kernel", "ok", [f"виджетов: {widgets_n}, инструментов: {len(tools)}", "kernel/contracts.py"], 0, 1),
        ("solver", "Решатель зависимостей", "manager", "bad" if problems else "ok",
         [problems[0][:44] if problems else "целостность: ОК", "dependency_solver.py"], 1, 1),
        ("installer", "Установка и откат", "manager", "ok", [f"версий в наличии: {versions_n}", "installer, hot_swap, rollback"], 2, 1),
        ("lifecycle", "Жизненный цикл", "kernel", "ok", [f"запущено: {running} из {len(enabled)}", "kernel/lifecycle.py, health.py"], 3, 1),
        ("events", "Шина событий", "kernel", "ok", [f"в журнале: {events_n}", "kernel/event_bus.py"], 4, 1),
    ]
    for nid, title, group, status, lines, col, krow in kernel:
        nodes.append(_node(nid, title, group, status, lines, pos={"x": xs[col], "y": base_y + krow * STEP, "w": 4, "h": 4}))

    # ----- связи -----
    ids = {n["id"] for n in nodes}
    # kuni как процесс: «kuni» в STATIC_EDGES означает модуль kuni
    alias = {"kuni": "mod_kuni"}
    for a, b, label, kind in STATIC_EDGES:
        a, b = alias.get(a, a), alias.get(b, b)
        if a in ids and b in ids:
            edges.append({"a": a, "b": b, "label": label, "kind": kind})
    provider = {}
    for n in enabled:
        for cap in (manifests.get(n).provides if manifests.get(n) else []):
            provider[cap] = n
    for name in names:
        m = manifests[name]
        edges.append({"a": "manager", "b": "mod_" + name, "label": "управляет", "kind": "manage"})
        if not m:
            continue
        for cap in m.requires:
            if cap in provider and provider[cap] != name:
                edges.append({"a": "mod_" + name, "b": "mod_" + provider[cap], "label": cap, "kind": "dep"})
        if m.tools and name in enabled:
            edges.append({"a": "mod_" + name, "b": "catalog", "label": "инструменты", "kind": "tools"})
        if m.widgets and name in enabled:
            edges.append({"a": "mod_" + name, "b": "panel", "label": "виджеты", "kind": "widgets"})
    state = {n["id"]: n for n in nodes}
    for e in edges:
        e["off"] = state[e["a"]]["status"] == "off" or state[e["b"]]["status"] == "off"
    return {"nodes": nodes, "edges": edges, "generated": round(time.time(), 1)}
