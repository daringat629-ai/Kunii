/* Раскладка виджетов: сетка 24 колонки, единицы клетки. Чистая логика без DOM, поэтому проверяется в node. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ZCLayout = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var COLS = 24, MIN_W = 3, MIN_H = 3, MAX_ROWS = 400, MAX_H = 60;

  function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
  function copy(layout) {
    var out = {};
    Object.keys(layout).forEach(function (k) { out[k] = { x: layout[k].x, y: layout[k].y, w: layout[k].w, h: layout[k].h }; });
    return out;
  }
  function clampRect(r, cols) {
    cols = cols || COLS;
    var w = clamp(Math.round(r.w), MIN_W, cols);
    var h = clamp(Math.round(r.h), MIN_H, MAX_H);
    return { x: clamp(Math.round(r.x), 0, cols - w), y: clamp(Math.round(r.y), 0, MAX_ROWS), w: w, h: h };
  }
  function overlaps(a, b) {
    return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  }
  function findFreeSpot(layout, w, h, cols) {
    cols = cols || COLS;
    var ids = Object.keys(layout);
    for (var y = 0; y <= MAX_ROWS; y++) {
      for (var x = 0; x + w <= cols; x++) {
        var cand = { x: x, y: y, w: w, h: h };
        var free = true;
        for (var i = 0; i < ids.length; i++) {
          if (overlaps(cand, layout[ids[i]])) { free = false; break; }
        }
        if (free) return cand;
      }
    }
    return { x: 0, y: MAX_ROWS, w: w, h: h };
  }
  /* Сдвигает вниз всё, что пересеклось с перемещённым виджетом (каскадно). */
  function resolveCollisions(layout, movedId) {
    var out = copy(layout), queue = [movedId], guard = 0;
    while (queue.length && guard++ < 5000) {
      var id = queue.shift(), r = out[id];
      Object.keys(out).forEach(function (other) {
        if (other === id) return;
        if (overlaps(r, out[other])) { out[other].y = r.y + r.h; queue.push(other); }
      });
    }
    return out;
  }
  function sanitizeLayout(raw, knownIds, cols) {
    var out = {};
    if (!raw || typeof raw !== 'object') return out;
    knownIds.forEach(function (id) {
      var r = raw[id];
      if (r && [r.x, r.y, r.w, r.h].every(function (v) { return typeof v === 'number' && isFinite(v); })) {
        out[id] = clampRect(r, cols);
      }
    });
    return out;
  }
  /* items: [{id, w, h}] в порядке показа. Сохранённые позиции сохраняются, остальные ставятся в свободные места. */
  function mergeLayout(saved, items, cols) {
    var layout = sanitizeLayout(saved, items.map(function (i) { return i.id; }), cols);
    items.forEach(function (it) {
      if (layout[it.id]) return;
      if (typeof it.x === 'number' && typeof it.y === 'number') {   // рекомендованное место (узлы архитектуры), если оно свободно
        var cand = clampRect({ x: it.x, y: it.y, w: it.w, h: it.h }, cols);
        if (Object.keys(layout).every(function (k) { return !overlaps(cand, layout[k]); })) { layout[it.id] = cand; return; }
      }
      layout[it.id] = findFreeSpot(layout, it.w, it.h, cols);
    });
    return layout;
  }
  function pxToCells(dx, dy, cellW, rowH) {
    return { dx: Math.round(dx / cellW) || 0, dy: Math.round(dy / rowH) || 0 };   // || 0: без отрицательного нуля
  }
  function rectToPx(r, cellW, rowH, gap) {
    gap = gap || 0;
    return { left: r.x * cellW + gap / 2, top: r.y * rowH + gap / 2, width: r.w * cellW - gap, height: r.h * rowH - gap };
  }
  function boardRows(layout) {
    var m = 0;
    Object.keys(layout).forEach(function (k) { m = Math.max(m, layout[k].y + layout[k].h); });
    return m;
  }
  /* ---------- нити между виджетами ---------- */
  // какие виджеты связаны (нить рисуется, только если оба показаны); виджеты плагинов (m:*) связаны с «Плагинами»
  var THREAD_PAIRS = [['system', 'plugins'], ['plugins', 'log'], ['plugins', 'load'], ['stats', 'log'], ['system', 'stats'],
                      ['transports', 'plugins'], ['llm', 'transports'], ['generation', 'llm'], ['plugins', 'tools']];
  function threadPairs(ids) {
    var has = {}, out = [];
    ids.forEach(function (id) { has[id] = true; });
    THREAD_PAIRS.forEach(function (p) { if (has[p[0]] && has[p[1]]) out.push({ a: p[0], b: p[1], kind: 'core' }); });
    if (has.plugins) ids.forEach(function (id) { if (id.indexOf('m:') === 0) out.push({ a: 'plugins', b: id, kind: 'module' }); });
    return out;
  }
  /* ra, rb: прямоугольники в пикселях {left, top, width, height}. Возвращает 4 точки кубической кривой Безье. */
  function threadCurve(ra, rb) {
    var ca = { x: ra.left + ra.width / 2, y: ra.top + ra.height / 2 }, cb = { x: rb.left + rb.width / 2, y: rb.top + rb.height / 2 };
    var rightOfA = ra.left + ra.width, rightOfB = rb.left + rb.width, bottomOfA = ra.top + ra.height, bottomOfB = rb.top + rb.height;
    var sepX = cb.x >= ca.x ? rb.left - rightOfA : ra.left - rightOfB;   // зазор по горизонтали (может быть отрицательным)
    var sepY = cb.y >= ca.y ? rb.top - bottomOfA : ra.top - bottomOfB;
    var horizontal = sepX > 0 && (sepX >= sepY || sepY <= 0);
    var p0, p3, c1, c2, k;
    if (horizontal) {
      var sx = cb.x >= ca.x ? 1 : -1;
      p0 = [sx > 0 ? rightOfA : ra.left, ca.y]; p3 = [sx > 0 ? rb.left : rightOfB, cb.y];
      k = Math.max(40, Math.abs(p3[0] - p0[0]) * 0.5);
      c1 = [p0[0] + sx * k, p0[1]]; c2 = [p3[0] - sx * k, p3[1]];
    } else {
      var sy = cb.y >= ca.y ? 1 : -1;
      p0 = [ca.x, sy > 0 ? bottomOfA : ra.top]; p3 = [cb.x, sy > 0 ? rb.top : bottomOfB];
      k = Math.max(40, Math.abs(p3[1] - p0[1]) * 0.5);
      c1 = [p0[0], p0[1] + sy * k]; c2 = [p3[0], p3[1] - sy * k];
    }
    return [p0, c1, c2, p3];
  }
  function bezierPoint(p, t) {
    var u = 1 - t, a = u * u * u, b = 3 * u * u * t, c = 3 * u * t * t, d = t * t * t;
    return [a * p[0][0] + b * p[1][0] + c * p[2][0] + d * p[3][0], a * p[0][1] + b * p[1][1] + c * p[2][1] + d * p[3][1]];
  }
  return { threadPairs: threadPairs, threadCurve: threadCurve, bezierPoint: bezierPoint, THREAD_PAIRS: THREAD_PAIRS, COLS: COLS, MIN_W: MIN_W, MIN_H: MIN_H, clampRect: clampRect, overlaps: overlaps, findFreeSpot: findFreeSpot,
           resolveCollisions: resolveCollisions, sanitizeLayout: sanitizeLayout, mergeLayout: mergeLayout,
           pxToCells: pxToCells, rectToPx: rectToPx, boardRows: boardRows, copy: copy };
});
