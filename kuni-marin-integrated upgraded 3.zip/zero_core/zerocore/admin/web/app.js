/* Панель «Нулевое ядро»: сетка перетаскиваемых виджетов. Без внешних библиотек и без innerHTML. */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.ZC = api;
    if (root.document && !root.__ZC_NO_BOOT) {
      api.boot({ document: root.document, window: root, fetch: root.fetch.bind(root), storage: root.localStorage,
                 setInterval: root.setInterval.bind(root), setTimeout: root.setTimeout.bind(root),
                 location: root.location, history: root.history,
                 Layout: root.ZCLayout, requestAnimationFrame: root.requestAnimationFrame && root.requestAnimationFrame.bind(root),
                 reducedMotion: !!(root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches) });
    }
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var ROW_H = 30, DEFAULT_GAP = 14;
  /* Цвета нитей (canvas не видит CSS-переменные) */
  var KIND_RGB = { dep: '61,220,132', tools: '255,183,77', widgets: '199,146,234', ext: '255,183,77', kuni: '199,146,234' };
  var THREAD_COLORS = {
    black: { line: 'rgba(110,168,255,0.55)', glow: 'rgba(110,168,255,0.12)', module: 'rgba(61,220,132,0.6)', pulse: 'rgba(200,225,255,0.95)', hot: 'rgba(170,205,255,0.95)', hotGlow: 'rgba(110,168,255,0.30)', label: 'rgba(175,195,235,0.95)', labelBg: 'rgba(0,0,0,0.78)', err: 'rgba(255,107,107,0.97)' },
    dark: { line: 'rgba(122,162,255,0.55)', glow: 'rgba(122,162,255,0.12)', module: 'rgba(88,214,141,0.6)', pulse: 'rgba(205,220,255,0.95)', hot: 'rgba(175,200,255,0.95)', hotGlow: 'rgba(122,162,255,0.30)', label: 'rgba(175,195,235,0.95)', labelBg: 'rgba(7,11,28,0.78)', err: 'rgba(255,107,107,0.97)' },
    light: { line: 'rgba(47,85,212,0.5)', glow: 'rgba(47,85,212,0.10)', module: 'rgba(30,142,78,0.6)', pulse: 'rgba(47,85,212,0.95)', hot: 'rgba(47,85,212,0.95)', hotGlow: 'rgba(47,85,212,0.25)', label: 'rgba(40,52,110,0.95)', labelBg: 'rgba(238,241,251,0.85)', err: 'rgba(192,57,43,0.97)' }
  };
  var I18N = {
    ru: { app: 'Нулевое ядро', system: 'Система', llm: 'LLM', transports: 'Транспорты', generation: 'Генерация',
          stats: 'Статистика', load: 'График нагрузки', log: 'Живой лог', plugins: 'Плагины', tools: 'Тулы',
          settings: 'Настройки', language: 'Язык', theme: 'Тема', dark: 'Тёмная', light: 'Светлая', black: 'Чёрная', gap: 'Отступ между виджетами', view_panel: 'Панель', view_arch: 'Архитектура', node_ok: 'в норме', node_idle: 'ожидает', node_warn: 'внимание', node_bad: 'ошибка', node_off: 'не активен', confirm_title: 'Подтверждение', log_lines: 'Строк в логе',
          save: 'Сохранить', cancel: 'Отмена', reset_layout: 'Сбросить раскладку', change_token: 'Сменить токен',
          token_title: 'Вход', token_hint: 'Токен панели (файл panel_token)', enter: 'Войти', hide: 'Скрыть',
          restore: 'Скрытые виджеты', nothing_hidden: 'Скрытых виджетов нет', close: 'Закрыть', show: 'Показать',
          version: 'версия', os: 'ОС', home: 'каталог', uptime: 'работает', modules: 'модулей', integrity: 'целостность',
          host: 'хост', provider: 'провайдер', model: 'модель', endpoint: 'адрес', embedding: 'эмбеддинги', lockdown: 'доступ',
          none: 'нет', no_data: 'нет данных', generating: 'идёт генерация', idle: 'нет активной генерации',
          last_gen: 'последняя', ago: 'назад', s: 'с', min: 'мин', h: 'ч',
          st_llm_today: 'запросов к LLM сегодня', st_shell: 'команд shell (сессия)', st_sent: 'сообщений отправлено (сессия)',
          st_external: 'вызовов внешних инструментов (сессия)', st_refused: 'отказов охранника (сессия)', st_http: 'ошибок LLM (сессия)', st_errors: 'ошибок (сессия)',
          running: 'работает', stopped: 'остановлен', enable: 'включить', disable: 'выключить', start: 'запустить',
          stop: 'остановить', restart: 'перезапустить', confirm: 'Выполнить', error: 'Ошибка', updated: 'обновлено',
          rss: 'память kuni', all: 'все', core_src: 'ядро', kuni_src: 'kuni', tools_count: 'инструментов' },
    en: { app: 'Zero Core', system: 'System', llm: 'LLM', transports: 'Transports', generation: 'Generation',
          stats: 'Statistics', load: 'Load graph', log: 'Live log', plugins: 'Plugins', tools: 'Tools',
          settings: 'Settings', language: 'Language', theme: 'Theme', dark: 'Dark', light: 'Light', black: 'Black', gap: 'Widget spacing', view_panel: 'Panel', view_arch: 'Architecture', node_ok: 'healthy', node_idle: 'idle', node_warn: 'attention', node_bad: 'error', node_off: 'inactive', confirm_title: 'Confirmation', log_lines: 'Log lines',
          save: 'Save', cancel: 'Cancel', reset_layout: 'Reset layout', change_token: 'Change token',
          token_title: 'Sign in', token_hint: 'Panel token (panel_token file)', enter: 'Enter', hide: 'Hide',
          restore: 'Hidden widgets', nothing_hidden: 'No hidden widgets', close: 'Close', show: 'Show',
          version: 'version', os: 'OS', home: 'home', uptime: 'uptime', modules: 'modules', integrity: 'integrity',
          host: 'host', provider: 'provider', model: 'model', endpoint: 'endpoint', embedding: 'embeddings', lockdown: 'access',
          none: 'none', no_data: 'no data', generating: 'generating', idle: 'no active generation',
          last_gen: 'last', ago: 'ago', s: 's', min: 'min', h: 'h',
          st_llm_today: 'LLM requests today', st_shell: 'shell commands (session)', st_sent: 'messages sent (session)',
          st_external: 'external tool calls (session)', st_refused: 'guard refusals (session)', st_http: 'LLM errors (session)', st_errors: 'errors (session)',
          running: 'running', stopped: 'stopped', enable: 'enable', disable: 'disable', start: 'start',
          stop: 'stop', restart: 'restart', confirm: 'Run', error: 'Error', updated: 'updated',
          rss: 'kuni memory', all: 'all', core_src: 'core', kuni_src: 'kuni', tools_count: 'tools' }
  };

  function h(doc, tag, attrs, children) {
    var el = doc.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'on') Object.keys(v).forEach(function (ev) { el.addEventListener(ev, v[ev]); });
      else if (k === 'style') Object.keys(v).forEach(function (s) { el.style[s] = v[s]; });
      else if (k === 'value') el.value = v;
      else if (k === 'disabled') el.disabled = !!v;
      else el.setAttribute(k, v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined) return;
      el.appendChild(typeof c === 'string' ? doc.createTextNode(c) : c);
    });
    return el;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(sec) {
    if (sec === null || sec === undefined) return '--:--:--';
    var d = new Date(sec * 1000);
    return pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
  }

  function boot(env) {
    var doc = env.document, L = env.Layout;
    /* Токен из адреса вида http://127.0.0.1:8767/#token=...: нужен киоску на экране ноутбука (без ввода с клавиатуры). Сохраняется и убирается из адреса. */
    var hashMatch = /[#&]token=([^&]+)/.exec((env.location && env.location.hash) || '');
    if (hashMatch) {
      try { env.storage.setItem('zc_token', decodeURIComponent(hashMatch[1])); } catch (e) { /* хранилище недоступно: токен спросят окном */ }
      if (env.history && env.history.replaceState) env.history.replaceState(null, '', env.location.pathname + (env.location.search || ''));
    }
    var board = doc.getElementById('board'), topbar = doc.getElementById('topbar'), overlay = doc.getElementById('overlay');
    var S = { token: env.storage.getItem('zc_token') || '', settings: { language: 'ru', theme: 'dark', log_lines: 200, gap: DEFAULT_GAP, view: 'panel', layout: {}, hidden: [] },
              defs: [], nodes: {}, layout: {}, modules: [], stacked: false, cellW: 50, logFilter: 'all', statusTimer: null,
              threads: [], dragId: null, shock: null, animating: false, lastDraw: 0, reduced: !!env.reducedMotion,
              archDefs: [], arch: null, archById: {}, archNext: 0, bursts: [], activitySince: 0, activityNext: 0 };
    var statusEl = null;

    function t(key) { return (I18N[S.settings.language] || I18N.ru)[key] || key; }

    // ---------- сеть ----------
    function api(path, opts) {
      opts = opts || {};
      var init = { method: opts.method || 'GET', headers: { 'X-Token': S.token } };
      if (opts.body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opts.body); }
      return env.fetch(path, init).then(function (resp) {
        return resp.json().then(function (data) {
          if (resp.status === 401) { showLogin(); throw new Error('401'); }
          if (!resp.ok) throw new Error((data && data.error) || String(resp.status));
          return data;
        });
      });
    }
    function setStatus(msg, isErr) {
      if (!statusEl) return;
      statusEl.textContent = msg;
      statusEl.className = 'status' + (isErr ? ' err' : '');
      if (S.statusTimer && env.clearTimeout) env.clearTimeout(S.statusTimer);
      if (isErr && env.setTimeout) S.statusTimer = env.setTimeout(function () { statusEl.className = 'status'; }, 8000);
    }
    function saveSettings(patch) {
      return api('/api/settings', { method: 'POST', body: patch }).then(function (s) { S.settings = s; return s; })
        .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }

    // ---------- окна ----------
    function closeOverlay() { overlay.hidden = true; clear(overlay); }
    function openModal(title, content, buttons) {
      clear(overlay);
      overlay.hidden = false;
      overlay.appendChild(h(doc, 'div', { class: 'modal' }, [h(doc, 'h3', { text: title })].concat(content)
        .concat([h(doc, 'div', { class: 'buttons' }, buttons)])));
    }
    function showLogin() {
      var input = h(doc, 'input', { type: 'password', id: 'token-input', placeholder: t('token_hint') });
      function submit() {
        var v = (input.value || '').trim();
        if (!v) return;
        S.token = v;
        env.storage.setItem('zc_token', v);
        closeOverlay();
        start();
      }
      openModal(t('token_title'), [h(doc, 'div', { class: 'dim', text: t('token_hint') }), input],
                [h(doc, 'button', { class: 'btn', id: 'token-submit', text: t('enter'), on: { click: submit } })]);
    }
    function showSettings() {
      var lang = h(doc, 'select', { id: 's-lang' }, [h(doc, 'option', { value: 'ru', text: 'Русский' }), h(doc, 'option', { value: 'en', text: 'English' })]);
      var theme = h(doc, 'select', { id: 's-theme' }, [h(doc, 'option', { value: 'dark', text: t('dark') }), h(doc, 'option', { value: 'light', text: t('light') }),
        h(doc, 'option', { value: 'black', text: t('black') })]);
      var lines = h(doc, 'input', { type: 'number', id: 's-lines' });
      var gapIn = h(doc, 'input', { type: 'number', id: 's-gap' });
      lang.value = S.settings.language; theme.value = S.settings.theme; lines.value = S.settings.log_lines; gapIn.value = gapOf();
      openModal(t('settings'), [
        h(doc, 'label', {}, [t('language'), lang]), h(doc, 'label', {}, [t('theme'), theme]), h(doc, 'label', {}, [t('log_lines'), lines]), h(doc, 'label', {}, [t('gap'), gapIn])
      ], [
        h(doc, 'button', { class: 'btn danger', text: t('change_token'), on: { click: function () { env.storage.setItem('zc_token', ''); S.token = ''; showLogin(); } } }),
        h(doc, 'button', { class: 'btn danger', id: 's-reset', text: t('reset_layout'), on: { click: function () {
          S.settings.layout = {}; closeOverlay(); saveSettings({ layout: {} }).then(function () { relayout(); }); } } }),
        h(doc, 'button', { class: 'btn', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn', id: 's-save', text: t('save'), on: { click: function () {
          var g = parseInt(gapIn.value, 10);
          saveSettings({ language: lang.value, theme: theme.value, log_lines: parseInt(lines.value, 10) || 200, gap: isNaN(g) ? DEFAULT_GAP : g }).then(function () {
            closeOverlay(); applyTheme(); buildTopbar(); rebuildAll(); }); } } })
      ]);
    }
    function showHidden() {
      var hidden = S.settings.hidden, rows = [];
      if (!hidden.length) rows.push(h(doc, 'div', { class: 'dim', text: t('nothing_hidden') }));
      hidden.forEach(function (id) {
        var def = S.defs.concat(S.archDefs).filter(function (d) { return d.id === id; })[0];
        rows.push(h(doc, 'div', { class: 'row' }, [h(doc, 'span', { class: 'grow', text: def ? title(def) : id }),
          h(doc, 'button', { class: 'btn', text: t('show'), on: { click: function () {
            S.settings.hidden = S.settings.hidden.filter(function (x) { return x !== id; });
            saveSettings({ hidden: S.settings.hidden }).then(function () { closeOverlay(); rebuildAll(); }); } } })]));
      });
      openModal(t('restore'), rows, [h(doc, 'button', { class: 'btn', text: t('close'), on: { click: closeOverlay } })]);
    }

    // ---------- верхняя панель ----------
    function applyTheme() { doc.body.className = 'theme-' + S.settings.theme; }
    function buildTopbar() {
      clear(topbar);
      statusEl = h(doc, 'span', { class: 'status', text: '' });
      topbar.appendChild(h(doc, 'span', { class: 'brand', text: t('app') }));
      topbar.appendChild(h(doc, 'span', { class: 'badge', text: 'WebUI' }));
      ['panel', 'arch'].forEach(function (v) {
        topbar.appendChild(h(doc, 'button', { class: 'btn tab' + (S.settings.view === v ? ' active' : ''), id: 'tab-' + v, text: t('view_' + v), on: { click: function () { setView(v); } } }));
      });
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-hidden', text: '＋', title: t('restore'), on: { click: showHidden } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-settings', text: '⚙', title: t('settings'), on: { click: showSettings } }));
      topbar.appendChild(h(doc, 'button', { class: 'btn', id: 'btn-refresh', text: '⟳', on: { click: function () { refreshAll(); } } }));
      topbar.appendChild(statusEl);
    }

    // ---------- отрисовка содержимого ----------
    function kv(rows) {
      return h(doc, 'table', { class: 'kv' }, rows.map(function (r) {
        return h(doc, 'tr', {}, [h(doc, 'td', { class: 'k', text: String(r[0]) }), h(doc, 'td', { class: 'v', text: String(r[1]) })]);
      }));
    }
    function dot(cls) { return h(doc, 'span', { class: 'dot ' + (cls || '') }); }
    function fmtDur(sec) {
      if (sec < 90) return sec + ' ' + t('s');
      if (sec < 5400) return Math.round(sec / 60) + ' ' + t('min');
      return Math.floor(sec / 3600) + ' ' + t('h') + ' ' + Math.round((sec % 3600) / 60) + ' ' + t('min');
    }
    function text(body, msg, cls) { body.appendChild(h(doc, 'div', { class: cls || '', text: msg })); }

    function renderSystem(body, d) {
      var host = d.host || {};
      body.appendChild(kv([
        [t('version'), d.zerocore], ['Python', d.python], [t('os'), d.os], ['PID', d.pid], [t('home'), d.home],
        [t('uptime'), fmtDur(d.uptime)], [t('modules'), d.enabled + ' / ' + d.modules],
        [t('integrity'), d.integrity && d.integrity.length ? d.integrity.join('; ') : 'OK'],
        [t('host'), 'load ' + (host.load1 === null ? '?' : host.load1) + ' · RAM ' + (host.mem_pct === null ? '?' : host.mem_pct + '%')]
      ]));
    }
    function renderLlm(body, d) {
      if (!d.available) return text(body, d.error || t('no_data'), 'dim');
      body.appendChild(kv([[t('provider'), d.provider], [t('model'), d.model], [t('endpoint'), d.host],
                           [t('embedding'), d.embedding_model + (d.embedding_host ? ' @ ' + d.embedding_host : '')], [t('lockdown'), d.lockdown]]));
    }
    function renderTransports(body, d) {
      if (!d.length) return text(body, t('none'), 'dim');
      d.forEach(function (x) {
        body.appendChild(h(doc, 'div', { class: 'row' }, [dot(x.running ? 'ok' : 'bad'), h(doc, 'span', { class: 'grow', text: x.name }),
          h(doc, 'span', { class: 'dim', text: x.capability })]));
      });
    }
    function renderStats(body, d) {
      body.appendChild(kv([[t('st_llm_today'), d.llm_requests_today], [t('st_shell'), d.shell_commands], [t('st_sent'), d.messages_sent], [t('st_external'), d.external_calls || 0],
                           [t('st_refused'), d.guard_refusals], [t('st_http'), d.llm_http_errors], [t('st_errors'), d.errors]]));
    }
    function renderGeneration(body, d) {
      if (!d.known) return text(body, t('no_data'), 'dim');
      if (d.active) return body.appendChild(h(doc, 'div', {}, [dot('warn'), t('generating') + ' · ' + Math.round(d.since) + ' ' + t('s')]));
      body.appendChild(h(doc, 'div', {}, [dot(''), t('idle')]));
      if (d.last_seconds !== null && d.last_seconds !== undefined) text(body, t('last_gen') + ': ' + d.last_seconds + ' ' + t('s') + (d.ago !== undefined ? ' · ' + fmtDur(d.ago) + ' ' + t('ago') : ''), 'dim');
    }
    function spark(canvas, series, color, max) {
      var ctx = canvas.getContext('2d'), w = canvas.width, hgt = canvas.height;
      ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.beginPath();
      var started = false;
      series.forEach(function (v, i) {
        if (v === null || v === undefined) return;
        var x = series.length < 2 ? 0 : (i / (series.length - 1)) * (w - 2) + 1, y = hgt - 2 - Math.min(1, v / max) * (hgt - 4);
        if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
      });
      ctx.stroke();
    }
    function renderLoad(body, pts) {
      if (!pts.length) return text(body, t('no_data'), 'dim');
      var canvas = h(doc, 'canvas', { class: 'spark', width: 600, height: 100 });
      body.appendChild(canvas);
      var loads = pts.map(function (p) { return p.load1; }), maxLoad = Math.max.apply(null, [1].concat(loads.filter(function (v) { return v !== null; })));
      spark(canvas, loads, '#7aa2ff', maxLoad);
      spark(canvas, pts.map(function (p) { return p.mem; }), '#58d68d', 100);
      var last = pts[pts.length - 1];
      body.appendChild(h(doc, 'div', { class: 'legend', text: 'load ' + last.load1 + ' (max ' + maxLoad.toFixed(1) + ') · RAM ' + last.mem + '% · ' + t('rss') + ' ' + (last.rss === null ? '—' : last.rss + ' MB') }));
    }
    function renderLog(body, rows, ctx) {
      var st = ctx.def.state;
      if (!st.lines) {
        st.lines = h(doc, 'div', { class: 'loglines' });
        var sel = h(doc, 'select', { id: 'log-filter' }, ['all', 'core', 'kuni'].map(function (v) {
          return h(doc, 'option', { value: v, text: v === 'all' ? t('all') : v === 'core' ? t('core_src') : t('kuni_src') }); }));
        sel.value = S.logFilter;
        sel.addEventListener('change', function () { S.logFilter = sel.value; refreshDef(ctx.def); });
        st.bar = h(doc, 'div', { class: 'logbar' }, [sel]);
      }
      clear(st.lines);
      rows.filter(function (r) { return S.logFilter === 'all' || r.src === S.logFilter; }).forEach(function (r) {
        var cls = /\[(ERR|ERROR)\]|HTTP_[45]/.test(r.text) ? 'bad' : /\[WARN\]/.test(r.text) ? 'warn' : r.src === 'core' ? 'core' : '';
        st.lines.appendChild(h(doc, 'div', { class: 'logline ' + cls }, [h(doc, 'span', { class: 'ts', text: fmtTime(r.t) }), r.text]));
      });
      body.appendChild(st.bar);
      body.appendChild(st.lines);
      body.scrollTop = body.scrollHeight;
    }
    /* Подтверждение: окно внутри панели (в тон теме, работает на телефоне); env.confirm, если задан, имеет приоритет (тесты). */
    function confirmAction(message, onYes) {
      if (env.confirm) { if (env.confirm(message)) onYes(); return; }
      openModal(t('confirm_title'), [h(doc, 'div', { text: message })], [
        h(doc, 'button', { class: 'btn', id: 'confirm-no', text: t('cancel'), on: { click: closeOverlay } }),
        h(doc, 'button', { class: 'btn danger', id: 'confirm-yes', text: t('confirm'), on: { click: function () { closeOverlay(); onYes(); } } })
      ]);
    }
    function moduleAction(name, action) {
      var risky = action === 'stop' || action === 'disable' || action === 'restart';
      if (risky) return confirmAction(t(action) + ' ' + name + '?', function () { runModuleAction(name, action); });
      runModuleAction(name, action);
    }
    function runModuleAction(name, action) {
      setStatus(t(action) + ' ' + name + '…', false);
      api('/api/modules/' + name + '/' + action, { method: 'POST', body: action === 'disable' ? { cascade: false } : {} })
        .then(function () { setStatus('OK: ' + t(action) + ' ' + name, false); return syncModules(); })
        .then(function () { refreshAll(); })
        .catch(function (e) { setStatus(t('error') + ': ' + e.message, true); });
    }
    function moduleDotClass(m) { return !m.enabled ? '' : m.health === 'healthy' ? 'ok' : (m.health === 'unhealthy' || m.health === 'broken') ? 'bad' : m.running ? 'ok' : 'warn'; }
    function moduleButtons(m) {
      var btns = [h(doc, 'button', { class: 'btn', text: m.enabled ? t('disable') : t('enable'), on: { click: function () { moduleAction(m.name, m.enabled ? 'disable' : 'enable'); } } })];
      if (m.enabled && (m.kind === 'service' || m.kind === 'external')) {
        btns.push(h(doc, 'button', { class: 'btn', text: m.running ? t('stop') : t('start'), on: { click: function () { moduleAction(m.name, m.running ? 'stop' : 'start'); } } }));
        if (m.running) btns.push(h(doc, 'button', { class: 'btn', text: t('restart'), on: { click: function () { moduleAction(m.name, 'restart'); } } }));
      }
      return btns;
    }
    function moduleRow(m) {
      return h(doc, 'div', { class: 'row', 'data-owner': m.name }, [dot(moduleDotClass(m)), h(doc, 'span', { class: 'grow', text: m.name + ' ' + m.version, title: m.detail || '' }),
        h(doc, 'span', { class: 'dim', text: m.kind + ' · ' + m.health }), h(doc, 'span', {}, moduleButtons(m))]);
    }
    function renderPlugins(body, mods) {
      mods.forEach(function (m) { body.appendChild(moduleRow(m)); });
    }
    /* Узел архитектуры: состояние, описание, у модулей те же кнопки, что в «Плагинах». */
    function renderArchNode(body, n, ctx) {
      var node = S.nodes[ctx.def.id];
      if (node) {
        ['grp-kernel', 'grp-manager', 'grp-module', 'grp-kuni', 'grp-external'].forEach(function (c) { node.el.classList.remove(c); });
        node.el.classList.add('grp-' + n.group);
        if (n.status === 'off') node.el.classList.add('off'); else node.el.classList.remove('off');
      }
      if (n.module) {   // узкая карточка: имя уже в заголовке, поэтому состояние, кнопки и описание идут отдельными строками
        var m = { name: n.module, version: n.version, kind: n.kind, enabled: n.enabled, running: n.running, health: n.health, detail: '' };
        body.appendChild(h(doc, 'div', { class: 'row' }, [dot(moduleDotClass(m)), h(doc, 'span', { class: 'grow', text: m.version + ' · ' + m.kind }), h(doc, 'span', { class: 'dim', text: m.health })]));
        body.appendChild(h(doc, 'div', { class: 'row', 'data-owner': m.name }, [h(doc, 'span', {}, moduleButtons(m))]));
      } else {
        var cls = n.status === 'ok' ? 'ok' : n.status === 'bad' ? 'bad' : (n.status === 'warn' || n.status === 'idle') ? 'warn' : '';
        body.appendChild(h(doc, 'div', { class: 'row' }, [dot(cls), h(doc, 'span', { class: 'grow', text: t('node_' + n.status) })]));
      }
      (n.lines || []).forEach(function (line) { if (line) body.appendChild(h(doc, 'div', { class: 'dim', text: line })); });
    }
    function renderTools(body, tools) {
      if (!tools.length) return text(body, t('no_data'), 'dim');
      text(body, t('tools_count') + ': ' + tools.length, 'dim');
      tools.forEach(function (x) { body.appendChild(h(doc, 'div', { class: 'row', title: x.description }, [h(doc, 'span', { text: '▸ ' + x.name })])); });
    }
    function renderModuleWidget(body, d, ctx) {
      if (!d.ok) return text(body, t('error') + ': ' + d.error, 'err');
      if (d.kind === 'kv') body.appendChild(kv(d.data.items));
      else if (d.kind === 'text') body.appendChild(h(doc, 'pre', { text: d.data.text }));
      else if (d.kind === 'table') {
        body.appendChild(h(doc, 'table', { class: 'grid' }, [h(doc, 'tr', {}, d.data.columns.map(function (c) { return h(doc, 'th', { text: String(c) }); }))]
          .concat(d.data.rows.map(function (r) { return h(doc, 'tr', {}, r.map(function (c) { return h(doc, 'td', { text: String(c) }); })); }))));
      } else if (d.kind === 'counter') {
        body.appendChild(h(doc, 'div', { class: 'counter-value', text: String(d.data.value) }));
        body.appendChild(h(doc, 'div', { class: 'counter-label', text: d.data.label || '' }));
      }
      if (d.actions && d.actions.length) {
        body.appendChild(h(doc, 'div', { class: 'actions' }, d.actions.map(function (a) {
          return h(doc, 'button', { class: 'btn', text: a.label, on: { click: function () {
            api('/api/widget/' + ctx.def.mod + '/' + ctx.def.wid + '/action/' + a.id, { method: 'POST', body: {} })
              .then(function (res) { renderInto(ctx.def, res); }).catch(function (e) { setStatus(t('error') + ': ' + e.message, true); }); } } });
        })));
      }
      if (d.note) body.appendChild(h(doc, 'div', { class: 'note', text: d.note }));
    }

    // ---------- описания виджетов ----------
    function builtinDefs() {
      function d(id, w, hgt, refresh, load, render) { return { id: id, title: id, w: w, h: hgt, refresh: refresh, load: load, render: render, state: {}, next: 0, builtin: true }; }
      return [
        d('system', 8, 9, 10, function () { return api('/api/system'); }, renderSystem),
        d('llm', 8, 7, 30, function () { return api('/api/llm'); }, renderLlm),
        d('transports', 8, 5, 10, function () { return api('/api/transports'); }, renderTransports),
        d('stats', 8, 8, 10, function () { return api('/api/stats'); }, renderStats),
        d('generation', 8, 5, 3, function () { return api('/api/generation'); }, renderGeneration),
        d('load', 8, 8, 5, function () { return api('/api/metrics'); }, renderLoad),
        d('log', 16, 12, 3, function () { return api('/api/log?n=' + S.settings.log_lines); }, renderLog),
        d('plugins', 12, 10, 5, function () { return Promise.resolve(S.modules); }, renderPlugins),
        d('tools', 12, 10, 30, function () { return api('/api/tools'); }, renderTools)
      ];
    }
    function title(def) { return def.rawTitle ? def.title : t(def.title); }
    function syncModules() {
      return api('/api/modules').then(function (mods) {
        S.modules = mods;
        var keep = S.defs.filter(function (d) { return d.builtin; }), extra = [];
        mods.forEach(function (m) {
          (m.widgets || []).forEach(function (w) {
            var id = 'm:' + m.name + ':' + w.id;
            var existing = S.defs.filter(function (d) { return d.id === id; })[0];
            extra.push(existing || { id: id, rawTitle: true, title: w.title, mod: m.name, wid: w.id, w: w.size.w, h: w.size.h, refresh: w.refresh,
                                     load: function () { return api('/api/widget/' + m.name + '/' + w.id); }, render: renderModuleWidget, state: {}, next: 0 });
          });
        });
        var changed = extra.map(function (d) { return d.id; }).join() !== S.defs.filter(function (d) { return !d.builtin; }).map(function (d) { return d.id; }).join();
        S.defs = keep.concat(extra);
        if (changed) rebuildAll();
      });
    }

    /* Архитектура: узлы строит сервер из живого реестра; здесь они становятся виджетами, а связи нитями. */
    function syncArchitecture() {
      return api('/api/architecture').then(function (g) {
        S.arch = g;
        S.archById = {};
        g.nodes.forEach(function (n) { S.archById[n.id] = n; });
        var existing = {};
        S.archDefs.forEach(function (d) { existing[d.id] = d; });
        var defs = g.nodes.map(function (n) {
          var d = existing['a:' + n.id] || { id: 'a:' + n.id, rawTitle: true, w: n.pos.w, h: n.pos.h, x: n.pos.x, y: n.pos.y, refresh: 5, state: {}, next: 0, arch: true,
            load: function () { return Promise.resolve(S.archById[n.id]); }, render: renderArchNode };
          d.title = n.title;
          return d;
        });
        var changed = defs.map(function (d) { return d.id; }).join() !== S.archDefs.map(function (d) { return d.id; }).join();
        S.archDefs = defs;
        if (S.settings.view === 'arch') {
          if (changed) rebuildAll(); else { computeThreads(); if (!S.animating) drawThreads(); }
          return Promise.all(visibleDefs().map(function (d) { return refreshDef(d); }));
        }
      });
    }
    function setView(v) {
      if (S.settings.view === v) return Promise.resolve();
      S.settings.view = v;
      return saveSettings({ view: v }).then(function () {
        buildTopbar();
        return (v === 'arch' ? syncArchitecture().catch(function () {}) : Promise.resolve()).then(function () { rebuildAll(); return refreshAll(); });
      });
    }

    // ---------- виджеты: узлы и раскладка ----------
    function currentDefs() { return S.settings.view === 'arch' ? S.archDefs : S.defs; }
    function visibleDefs() { return currentDefs().filter(function (d) { return S.settings.hidden.indexOf(d.id) < 0; }); }
    function renderInto(def, data) {
      var node = S.nodes[def.id];
      if (!node) return;
      clear(node.body);
      node.body.className = 'wb';
      try { def.render(node.body, data, { def: def }); } catch (e) { node.body.className = 'wb err'; text(node.body, String(e && e.message || e)); }
    }
    function refreshDef(def) {
      if (def.busy || !S.nodes[def.id]) return Promise.resolve();
      def.busy = true;
      return def.load().then(function (data) { renderInto(def, data); }).catch(function (e) {
        var node = S.nodes[def.id];
        if (node && e.message !== '401') { clear(node.body); node.body.className = 'wb err'; text(node.body, t('error') + ': ' + e.message); }
      }).then(function () { def.busy = false; });
    }
    function refreshAll() {
      return syncModules().catch(function () {}).then(function () {
        return S.settings.view === 'arch' ? syncArchitecture().catch(function () {}) : Promise.all(visibleDefs().map(function (d) { return refreshDef(d); }));
      }).then(function () { setStatus(t('updated') + ' ' + fmtTime(Date.now() / 1000), false); });
    }
    function createNode(def) {
      var body = h(doc, 'div', { class: 'wb' });
      var close = h(doc, 'button', { class: 'wx', title: t('hide'), text: '✕', on: { click: function () {
        S.settings.hidden = S.settings.hidden.concat([def.id]);
        saveSettings({ hidden: S.settings.hidden }).then(function () { rebuildAll(); }); } } });
      var head = h(doc, 'header', { class: 'wh' }, [h(doc, 'span', { class: 'wt', text: title(def) }), close]);
      var handle = h(doc, 'div', { class: 'rh' });
      var el = h(doc, 'section', { class: 'widget', id: 'w-' + def.id }, [head, body, handle]);
      head.addEventListener('pointerdown', function (ev) { if (ev.target !== close) startDrag(ev, def.id, 'move'); });
      handle.addEventListener('pointerdown', function (ev) { startDrag(ev, def.id, 'resize'); });
      board.appendChild(el);
      S.nodes[def.id] = { el: el, body: body, head: head };
    }
    function rebuildAll() {
      var vis = visibleDefs(), ids = vis.map(function (d) { return d.id; });
      Object.keys(S.nodes).forEach(function (id) {
        if (ids.indexOf(id) < 0) { board.removeChild(S.nodes[id].el); delete S.nodes[id]; }
      });
      vis.forEach(function (d) {
        if (!S.nodes[d.id]) createNode(d);
        else S.nodes[d.id].head.firstChild.textContent = title(d);
      });
      relayout();
      vis.forEach(function (d) { d.next = 0; });
    }
    function gapOf() { return typeof S.settings.gap === 'number' ? S.settings.gap : DEFAULT_GAP; }
    function clock() { return env.now ? env.now() : Date.now(); }
    var threadCanvas = h(doc, 'canvas', { class: 'threads', id: 'threads' });
    board.appendChild(threadCanvas);   // первый ребёнок доски: лежит под виджетами

    function computeThreads() {
      S.threads = [];
      if (S.stacked) return;
      var pairs = S.settings.view === 'arch' && S.arch ? S.arch.edges.map(function (e) { return { a: 'a:' + e.a, b: 'a:' + e.b, kind: e.kind, label: e.label, off: !!e.off }; })
                                                       : L.threadPairs(Object.keys(S.nodes));
      pairs.forEach(function (pr) {
        if (!S.nodes[pr.a] || !S.nodes[pr.b] || !S.layout[pr.a] || !S.layout[pr.b]) return;
        S.threads.push({ a: pr.a, b: pr.b, kind: pr.kind, label: pr.label || '', off: !!pr.off,
          p: L.threadCurve(L.rectToPx(S.layout[pr.a], S.cellW, ROW_H, gapOf()), L.rectToPx(S.layout[pr.b], S.cellW, ROW_H, gapOf())) });
      });
    }
    function bez(ctx, p) { ctx.beginPath(); ctx.moveTo(p[0][0], p[0][1]); ctx.bezierCurveTo(p[1][0], p[1][1], p[2][0], p[2][1], p[3][0], p[3][1]); }
    function dotAt(ctx, pt, r, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(pt[0], pt[1], r, 0, Math.PI * 2); ctx.fill(); }
    /* Нити светятся, по ним бегут импульсы; нити перетаскиваемого виджета ярче; от клика по виджету бежит яркая волна. */
    function drawThreads() {
      var ctx = threadCanvas.getContext('2d'), now = clock();
      ctx.clearRect(0, 0, threadCanvas.width, threadCanvas.height);
      if (S.stacked) return;
      var col = THREAD_COLORS[S.settings.theme] || THREAD_COLORS.dark;
      ctx.lineCap = 'round';
      S.threads.forEach(function (th, i) {
        var hot = S.dragId && (th.a === S.dragId || th.b === S.dragId), rgb = KIND_RGB[th.kind];
        ctx.globalAlpha = th.off ? 0.22 : 1;   // связь выключенного модуля тусклая и без импульсов
        bez(ctx, th.p); ctx.strokeStyle = hot ? col.hotGlow : (rgb ? 'rgba(' + rgb + ',0.12)' : col.glow); ctx.lineWidth = hot ? 9 : 6; ctx.stroke();
        bez(ctx, th.p); ctx.strokeStyle = hot ? col.hot : (rgb ? 'rgba(' + rgb + ',0.62)' : (th.kind === 'module' ? col.module : col.line)); ctx.lineWidth = hot ? 2.2 : 1.4; ctx.stroke();
        ctx.globalAlpha = S.settings.view === 'arch' ? 0.4 : 1;   // в архитектуре фоновые импульсы тихие: яркие только по настоящим событиям
        if (!th.off) for (var k = 0; k < 2; k++) dotAt(ctx, L.bezierPoint(th.p, ((now / 1000) * 0.16 + i * 0.31 + k * 0.5) % 1), hot ? 3.6 : 2.6, col.pulse);
        ctx.globalAlpha = th.off ? 0.22 : 1;
        if (th.label && th.kind !== 'manage') {   // подписи у «управляет» только засоряли бы схему
          var mid = L.bezierPoint(th.p, 0.5), m = ctx.measureText ? ctx.measureText(th.label) : null, lw = (m && m.width) || th.label.length * 6;
          ctx.font = '10px monospace'; ctx.fillStyle = col.labelBg; ctx.fillRect(mid[0] - lw / 2 - 3, mid[1] - 8, lw + 6, 14);
          ctx.fillStyle = col.label; ctx.fillText(th.label, mid[0] - lw / 2, mid[1] + 3);
        }
        ctx.globalAlpha = 1;
        if (S.shock && (th.a === S.shock.id || th.b === S.shock.id)) {
          var age = (now - S.shock.t0) / 900;
          if (age < 1) { var tt = th.a === S.shock.id ? age : 1 - age, pt = L.bezierPoint(th.p, tt); dotAt(ctx, pt, 9, col.glow); dotAt(ctx, pt, 4.5, col.pulse); }
        }
      });
      if (S.shock && now - S.shock.t0 >= 900) S.shock = null;
      // настоящие события: яркая «комета» бежит по нити в направлении события (красная для ошибок)
      S.bursts = S.bursts.filter(function (bu) { return now - bu.t0 < 1000; });
      S.bursts.forEach(function (bu) {
        var th = S.threads.filter(function (x) { return x.a === bu.a && x.b === bu.b; })[0];
        if (!th) return;
        var age = (now - bu.t0) / 1000, color = bu.level === 'error' ? col.err : col.pulse;
        for (var k = 3; k >= 0; k--) {
          var tt = age - k * 0.05;
          if (tt < 0) continue;
          var pt = L.bezierPoint(th.p, bu.forward ? tt : 1 - tt);
          if (k === 0) dotAt(ctx, pt, 11, bu.level === 'error' ? 'rgba(255,107,107,0.22)' : col.glow);
          dotAt(ctx, pt, k === 0 ? 4.6 : 3.6 - k * 0.7, color);
        }
      });
    }
    function flashNode(id) {
      var n = S.nodes[id];
      if (!n) return;
      n.el.classList.add('flash');
      if (env.setTimeout) env.setTimeout(function () { n.el.classList.remove('flash'); }, 700);
    }
    /* Событие активности -> импульс по нити между его узлами (если такой нити сейчас нет, например узел скрыт, событие пропускается). */
    function addBurst(ev) {
      var a = 'a:' + ev.a, b = 'a:' + ev.b;
      var th = S.threads.filter(function (x) { return (x.a === a && x.b === b) || (x.a === b && x.b === a); })[0];
      if (!th) return false;
      S.bursts.push({ a: th.a, b: th.b, forward: th.a === a, t0: clock(), level: ev.level });
      if (S.bursts.length > 40) S.bursts.shift();
      flashNode(a); flashNode(b);
      return true;
    }
    function pollActivity() {
      return api('/api/activity' + (S.activitySince ? '?since=' + S.activitySince : '')).then(function (r) {
        S.activitySince = r.now;
        r.events.forEach(addBurst);
        if (!S.animating) drawThreads();
        return r.events.length;
      });
    }
    function animate() {
      if (!doc.hidden && !S.stacked && clock() - S.lastDraw >= 33) { S.lastDraw = clock(); drawThreads(); }
      env.requestAnimationFrame(animate);
    }
    function startAnimation() {
      if (S.animating) return;
      if (env.requestAnimationFrame && !S.reduced) { S.animating = true; env.requestAnimationFrame(animate); }
    }
    /* Эффект клика: расходящееся кольцо у курсора и волна по нитям от виджета, по которому нажали. */
    function nearestWidgetId(el) {
      while (el) { if (el.id && String(el.id).indexOf('w-') === 0) return String(el.id).slice(2); el = el.parentNode || el.parent; }
      return null;
    }
    doc.addEventListener('pointerdown', function (ev) {
      var fx = h(doc, 'div', { class: 'clickfx', style: { left: ev.clientX + 'px', top: ev.clientY + 'px' } });
      doc.body.appendChild(fx);
      if (env.setTimeout) env.setTimeout(function () { var par = fx.parentNode || fx.parent; if (par) par.removeChild(fx); }, 700);
      var wid = nearestWidgetId(ev.target);
      if (wid) S.shock = { id: wid, t0: clock() };
      if (!S.animating) drawThreads();
    });

    function relayout() {
      S.layout = L.mergeLayout(S.settings.layout, visibleDefs().map(function (d) { return { id: d.id, w: d.w, h: d.h, x: d.x, y: d.y }; }), L.COLS);
      applyLayout();
    }
    function applyLayout() {
      var rect = board.getBoundingClientRect(), width = rect.width || 1200;
      S.stacked = width < 720;
      board.className = S.stacked ? 'stack' : '';
      S.cellW = width / L.COLS;
      if (board.style.setProperty) { board.style.setProperty('--cell', S.cellW + 'px'); board.style.setProperty('--row', ROW_H + 'px'); }
      var ids = Object.keys(S.nodes);
      if (S.stacked) {
        ids.sort(function (a, b) { return (S.layout[a].y - S.layout[b].y) || (S.layout[a].x - S.layout[b].x); });
        ids.forEach(function (id) { var st = S.nodes[id].el.style; st.left = ''; st.top = ''; st.width = ''; st.height = ''; board.appendChild(S.nodes[id].el); });
        board.style.height = '';
        computeThreads();
        if (!S.animating) drawThreads();
        return;
      }
      ids.forEach(function (id) {
        var px = L.rectToPx(S.layout[id], S.cellW, ROW_H, gapOf()), st = S.nodes[id].el.style;
        st.left = px.left + 'px'; st.top = px.top + 'px'; st.width = px.width + 'px'; st.height = px.height + 'px';
      });
      var boardH = Math.max(L.boardRows(S.layout) + 2, 20) * ROW_H;
      board.style.height = boardH + 'px';
      if (threadCanvas.width !== Math.round(width)) threadCanvas.width = Math.round(width);
      if (threadCanvas.height !== boardH) threadCanvas.height = boardH;
      computeThreads();
      if (!S.animating) drawThreads();
    }
    function startDrag(ev, id, mode) {
      if (S.stacked) return;
      if (ev.preventDefault) ev.preventDefault();
      var start = { x: ev.clientX, y: ev.clientY, rect: L.copy(S.layout)[id] }, el = S.nodes[id].el;
      el.classList.add('dragging');
      S.dragId = id;
      function move(e) {
        var d = L.pxToCells(e.clientX - start.x, e.clientY - start.y, S.cellW, ROW_H);
        S.layout[id] = L.clampRect(mode === 'move'
          ? { x: start.rect.x + d.dx, y: start.rect.y + d.dy, w: start.rect.w, h: start.rect.h }
          : { x: start.rect.x, y: start.rect.y, w: start.rect.w + d.dx, h: start.rect.h + d.dy }, L.COLS);
        applyLayout();
      }
      function up() {
        doc.removeEventListener('pointermove', move);
        doc.removeEventListener('pointerup', up);
        el.classList.remove('dragging');
        S.dragId = null;
        S.layout = L.resolveCollisions(S.layout, id);
        S.settings.layout = Object.assign({}, S.settings.layout, L.copy(S.layout));   // раскладка другого вида сохраняется
        applyLayout();
        saveSettings({ layout: S.settings.layout });
      }
      doc.addEventListener('pointermove', move);
      doc.addEventListener('pointerup', up);
    }

    // ---------- запуск ----------
    function tick() {
      if (doc.hidden || overlay.hidden === false) return;
      var now = Date.now();
      if (S.settings.view === 'arch' && now >= S.archNext) { S.archNext = now + 5000; syncArchitecture().catch(function () {}); }
      if (S.settings.view === 'arch' && now >= S.activityNext) { S.activityNext = now + 2000; pollActivity().catch(function () {}); }
      visibleDefs().forEach(function (d) {
        if (!d.busy && now >= d.next) { d.next = now + d.refresh * 1000; refreshDef(d); }
      });
    }
    var ticking = false;
    function start() {
      if (!S.token) return showLogin();
      return api('/api/settings').then(function (s) {
        S.settings = s;
        applyTheme();
        buildTopbar();
        S.defs = builtinDefs();
        return syncModules().catch(function () {}).then(function () { return S.settings.view === 'arch' ? syncArchitecture().catch(function () {}) : null; });
      }).then(function () {
        rebuildAll();
        startAnimation();
        if (!ticking) { ticking = true; env.setInterval(tick, 1000); if (env.window && env.window.addEventListener) env.window.addEventListener('resize', applyLayout); }
        return refreshAll();
      }).catch(function (e) { if (e.message !== '401') { buildTopbar(); setStatus(t('error') + ': ' + e.message, true); } });
    }
    var started = start();
    return { S: S, started: started, refreshAll: refreshAll, tick: tick, applyLayout: applyLayout, drawThreads: drawThreads, setView: setView, syncArchitecture: syncArchitecture, pollActivity: pollActivity };
  }

  return { boot: boot, h: h, I18N: I18N };
});
