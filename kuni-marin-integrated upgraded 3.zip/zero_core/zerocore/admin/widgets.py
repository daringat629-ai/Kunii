"""Виджеты модулей. Модуль объявляет виджет в манифесте (widgets), панель запускает его команду и рисует результат.
Контракт вывода команды (JSON в stdout, код 0, до 64 КБ, таймаут):
  kv      {"items": [["ключ", "значение"], ...]}
  table   {"columns": ["a", "b"], "rows": [["1", "2"], ...]}
  text    {"text": "строка"}
  counter {"value": 229, "label": "кликов"}
Кнопки (actions) запускают только команды, объявленные в манифесте; после действия виджет перечитывается."""
import json
import subprocess

from ..kernel.errors import ZeroCoreError

MAX_OUTPUT = 65536


def _check_shape(kind, data):
    if not isinstance(data, dict):
        return "ответ должен быть объектом JSON"
    if kind == "kv":
        items = data.get("items")
        if not (isinstance(items, list) and all(isinstance(i, list) and len(i) == 2 for i in items)):
            return 'ожидается {"items": [["ключ", "значение"], ...]}'
    elif kind == "table":
        cols, rows = data.get("columns"), data.get("rows")
        if not (isinstance(cols, list) and isinstance(rows, list) and all(isinstance(r, list) and len(r) == len(cols) for r in rows)):
            return 'ожидается {"columns": [...], "rows": [[...], ...]} с равной длиной строк'
    elif kind == "text":
        if not isinstance(data.get("text"), str):
            return 'ожидается {"text": "..."}'
    elif kind == "counter":
        if not isinstance(data.get("value"), (int, float)) or isinstance(data.get("value"), bool):
            return 'ожидается {"value": число, "label": "..."}'
    return None


def find_widget(manager, module, widget_id):
    if module not in manager.enabled_names():
        raise ZeroCoreError(f"модуль {module} не включён")
    m = manager.manifest(module)
    for w in m.widgets:
        if w["id"] == widget_id:
            return m, w
    raise ZeroCoreError(f"у модуля {module} нет виджета {widget_id}")


def _run(manager, module, command, timeout):
    mdir = manager.module_dir(module)
    m = manager.manifest(module)
    argv = manager._expand(command, module, mdir)
    r = subprocess.run(argv, cwd=str(mdir), env=manager._env(module, m, mdir), capture_output=True, timeout=timeout)
    if len(r.stdout) > MAX_OUTPUT:
        raise ZeroCoreError(f"вывод больше {MAX_OUTPUT} байт")
    if r.returncode != 0:
        tail = (r.stderr or r.stdout).decode("utf-8", "ignore").strip()[-200:]
        raise ZeroCoreError(f"команда завершилась кодом {r.returncode}: {tail}")
    return r.stdout.decode("utf-8", "replace")


def run_widget(manager, module, widget_id, action_id=None, timeout=5.0):
    """Возвращает {"ok": bool, ...}. Ошибки виджета не должны ронять панель."""
    _, w = find_widget(manager, module, widget_id)
    note = None
    try:
        if action_id is not None:
            act = next((a for a in w.get("actions", []) if a["id"] == action_id), None)
            if act is None:
                raise ZeroCoreError(f"у виджета нет действия {action_id}")
            note = _run(manager, module, act["command"], timeout).strip()[:300] or None
        raw = _run(manager, module, w["command"], timeout)
        try:
            data = json.loads(raw)
        except ValueError:
            raise ZeroCoreError("команда вернула не JSON")
        problem = _check_shape(w["kind"], data)
        if problem:
            raise ZeroCoreError(problem)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": f"таймаут {timeout:g} с"}
    except ZeroCoreError as ex:
        if str(ex).startswith("у виджета нет действия"):
            raise
        return {"ok": False, "error": str(ex)}
    except OSError as ex:
        return {"ok": False, "error": f"не удалось запустить: {ex}"}
    return {"ok": True, "kind": w["kind"], "title": w["title"], "data": data, "note": note,
            "actions": [{"id": a["id"], "label": a["label"]} for a in w.get("actions", [])]}
