"""HTTP-сервер панели «Нулевое ядро»: слушает 127.0.0.1, данные API закрыты токеном, статические файлы открыты."""
import hmac
import json
import os
import re
import secrets
import sys
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from .. import __version__
from ..kernel.errors import ZeroCoreError
from . import activity, architecture, providers, widgets
from .settings import AdminState

WEB = Path(__file__).parent / "web"
HTML = "text/html; charset=utf-8"
JS = "text/javascript; charset=utf-8"
STATIC = {"/": ("index.html", HTML), "/index.html": ("index.html", HTML), "/app.js": ("app.js", JS),
          "/layout.js": ("layout.js", JS), "/style.css": ("style.css", "text/css; charset=utf-8")}
CSP = "default-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
MAX_BODY = 100_000
TRANSPORT_RE = re.compile(r"^(telegram|transport)\.")
ACTIONS = ("enable", "disable", "start", "stop", "restart")


def get_token(home):
    env = os.environ.get("ZEROCORE_PANEL_TOKEN")
    if env:
        return env
    path = Path(home) / "panel_token"
    if not path.exists():
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(secrets.token_urlsafe(24))
        except FileExistsError:
            pass
    return path.read_text().strip()


class AdminApp:
    def __init__(self, manager, sampler=None, widget_timeout=5.0):
        self.m = manager
        self.state = AdminState(manager.home)
        self.sampler = sampler or providers.MetricsSampler()
        self.widget_timeout = widget_timeout
        self.started = time.time()

    # --- пути kuni берутся из конфигурации модуля kuni ---
    def kuni_paths(self):
        try:
            cfg = self.m.config("kuni")
        except ZeroCoreError:
            cfg = {}
        base = os.environ.get("ZEROCORE_KUNI_DIR") or cfg.get("kuni_dir") or ""
        logs = os.path.join(base, "logs") if base else ""
        toml = os.path.join(base, "config.toml") if base else ""
        console = providers.newest(cfg.get("console_log_glob") or "/tmp/aui.*.log")
        return logs, toml, console

    def modules_payload(self):
        rows = self.m.status()
        enabled = set(self.m.enabled_names())
        for r in rows:
            r["widgets"] = []
            if r["name"] in enabled:
                try:
                    for w in self.m.manifest(r["name"]).widgets:
                        r["widgets"].append({"id": w["id"], "title": w["title"], "kind": w["kind"],
                                             "refresh": w.get("refresh_seconds", 10),
                                             "size": w.get("size", {"w": 6, "h": 6})})
                except ZeroCoreError:
                    pass
        return rows

    def module_action(self, name, action, body):
        if name not in self.m.installed():
            return 404, {"error": f"модуль {name} не установлен"}
        if action not in ACTIONS:
            return 404, {"error": "неизвестное действие"}
        try:
            if action == "enable":
                result = self.m.enable(name)
            elif action == "disable":
                result = self.m.disable(name, cascade=bool((body or {}).get("cascade")))
            elif action == "start":
                result = self.m.start(name)
            elif action == "stop":
                result = self.m.stop(name)
            else:
                result = self.m.restart(name)
        except ZeroCoreError as ex:
            return 400, {"error": str(ex)}
        return 200, {"ok": True, "result": result}

    def handle(self, method, path, query=None, body=None):
        """Возвращает (код, объект). Без HTTP, поэтому легко тестируется."""
        query = query or {}
        r = [p for p in path.split("/") if p]
        if r[:1] != ["api"]:
            return 404, {"error": "not found"}
        r = r[1:]
        logs, toml, console = self.kuni_paths()
        if method == "GET":
            if r == ["system"]:
                return 200, providers.system_info(self.m, __version__, self.started)
            if r == ["modules"]:
                return 200, self.modules_payload()
            if r == ["transports"]:
                return 200, [{"name": x["name"], "capability": c, "running": x["running"], "health": x["health"]}
                             for x in self.m.status() if x["enabled"] for c in x["provides"] if TRANSPORT_RE.match(c)]
            if r == ["llm"]:
                return 200, providers.parse_llm(toml) if toml else {"available": False, "error": "kuni_dir не задан"}
            if r == ["stats"]:
                return 200, providers.stats(logs, console)
            if r == ["metrics"]:
                return 200, self.sampler.points()
            if r == ["tools"]:
                return 200, providers.tools_from_query(logs) if logs else []
            if r == ["generation"]:
                return 200, providers.generation_state(logs) if logs else {"known": False}
            if r == ["log"]:
                try:
                    n = int((query.get("n") or [self.state.get()["log_lines"]])[0])
                except ValueError:
                    n = 200
                return 200, providers.live_log(self.m.bus.recent(min(max(n, 10), 2000)), console, min(max(n, 10), 2000))
            if r == ["activity"]:
                now = time.time()
                try:
                    since = float((query.get("since") or [now - 3])[0])
                except ValueError:
                    since = now - 3
                return 200, activity.collect(self.m, logs, console, min(max(since, now - 300), now), now)
            if r == ["architecture"]:
                return 200, architecture.build(self.m, toml or None)
            if r == ["settings"]:
                return 200, self.state.get()
            if len(r) == 3 and r[0] == "widget":
                try:
                    return 200, widgets.run_widget(self.m, r[1], r[2], timeout=self.widget_timeout)
                except ZeroCoreError as ex:
                    return 404, {"error": str(ex)}
        if method == "POST":
            if r == ["settings"]:
                try:
                    return 200, self.state.update(body)
                except ValueError as ex:
                    return 400, {"error": str(ex)}
            if len(r) == 3 and r[0] == "modules":
                return self.module_action(r[1], r[2], body)
            if len(r) == 5 and r[0] == "widget" and r[3] == "action":
                try:
                    return 200, widgets.run_widget(self.m, r[1], r[2], r[4], timeout=self.widget_timeout)
                except ZeroCoreError as ex:
                    return 404, {"error": str(ex)}
        return 404, {"error": "not found"}


class Handler(BaseHTTPRequestHandler):
    server_version = "ZeroCorePanel"

    def log_message(self, *a):
        pass

    def _send(self, code, data, ctype="application/json; charset=utf-8"):
        b = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", CSP)
        self.end_headers()
        self.wfile.write(b)

    def _authed(self):
        return hmac.compare_digest(self.headers.get("X-Token", ""), self.server.token)

    def _api(self, method, body=None):
        u = urllib.parse.urlparse(self.path)
        if not self._authed():
            return self._send(401, {"error": "нужен токен"})
        try:
            code, payload = self.server.app.handle(method, u.path, urllib.parse.parse_qs(u.query), body)
        except Exception as ex:  # ошибка обработчика не должна ронять панель
            print(f"panel: ошибка {type(ex).__name__}: {ex}", file=sys.stderr)
            return self._send(500, {"error": "внутренняя ошибка панели"})
        self._send(code, payload)

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in STATIC:
            name, ctype = STATIC[path]
            try:
                return self._send(200, (WEB / name).read_bytes(), ctype)
            except OSError:
                return self._send(404, {"error": "not found"})
        if path.startswith("/api/"):
            return self._api("GET")
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self.path.startswith("/api/"):
            return self._send(404, {"error": "not found"})
        if not self._authed():
            return self._send(401, {"error": "нужен токен"})
        try:
            ln = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            return self._send(400, {"error": "Content-Length"})
        if ln > MAX_BODY:
            return self._send(413, {"error": "слишком большой запрос"})
        try:
            body = json.loads(self.rfile.read(ln) or b"{}")
        except ValueError:
            return self._send(400, {"error": "тело запроса не JSON"})
        self._api("POST", body)


def make_server(manager, host="127.0.0.1", port=8767, token=None, app=None):
    srv = ThreadingHTTPServer((host, port), Handler)
    srv.daemon_threads = True
    srv.app = app or AdminApp(manager)
    srv.token = token or get_token(manager.home)
    return srv


def serve(manager, host="127.0.0.1", port=8767):
    srv = make_server(manager, host, port)
    srv.app.sampler.start()
    print(f"Панель «Нулевое ядро»: http://{host}:{srv.server_address[1]}/")
    print(f"Токен: {srv.token}  (файл {Path(manager.home) / 'panel_token'})")
    if host not in ("127.0.0.1", "localhost"):
        print("ВНИМАНИЕ: панель слушает не только localhost; токен — единственная защита.", file=sys.stderr)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.app.sampler.stop()
