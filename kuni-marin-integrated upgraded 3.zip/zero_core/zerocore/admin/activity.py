"""Живая активность для схемы архитектуры: что происходило недавно и по какой связи это «прошло».
Источники: события менеджера, консольный лог бота (сообщения, shell, внешние инструменты, отказы охранника, ошибки LLM) и файлы
журнала запросов к LLM. Каждое событие привязано к паре узлов схемы, между которыми есть нить; панель пускает по ней яркий импульс."""
import os
import re

from . import providers

LIMIT = 60


def _ev(t, a, b, kind, text, level="info"):
    return {"t": round(t, 3), "a": a, "b": b, "kind": kind, "level": level, "text": text[:80]}


def from_bus(events, since):
    out = []
    for e in events:
        if e["ts"] <= since:
            continue
        topic, p, t = e["topic"], e.get("payload") or {}, e["ts"]
        mod = p.get("module")
        bad = topic.endswith(("failed", "broken", "suppressed"))
        level = "error" if bad else "info"
        if mod:
            out.append(_ev(t, "manager", "mod_" + mod, "manager", f"{topic} {mod}", level))
        if topic in ("module.installed", "module.swapped", "module.uninstalled", "swap.failed"):
            out.append(_ev(t, "manager", "installer", "manager", topic, level))
        elif topic.startswith("tools."):
            out.append(_ev(t, "manager", "catalog", "tools", topic, level))
        elif topic == "integrity.broken":
            out.append(_ev(t, "manager", "solver", "manager", topic, "error"))
        elif topic in ("module.started", "module.stopped", "module.restarted", "health.changed"):
            out.append(_ev(t, "manager", "lifecycle", "manager", topic, level))
        elif topic == "config.changed":
            out.append(_ev(t, "manager", "state", "manager", topic, level))
    return out


def from_console(lines_with_time, since):
    out = []
    for t, line in lines_with_time:
        if t is None or t <= since:
            continue
        if "[send_telegram_message][INFO]: Synthetic typing delay" in line:
            out.append(_ev(t, "k_telegram", "telegram", "message", "сообщение отправлено"))
        elif "Processing notification" in line:
            out.append(_ev(t, "telegram", "k_telegram", "message", "входящее сообщение"))
            out.append(_ev(t, "k_telegram", "k_cognition", "message", "событие в цикл ходов"))
        elif "[tools::shell][WARN]: EXEC:" in line:
            cmd = line.split("EXEC:", 1)[1].strip()
            out.append(_ev(t, "k_cognition", "k_tools", "tool", "shell: " + cmd))
        elif "[tools::external][INFO]: CALL" in line:
            name = line.split("CALL", 1)[1].strip()
            out.append(_ev(t, "k_cognition", "k_tools", "tool", "инструмент " + name))
            out.append(_ev(t, "k_tools", "catalog", "tools", "инструмент " + name))
        elif "[tools::external][INFO]: Loaded" in line:
            out.append(_ev(t, "catalog", "k_tools", "tools", "каталог перечитан"))
        elif "tool call refused" in line:
            out.append(_ev(t, "k_cognition", "k_tools", "guard", "отказ охранника", "error"))
        elif "chatStreaming: status=HTTP_" in line:
            out.append(_ev(t, "k_cognition", "llm", "llm", "ошибка LLM", "error"))
    return out


def from_logs(logs_dir, since):
    out = []
    try:
        names = sorted((e for e in os.scandir(logs_dir) if e.name.endswith(("query.json", "response.json"))), key=lambda e: e.name, reverse=True)[:60]
    except OSError:
        return out
    for e in names:
        t = e.stat().st_mtime
        if t > since:
            out.append(_ev(t, "k_cognition", "llm", "llm", "запрос к LLM" if e.name.endswith("query.json") else "ответ LLM"))
    return out


def collect(manager, logs_dir, console_path, since, now):
    events = from_bus(manager.bus.recent(100), since)
    if console_path:
        lines = providers.console_lines(console_path, 300)
        events += from_console([(providers.parse_console_ts(l, now), l) for l in lines], since)
    if logs_dir:
        events += from_logs(logs_dir, since)
    seen, unique = set(), []
    for e in sorted(events, key=lambda e: e["t"]):
        key = (e["t"], e["a"], e["b"], e["text"])
        if key not in seen:
            seen.add(key)
            unique.append(e)
    return {"now": round(now, 3), "events": unique[-LIMIT:]}
