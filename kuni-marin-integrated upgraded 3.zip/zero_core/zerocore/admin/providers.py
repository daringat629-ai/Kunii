"""Источники данных встроенных виджетов панели. Только чтение. Ключи и секреты не читаются и не отдаются."""
import json
import os
import platform
import re
import threading
import time
import tomllib
import urllib.parse
from collections import deque
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
TS = re.compile(r"^\[(\d\d):(\d\d):(\d\d)\]")


def newest(pattern):
    import glob
    files = glob.glob(pattern)
    return max(files, key=os.path.getmtime) if files else None


def tail_text(path, max_bytes=400_000):
    try:
        with open(path, "rb") as f:
            f.seek(0, 2)
            f.seek(max(0, f.tell() - max_bytes))
            return f.read().decode("utf-8", "ignore")
    except OSError:
        return ""


def console_lines(path, n=400, max_bytes=400_000):
    """Строки консольного лога kuni без шума (замеры производительности, хвосты стека)."""
    out = []
    for line in ANSI.sub("", tail_text(path, max_bytes)).splitlines():
        if not line.strip() or line.startswith(" - ") or "[Performance]" in line:
            continue
        out.append(line)
    return out[-n:]


# ---------- хост ----------
def read_meminfo():
    info = {}
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                k, _, v = line.partition(":")
                info[k] = int(v.split()[0])
    except (OSError, ValueError, IndexError):
        pass
    return info


def host_metrics():
    mem = read_meminfo()
    total, avail = mem.get("MemTotal"), mem.get("MemAvailable")
    pct = round(100 * (1 - avail / total), 1) if total and avail is not None else None
    try:
        load1 = round(os.getloadavg()[0], 2)
    except OSError:
        load1 = None
    return {"load1": load1, "mem_pct": pct, "cpus": os.cpu_count()}


def process_rss_mb(comm):
    try:
        entries = os.listdir("/proc")
    except OSError:
        return None
    for d in entries:
        if not d.isdigit():
            continue
        try:
            with open(f"/proc/{d}/comm") as f:
                if f.read().strip() != comm[:15]:
                    continue
            with open(f"/proc/{d}/status") as f:
                for line in f:
                    if line.startswith("VmRSS:"):
                        return round(int(line.split()[1]) / 1024, 1)
        except (OSError, ValueError, IndexError):
            continue
    return None


class MetricsSampler:
    """Кольцевой буфер замеров нагрузки: chat-бот не хранит историю, панель строит график по этому буферу."""

    def __init__(self, interval=5.0, size=120, process="kuni"):
        self.interval, self.process = interval, process
        self._points = deque(maxlen=size)
        self._stop = threading.Event()
        self._thread = None

    def sample_once(self, now=None):
        m = host_metrics()
        self._points.append({"t": now or time.time(), "load1": m["load1"], "mem": m["mem_pct"],
                             "rss": process_rss_mb(self.process)})

    def points(self):
        return list(self._points)

    def start(self):
        if self._thread:
            return

        def loop():
            while not self._stop.is_set():
                try:
                    self.sample_once()
                except Exception:
                    pass
                self._stop.wait(self.interval)
        self._thread = threading.Thread(target=loop, daemon=True, name="zerocore-metrics")
        self._thread.start()

    def stop(self):
        self._stop.set()


# ---------- LLM ----------
def _host_only(url):
    try:
        p = urllib.parse.urlparse(str(url))
        return f"{p.scheme}://{p.hostname}" + (f":{p.port}" if p.port else "") if p.hostname else ""
    except ValueError:
        return ""


def _provider(host):
    h = host.lower()
    if "openrouter" in h:
        return "openrouter"
    if ":11434" in h or "ollama" in h:
        return "ollama"
    if "openai.com" in h:
        return "openai"
    return urllib.parse.urlparse(host).hostname or "?"


def parse_llm(config_path):
    """Только модель и хост конечной точки. bearerKey и остальные поля не читаются в ответ."""
    try:
        data = tomllib.loads(Path(config_path).read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return {"available": False, "error": "config.toml не найден или не читается"}
    g = data.get("general", {}) if isinstance(data.get("general"), dict) else {}

    def part(name):
        sect = g.get(name, {}) if isinstance(g.get(name), dict) else {}
        ep = sect.get("endpoint", {}) if isinstance(sect.get("endpoint"), dict) else {}
        host = _host_only(ep.get("baseUrl", ""))
        return str(sect.get("model", ""))[:200], host
    model, host = part("llm")
    emodel, ehost = part("embedding")
    return {"available": True, "provider": _provider(host), "model": model, "host": host,
            "embedding_model": emodel, "embedding_host": ehost, "lockdown": str(g.get("lockdown", ""))}


# ---------- логи kuni ----------
def _query_names(logs_dir):
    try:
        return sorted((e.name for e in os.scandir(logs_dir) if e.name.endswith("query.json")), reverse=True)
    except OSError:
        return []


def tools_from_query(logs_dir, limit=120):
    """Список инструментов, который видит LLM: поле tools в самом свежем запросе."""
    for name in _query_names(logs_dir)[:8]:
        try:
            path = os.path.join(logs_dir, name)
            if os.path.getsize(path) > 8_000_000:
                continue
            with open(path, encoding="utf-8") as f:
                tools = json.load(f).get("tools")
        except (OSError, ValueError, AttributeError):
            continue
        if isinstance(tools, list) and tools:
            out = []
            for t in tools[:limit]:
                fn = t.get("function", {}) if isinstance(t, dict) else {}
                if fn.get("name"):
                    out.append({"name": str(fn["name"])[:80], "description": str(fn.get("description", ""))[:240]})
            return sorted(out, key=lambda x: x["name"])
    return []


def generation_state(logs_dir, now=None):
    """По файлам журнала запросов: свежий query без response означает, что идёт генерация."""
    now = now or time.time()
    try:
        entries = sorted((e for e in os.scandir(logs_dir) if e.name.endswith(("query.json", "response.json"))),
                         key=lambda e: e.name)
    except OSError:
        return {"known": False}
    if not entries:
        return {"known": True, "active": False, "last_seconds": None}
    last = entries[-1]
    st = last.stat()
    if last.name.endswith("query.json") and now - st.st_mtime < 300:
        return {"known": True, "active": True, "since": round(now - st.st_mtime, 1)}
    duration = None
    if last.name.endswith("response.json") and len(entries) > 1 and entries[-2].name.endswith("query.json"):
        duration = round(st.st_mtime - entries[-2].stat().st_mtime, 1)
    return {"known": True, "active": False, "last_seconds": duration, "ago": round(now - st.st_mtime)}


def stats(logs_dir, console_path, now=None):
    now = now or time.time()
    today = time.strftime("%Y-%m-%d", time.localtime(now))
    llm_today = 0
    try:
        llm_today = sum(1 for e in os.scandir(logs_dir) if e.name.startswith(today) and e.name.endswith("response.json"))
    except OSError:
        pass
    text = ANSI.sub("", tail_text(console_path, 2_000_000)) if console_path else ""
    return {
        "llm_requests_today": llm_today,
        "shell_commands": len(re.findall(r"\[tools::shell\]\[WARN\]: EXEC:", text)),
        "messages_sent": len(re.findall(r"\[send_telegram_message\]\[INFO\]: Synthetic typing delay", text)),
        "external_calls": len(re.findall(r"\[tools::external\]\[INFO\]: CALL", text)),
        "guard_refusals": text.count("tool call refused"),
        "llm_http_errors": len(re.findall(r"chatStreaming: status=HTTP_", text)),
        "errors": len(re.findall(r"\]\[(?:ERROR|ERR)\]", text)),
        "session_log": os.path.basename(console_path) if console_path else None,
    }


def parse_console_ts(line, now):
    m = TS.match(line)
    if not m:
        return None
    lt = time.localtime(now)
    t = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, int(m.group(1)), int(m.group(2)), int(m.group(3)), 0, 0, -1))
    return t - 86400 if t - now > 60 else t


def live_log(events, console_path, n=200, now=None):
    now = now or time.time()
    rows = [{"t": e["ts"], "src": "core", "text": f"{e['topic']} {json.dumps(e['payload'], ensure_ascii=False)}"}
            for e in events]
    if console_path:
        for line in console_lines(console_path, n):
            rows.append({"t": parse_console_ts(line, now), "src": "kuni", "text": line})
    rows.sort(key=lambda r: (r["t"] is not None, r["t"] or 0))
    return rows[-n:]


def system_info(manager, version, started):
    problems = manager.check_integrity()
    return {"zerocore": version, "python": platform.python_version(), "os": f"{platform.system()} ({platform.machine()})",
            "pid": os.getpid(), "home": str(manager.home), "uptime": round(time.time() - started),
            "modules": len(manager.installed()), "enabled": len(manager.enabled_names()), "integrity": problems,
            "host": host_metrics()}
