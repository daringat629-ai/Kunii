"""Настройки панели и раскладка виджетов (на сервере, поэтому одинаковы на телефоне и компьютере)."""
import copy
import re

from ..kernel.txn import StateStore

DEFAULTS = {"language": "ru", "theme": "dark", "log_lines": 200, "gap": 14, "view": "panel", "layout": {}, "hidden": []}
ID_RE = re.compile(r"^[A-Za-z0-9_:.\-]{1,80}$")


def _int(v, lo, hi, name):
    if isinstance(v, bool) or not isinstance(v, int):
        raise ValueError(f"{name}: нужно целое число")
    return max(lo, min(hi, v))


def sanitize_layout(raw):
    if not isinstance(raw, dict):
        raise ValueError("layout: объект {id: {x, y, w, h}}")
    out = {}
    for wid, r in raw.items():
        if not (isinstance(wid, str) and ID_RE.match(wid)) or not isinstance(r, dict) or len(out) >= 100:
            continue
        try:
            out[wid] = {"x": _int(r["x"], 0, 23, "x"), "y": _int(r["y"], 0, 400, "y"),
                        "w": _int(r["w"], 2, 24, "w"), "h": _int(r["h"], 2, 60, "h")}
        except (KeyError, ValueError):
            continue
    return out


class AdminState:
    def __init__(self, home):
        self.store = StateStore(home, "admin_state.json", copy.deepcopy(DEFAULTS))

    def get(self):
        s = copy.deepcopy(DEFAULTS)
        s.update({k: v for k, v in self.store.load().items() if k in DEFAULTS})
        return s

    def update(self, patch):
        if not isinstance(patch, dict):
            raise ValueError("ожидается объект JSON")
        s = self.get()
        if "language" in patch:
            if patch["language"] not in ("ru", "en"):
                raise ValueError("language: ru или en")
            s["language"] = patch["language"]
        if "theme" in patch:
            if patch["theme"] not in ("dark", "light", "black"):
                raise ValueError("theme: dark, light или black")
            s["theme"] = patch["theme"]
        if "log_lines" in patch:
            s["log_lines"] = _int(patch["log_lines"], 20, 2000, "log_lines")
        if "view" in patch:
            if patch["view"] not in ("panel", "arch"):
                raise ValueError("view: panel или arch")
            s["view"] = patch["view"]
        if "gap" in patch:
            s["gap"] = _int(patch["gap"], 0, 60, "gap")
        if "layout" in patch:
            s["layout"] = sanitize_layout(patch["layout"])
        if "hidden" in patch:
            h = patch["hidden"]
            if not (isinstance(h, list) and all(isinstance(x, str) and ID_RE.match(x) for x in h) and len(h) <= 100):
                raise ValueError("hidden: список идентификаторов виджетов")
            s["hidden"] = h
        self.store.save(s)
        return s
