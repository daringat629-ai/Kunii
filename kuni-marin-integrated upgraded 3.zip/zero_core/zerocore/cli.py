"""CLI: python3 zerocore.py <команда>. Домашний каталог: --home или переменная ZEROCORE_HOME."""
import argparse
import json
import os
import sys
import time
from pathlib import Path

from .kernel.errors import ZeroCoreError
from .module_manager import discovery
from .module_manager.manager import Manager
from . import kiosk, setup_tools

DEFAULT_ENABLE = ("world_v2", "kuni", "watchdog")  # безопасные: только наблюдение и проверки


def _parse_value(s):
    try:
        return json.loads(s)
    except ValueError:
        return s


def build_parser():
    p = argparse.ArgumentParser(prog="zerocore", description="Нулевое ядро: управление модулями")
    p.add_argument("--home", default=os.environ.get("ZEROCORE_HOME", str(Path.home() / "zero_core_home")))
    sub = p.add_subparsers(dest="cmd")
    sub.add_parser("status")
    sub.add_parser("health")
    sub.add_parser("check")
    sub.add_parser("tick")
    sub.add_parser("bootstrap")
    sub.add_parser("recover")
    sub.add_parser("available")
    sub.add_parser("tools")
    dc = sub.add_parser("doctor")
    dc.add_argument("--kuni-dir")
    dc.add_argument("--port", type=int, default=8767)
    wk = sub.add_parser("wire-kuni")
    wk.add_argument("--kuni-dir")
    up = sub.add_parser("up")
    up.add_argument("--kuni-dir")
    up.add_argument("--host", default="auto", help="auto: адрес в локальной сети (для телефона); 127.0.0.1: только этот компьютер")
    up.add_argument("--port", type=int, default=8767)
    up.add_argument("--demo", action="store_true", help="включить демонстрационные модули demo_counter и demo_tools")
    up.add_argument("--wire-kuni", action="store_true", help="прописать каталог инструментов в config.toml бота (с резервной копией)")
    up.add_argument("--tmux", action="store_true", help="запустить панель в фоне, в tmux-сессии zerocore-panel")
    up.add_argument("--no-panel", action="store_true", help="только подготовить, панель не запускать")
    up.add_argument("--theme", choices=["dark", "light", "black"], help="тема панели (сохраняется; потом меняется в настройках)")
    ks = sub.add_parser("kiosk", help="показать панель на экране самого ноутбука (Ubuntu без графики)")
    ks.add_argument("action", choices=["setup"])
    ks.add_argument("--user", default=os.environ.get("USER") or "marinka", help="пользователь, под которым работают бот и панель")
    ks.add_argument("--browser", choices=list(kiosk.BROWSERS), default="epiphany", help="epiphany (лёгкий, без snap), chromium, firefox или existing (уже установлен)")
    ks.add_argument("--port", type=int, default=8767)
    ks.add_argument("--boot", action="store_true", help="включить показ панели при каждой загрузке")
    ks.add_argument("--out", help="куда записать скрипт (по умолчанию ~/zerocore_kiosk_setup.sh)")
    pn = sub.add_parser("panel")
    pn.add_argument("--host", default="127.0.0.1")
    pn.add_argument("--port", type=int, default=8767)
    for c in ("enable", "start", "stop", "restart", "rollback"):
        sub.add_parser(c).add_argument("name")
    d = sub.add_parser("disable")
    d.add_argument("name")
    d.add_argument("--cascade", action="store_true")
    i = sub.add_parser("install")
    i.add_argument("source")
    s = sub.add_parser("swap")
    s.add_argument("name")
    s.add_argument("version")
    u = sub.add_parser("uninstall")
    u.add_argument("name")
    u.add_argument("--purge-data", action="store_true", default=None)
    u.add_argument("--keep-data", dest="purge_data", action="store_false")
    u.add_argument("--force", action="store_true")
    c = sub.add_parser("config")
    c.add_argument("name")
    c.add_argument("action", nargs="?", choices=["get", "set"], default="get")
    c.add_argument("key", nargs="?")
    c.add_argument("value", nargs="?")
    e = sub.add_parser("events")
    e.add_argument("-n", type=int, default=20)
    return p


def _table(rows):
    print(f"{'модуль':12} {'версия':8} {'вид':9} {'вкл':4} {'запущен':8} {'здоровье':10} подробности")
    for r in rows:
        print(f"{r['name']:12} {r['version']:8} {r['kind']:9} {'да' if r['enabled'] else 'нет':4} "
              f"{'да' if r['running'] else 'нет':8} {r['health']:10} {r['detail']}")


def run(args, out=print):
    m = Manager(args.home)
    cmd = args.cmd or "status"
    if cmd == "status":
        _table(m.status())
        probs = m.check_integrity()
        if probs:
            print("ВНИМАНИЕ, нарушена целостность:", "; ".join(probs))
    elif cmd == "health":
        for r in m.status():
            if r["enabled"]:
                print(f"{r['name']}: {r['health']} {r['detail']}")
    elif cmd == "check":
        probs = m.check_integrity()
        print("Целостность в порядке." if not probs else "\n".join(probs))
        return 1 if probs else 0
    elif cmd == "tick":
        for a in m.tick() or ["ничего не требовалось"]:
            print(a)
    elif cmd == "available":
        found, errs = discovery.discover(m.repo_root / "modules")
        for n, (p, mf) in found.items():
            print(f"{n} {mf.version} ({mf.kind}): {mf.description}")
        for p, e in errs:
            print(f"ОШИБКА {p}: {e}")
    elif cmd == "bootstrap":
        found, errs = discovery.discover(m.repo_root / "modules")
        for n, (p, mf) in found.items():
            if n not in m.installed():
                m.install(p)
                print(f"установлен {n} {mf.version}")
        for n in DEFAULT_ENABLE:
            if n in m.installed() and m.enable(n):
                print(f"включён {n}")
        print("Готово. Проверьте: zerocore status")
    elif cmd == "install":
        mf = m.install(args.source)
        print(f"установлен {mf.name} {mf.version} (выключен; включить: zerocore enable {mf.name})")
    elif cmd == "enable":
        print("включён" if m.enable(args.name) else "уже включён")
    elif cmd == "disable":
        print("выключены:", ", ".join(m.disable(args.name, args.cascade)) or "нечего выключать")
    elif cmd == "start":
        print("запущены:", ", ".join(m.start(args.name)) or "уже работает")
    elif cmd == "stop":
        print("остановлены:", ", ".join(m.stop(args.name)) or "уже остановлен")
    elif cmd == "restart":
        m.restart(args.name)
        print("перезапущен")
    elif cmd == "swap":
        o, n = m.swap(args.name, args.version)
        print(f"{args.name}: {o} -> {n}")
    elif cmd == "rollback":
        o, n = m.rollback(args.name)
        print(f"{args.name}: {o} -> {n}")
    elif cmd == "uninstall":
        r = m.uninstall(args.name, args.purge_data, args.force)
        print("удалён;", "данные удалены" if r["purged_data"] else "данные сохранены")
    elif cmd == "config":
        if args.action == "set":
            if not args.key or args.value is None:
                raise ZeroCoreError("использование: config <модуль> set <ключ> <значение>")
            m.config_set(args.name, args.key, _parse_value(args.value))
        print(json.dumps(m.config(args.name), ensure_ascii=False, indent=1))
    elif cmd == "events":
        for ev in m.bus.recent(args.n):
            print(time.strftime("%m-%d %H:%M:%S", time.localtime(ev["ts"])), ev["topic"], json.dumps(ev["payload"], ensure_ascii=False))
    elif cmd == "tools":
        cat = m.export_tools()
        for t in cat["tools"]:
            print(f"{t['name']:24} {t['module']:14} {t['description'][:60]}")
        for e in cat["errors"]:
            print("ПРОБЛЕМА:", e)
        print(f"\nкаталог: {m.tools_path()}  (инструментов: {len(cat['tools'])})")
        print("Подключение к kuni: в config.toml, секция [misc]: external_tools_catalog = \"" + str(m.tools_path()) + "\"")
    elif cmd == "doctor":
        return _doctor(m, args)
    elif cmd == "wire-kuni":
        kdir = setup_tools.detect_kuni_dir(args.kuni_dir)
        if not kdir:
            raise ZeroCoreError("каталог бота не найден; укажите --kuni-dir")
        m.export_tools()
        print(f"config.toml бота: {setup_tools.wire_kuni_catalog(kdir / 'config.toml', m.tools_path())}")
        print("Бот перечитает конфиг сам; в его логе появится «Loaded N external tool(s)» (нужен kuni с этапом B).")
    elif cmd == "up":
        return _up(m, args)
    elif cmd == "kiosk":
        user_home = os.path.expanduser(f"~{args.user}")
        if user_home == f"~{args.user}":
            user_home = f"/home/{args.user}"
        script = kiosk.setup_script(args.user, user_home, m.home, Path(__file__).resolve().parent.parent / "zerocore.py", sys.executable, args.port, args.browser, args.boot)
        out_path = Path(args.out or Path.home() / "zerocore_kiosk_setup.sh")
        out_path.write_text(script, encoding="utf-8")
        print(f"Скрипт записан: {out_path}\nПосмотрите его и запустите:  sudo sh {out_path}\nПотом:  sudo systemctl start zerocore-kiosk")
    elif cmd == "panel":
        from .admin.server import serve
        serve(m, args.host, args.port)
    elif cmd == "recover":
        print("откат выполнен" if m.recovered else "прерванных операций нет")
    return 0


def _doctor(m, args):
    marks = {"ok": "✓", "warn": "!", "fail": "✗"}
    results = setup_tools.doctor(m, args.kuni_dir, args.port)
    for status, title, detail, fix in results:
        print(f"{marks[status]} {title}" + (f": {detail}" if detail else ""))
        if status != "ok" and fix:
            print(f"    что делать: {fix}")
    bad = sum(1 for r in results if r[0] == "fail")
    warn = sum(1 for r in results if r[0] == "warn")
    print(f"\nитог: ошибок {bad}, замечаний {warn}")
    return 1 if bad else 0


def _up(m, args):
    """Одна команда: модули, пути к боту, каталог инструментов, панель и адрес для телефона."""
    found, _ = discovery.discover(m.repo_root / "modules")
    for n, (p, mf) in found.items():
        if n not in m.installed():
            m.install(p)
            print(f"установлен {n} {mf.version}")
    wanted = list(DEFAULT_ENABLE) + (["demo_counter", "demo_tools"] if args.demo else [])
    for n in wanted:
        if n in m.installed() and m.enable(n):
            print(f"включён {n}")
    kdir = setup_tools.detect_kuni_dir(args.kuni_dir)
    if kdir:
        m.config_set("kuni", "kuni_dir", str(kdir))
        print(f"бот: {kdir}")
    else:
        print("ВНИМАНИЕ: каталог бота не найден, виджеты LLM/статистики будут пустыми (укажите --kuni-dir)")
    cat = m.export_tools()
    print(f"каталог инструментов: {len(cat['tools'])} шт. ({m.tools_path()})")
    if args.theme:
        from .admin.settings import AdminState
        AdminState(m.home).update({"theme": args.theme})
        print(f"тема панели: {args.theme}")
    if args.wire_kuni:
        if not kdir:
            raise ZeroCoreError("--wire-kuni требует каталог бота (--kuni-dir)")
        print(f"config.toml бота: {setup_tools.wire_kuni_catalog(kdir / 'config.toml', m.tools_path())}")
    ips = setup_tools.lan_ips()
    host = args.host if args.host != "auto" else (ips[0] if ips else "127.0.0.1")
    from .admin.server import get_token
    token = get_token(m.home)
    shown = [host] if host not in ("0.0.0.0",) else (ips or ["127.0.0.1"])
    print("\nПанель:")
    for h in shown:
        print(f"  http://{h}:{args.port}/")
    print(f"Токен (спросит один раз): {token}")
    if host != "127.0.0.1":
        print("Доступна всем в этой сети, защита одна — токен. Только для себя: --host 127.0.0.1 и SSH-туннель.")
    if args.no_panel:
        return 0
    if not setup_tools.port_free(host, args.port):
        print(f"Порт {args.port} занят: панель, видимо, уже запущена (tmux attach -t {setup_tools.TMUX_SESSION}).")
        return 0
    if args.tmux:
        import shutil
        import subprocess
        if not shutil.which("tmux"):
            raise ZeroCoreError("tmux не найден: sudo apt install tmux (или запустите без --tmux)")
        subprocess.run(["tmux", "kill-session", "-t", setup_tools.TMUX_SESSION], capture_output=True)
        subprocess.run(setup_tools.tmux_command(m.home, host, args.port), check=True)
        print(f"Панель запущена в фоне. Смотреть: tmux attach -t {setup_tools.TMUX_SESSION} (выйти: Ctrl+B, затем D). Остановить: tmux kill-session -t {setup_tools.TMUX_SESSION}")
        return 0
    from .admin.server import serve
    serve(m, host, args.port)
    return 0


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        return run(args)
    except ZeroCoreError as ex:
        print(f"Ошибка: {ex}", file=sys.stderr)
        return 1
