"""Установка модуля из каталога или zip-архива. Модуль появляется выключенным."""
import os
import shutil
import tempfile
import zipfile
from pathlib import Path

from ..kernel.errors import ZeroCoreError
from .validation import validate_source


def _unpack(source):
    src = Path(source)
    if src.is_file() and src.suffix == ".zip":
        tmp = Path(tempfile.mkdtemp(prefix="zerocore_"))
        with zipfile.ZipFile(src) as z:
            for n in z.namelist():  # защита от выхода за пределы каталога
                if n.startswith("/") or ".." in Path(n).parts:
                    raise ZeroCoreError(f"небезопасный путь в архиве: {n}")
            z.extractall(tmp)
        if (tmp / "manifest.json").exists():
            return tmp, tmp
        subs = [p for p in tmp.iterdir() if p.is_dir() and (p / "manifest.json").exists()]
        if len(subs) != 1:
            raise ZeroCoreError("в архиве должен быть ровно один модуль с manifest.json")
        return subs[0], tmp
    return src, None


def install(mgr, source):
    src, tmp = _unpack(source)
    try:
        m = validate_source(src)
        root = mgr.module_root(m.name)
        dest = root / "versions" / m.version
        with mgr.txn(f"install {m.name} {m.version}") as t:
            st = mgr.store.load()
            first = m.name not in st["modules"]
            if dest.exists():
                raise ZeroCoreError(f"{m.name} {m.version}: эта версия уже установлена")
            t.add_undo("rmtree", str(root if first else dest))
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(src, dest)
            if first:
                os.symlink(f"versions/{m.version}", root / "current")
                st["modules"][m.name] = {"version": m.version, "versions": [m.version], "enabled": False,
                                         "previous": None, "desired": False}
            else:
                st["modules"][m.name]["versions"].append(m.version)
            (mgr.home / "data" / m.name).mkdir(parents=True, exist_ok=True)
            mgr.store.save(st)
        mgr.emit("module.installed", module=m.name, version=m.version)
        return m
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
