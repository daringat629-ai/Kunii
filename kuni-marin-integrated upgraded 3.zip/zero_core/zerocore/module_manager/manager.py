"""Менеджер модулей: единая точка управления. Все изменения идут через ConfigTransaction."""
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

from ..kernel import health as health_mod
from ..kernel import migrations
from ..kernel.contracts import Manifest
from ..kernel.errors import ContractError, DependencyError, ConflictError, LifecycleError, ZeroCoreError
from ..kernel.event_bus import EventBus
from ..kernel.lifecycle import ProcessRunner, wait_until
from ..kernel.service_registry import Registry
from ..kernel.txn import ConfigTransaction, StateStore, _atomic_write, recover
from . import dependency_solver as solver

TEMPLATE = re.compile(r"\$\{([a-z_.]+)\}")


class Manager:
    def __init__(self, home, repo_root=None):
        self.home = Path(home)
        for d in ("modules", "data", "run", "config", ".trash"):
            (self.home / d).mkdir(parents=True, exist_ok=True)
        self.repo_root = Path(repo_root) if repo_root else Path(__file__).resolve().parents[2]
        self.store = StateStore(self.home)
        self.runtime = StateStore(self.home, "runtime.json", {})
        self.runner = ProcessRunner(self.home / "run")
        migrations.apply(self.home / "zerocore.db", self.repo_root / "migrations")
        self.bus = EventBus(self.home / "zerocore.db")
        self.recovered = recover(self.home, self.store)
        if self.recovered:
            self.bus.publish("txn.recovered", {"msg": "прерванная операция откатана"})
        self.gc_trash()
        if not self.tools_path().exists() and self.enabled_names():
            self.refresh_tools()

    # ---------- базовое ----------
    def txn(self, label):
        return ConfigTransaction(self.home, label, self.store)

    def gc_trash(self):
        for p in (self.home / ".trash").iterdir():
            shutil.rmtree(p, ignore_errors=True)

    def module_root(self, name):
        return self.home / "modules" / name

    def module_dir(self, name, version=None):
        root = self.module_root(name)
        return root / "versions" / version if version else (root / "current").resolve()

    def manifest(self, name, version=None):
        return Manifest.load(self.module_dir(name, version) / "manifest.json")

    def installed(self):
        return self.store.load()["modules"]

    def enabled_names(self):
        return [n for n, m in self.installed().items() if m.get("enabled")]

    def enabled_manifests(self, add=None, replace=None, remove=None):
        out = {}
        names = set(self.enabled_names()) | ({add} if add else set())
        for n in sorted(names - ({remove} if remove else set())):
            out[n] = (replace or {}).get(n) or self.manifest(n)
        return out

    def emit(self, topic, **payload):
        try:
            self.bus.publish(topic, payload, producer="manager")
        except Exception:
            pass  # журнал событий не должен ломать операцию

    # ---------- конфигурация модулей ----------
    def config_path(self, name):
        return self.home / "config" / f"{name}.json"

    def config(self, name, mdir=None):
        """Значения по умолчанию берутся из манифеста запускаемой версии (mdir), поверх них пользовательские."""
        base = Manifest.load(Path(mdir) / "manifest.json") if mdir else self.manifest(name)
        cfg = dict(base.config)
        try:
            cfg.update(json.loads(self.config_path(name).read_text(encoding="utf-8")))
        except (OSError, ValueError):
            pass
        return cfg

    def config_update(self, name, fn):
        """Атомарное «прочитать-изменить-записать» под блокировкой: параллельные изменения не теряются."""
        with self.txn(f"config {name}") as t:
            m = self.manifest(name)
            path = self.config_path(name)
            old = path.read_text(encoding="utf-8") if path.exists() else None
            t.add_undo("restore_file", str(path), old)
            cfg = self.config(name)
            fn(cfg)
            unknown = set(cfg) - set(m.config)
            if unknown:
                raise ZeroCoreError(f"{name}: неизвестные параметры конфигурации: {', '.join(sorted(unknown))}")
            _atomic_write(path, json.dumps(cfg, ensure_ascii=False, indent=1, sort_keys=True))
        self.emit("config.changed", module=name)
        self.refresh_tools()
        return cfg

    def config_set(self, name, key, value):
        return self.config_update(name, lambda c: c.__setitem__(key, value))

    def _expand(self, obj, name, mdir):
        cfg = self.config(name, mdir)

        def rep(m):
            k = m.group(1)
            if k == "data_dir":
                return str(self.home / "data" / name)
            if k == "home":
                return str(self.home)
            if k == "module_dir":
                return str(mdir)
            if k.startswith("config."):
                v = cfg.get(k[7:], "")
                return "1" if v is True else "" if v in (False, None) else str(v)
            return ""
        if isinstance(obj, str):
            return TEMPLATE.sub(rep, obj)
        if isinstance(obj, list):
            return [self._expand(x, name, mdir) for x in obj]
        if isinstance(obj, dict):
            return {k: self._expand(v, name, mdir) for k, v in obj.items()}
        return obj

    def _env(self, name, m, mdir, staging=False):
        env = dict(os.environ)
        env.update({"ZEROCORE_API": "1", "ZEROCORE_HOME": str(self.home), "ZEROCORE_MODULE": name,
                    "ZEROCORE_DATA_DIR": str(self.home / "data" / name), "ZEROCORE_STAGING": "1" if staging else ""})
        (self.home / "data" / name).mkdir(parents=True, exist_ok=True)
        for k, v in self._expand(m.run.get("env", {}), name, mdir).items():
            if v != "":
                env[k] = v
        return env

    # ---------- каталог инструментов для kuni ----------
    def tools_path(self):
        return self.home / "tools.json"

    def _tool_env(self, name, m, mdir):
        """Минимальная среда инструмента: никаких секретов из окружения менеджера."""
        data = self.home / "data" / name
        data.mkdir(parents=True, exist_ok=True)
        env = {"ZEROCORE_API": "1", "ZEROCORE_HOME": str(self.home), "ZEROCORE_MODULE": name, "ZEROCORE_DATA_DIR": str(data)}
        for k, v in self._expand(m.run.get("env", {}), name, mdir).items():
            if v != "":
                env[k] = v
        return env

    def export_tools(self):
        """Пишет tools.json: инструменты включённых модулей, шаблоны раскрыты. Файл меняется атомарно и только если
        содержимое изменилось, поэтому kuni не перечитывает его зря."""
        import os as _os
        tools, errors, owner = [], [], {}
        for name in sorted(self.enabled_names()):
            try:
                m = self.manifest(name)
                mdir = self.module_dir(name)
                env = self._tool_env(name, m, mdir) if m.tools else {}
            except ZeroCoreError as ex:
                errors.append(f"{name}: {ex}")
                continue
            for t in m.tools:
                if t["name"] in owner:
                    errors.append(f"{name}: имя инструмента {t['name']} уже занято модулем {owner[t['name']]}")
                    continue
                owner[t["name"]] = name
                tools.append({"module": name, "name": t["name"], "description": t["description"],
                              "parameters": {"properties": t.get("parameters", {}), "required": t.get("required", [])},
                              "command": self._expand(t["command"], name, mdir), "cwd": str(mdir), "env": env,
                              "timeout_seconds": t.get("timeout_seconds", 30),
                              "max_output_bytes": t.get("max_output_bytes", 8000)})
        catalog = {"version": 1, "tools": tools, "errors": errors}
        path = self.tools_path()
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
            old.pop("generated", None)
        except (OSError, ValueError):
            old = None
        if old != catalog:
            _atomic_write(path, json.dumps({**catalog, "generated": time.time()}, ensure_ascii=False, indent=1))
            _os.chmod(path, 0o644)
        return catalog

    def refresh_tools(self):
        """Обновляет каталог после изменения набора модулей. Сбой экспорта не ломает основную операцию."""
        try:
            before = self.tools_path().stat().st_mtime if self.tools_path().exists() else None
            cat = self.export_tools()
            after = self.tools_path().stat().st_mtime if self.tools_path().exists() else None
            if before != after:
                self.emit("tools.exported", count=len(cat["tools"]), problems=len(cat["errors"]))
        except Exception as ex:
            self.emit("tools.export_failed", error=str(ex)[:300])

    # ---------- состояние ----------
    def is_running(self, name, m=None):
        m = m or self.manifest(name)
        if m.kind == "external":
            spec = self._expand(m.health, name, self.module_dir(name))
            return spec.get("type") == "pgrep" and health_mod.check(spec).state == "healthy"
        if m.kind in ("library", "job"):
            return False
        return self.runner.pid(name) is not None

    def health(self, name):
        m = self.manifest(name)
        spec = self._expand(m.health, name, self.module_dir(name))
        rt = self.runtime.load().get(name, {})
        return health_mod.check(spec, self.runner, name, "", rt, interval=m.run.get("schedule_seconds"))

    def status(self):
        rows = []
        for n, ms in sorted(self.installed().items()):
            row = {"name": n, "version": ms["version"], "enabled": ms.get("enabled", False), "versions": ms["versions"]}
            try:
                m = self.manifest(n)
                row.update(kind=m.kind, provides=m.provides, running=self.is_running(n, m),
                           health=self.health(n).state, detail=self.health(n).detail)
            except ZeroCoreError as ex:
                row.update(kind="?", provides=[], running=False, health="broken", detail=str(ex))
            rows.append(row)
        return rows

    def check_integrity(self):
        """Проблемы целостности включённых модулей (потерянная зависимость, конфликт, битый манифест)."""
        try:
            solver.solve(self.enabled_manifests())
            return []
        except (DependencyError, ConflictError, ContractError) as ex:
            return [str(ex)]

    # ---------- процессы ----------
    def _run_cmd(self, argv, timeout=20):
        try:
            r = subprocess.run(argv, capture_output=True, timeout=timeout, text=True)
        except (OSError, subprocess.TimeoutExpired) as ex:
            raise LifecycleError(f"команда {argv[0]} не выполнена: {ex}")
        if r.returncode != 0:
            raise LifecycleError(f"команда {argv[0]} завершилась кодом {r.returncode}: {(r.stderr or r.stdout).strip()[:300]}")

    def _spawn(self, name, m, mdir, suffix="", staging=False):
        argv = self._expand(m.run["command"], name, mdir)
        cwd = self._expand(m.run.get("cwd", "${module_dir}"), name, mdir)
        self.runner.start(name, argv, cwd, self._env(name, m, mdir, staging), m.limits, suffix)

    def _start_instance(self, name, m, mdir, suffix="", staging=False):
        if m.kind == "external":
            self._run_cmd(self._expand(m.run["start_command"], name, mdir))
        else:
            self._spawn(name, m, mdir, suffix, staging)
        self._wait_ready(name, m, mdir, suffix)

    def _stop_instance(self, name, m, suffix=""):
        timeout = m.run.get("stop_timeout", 10)
        if m.kind == "external":
            mdir = self.module_dir(name)
            if m.run.get("stop_command"):
                self._run_cmd(self._expand(m.run["stop_command"], name, mdir))
            if not wait_until(lambda: not self.is_running(name, m), timeout):
                if m.run.get("kill_command"):
                    self._run_cmd(self._expand(m.run["kill_command"], name, mdir))
                if not wait_until(lambda: not self.is_running(name, m), 5):
                    raise LifecycleError(f"{name}: не удалось остановить")
            return
        self.runner.stop(name, timeout, suffix)

    def _wait_ready(self, name, m, mdir, suffix=""):
        spec = self._expand(m.health, name, mdir)
        timeout = m.run.get("start_timeout", 10)
        end = time.time() + timeout
        t = spec.get("type", "none")
        if t in ("none", "process") and m.kind != "external":
            time.sleep(0.3)
            if not self.runner.pid(name, suffix):
                raise LifecycleError(f"{name}: завершился сразу после запуска. Лог: {self.runner.log_tail(name)!r}")
            return
        last = None
        while time.time() < end:
            if m.kind != "external" and not self.runner.pid(name, suffix):
                raise LifecycleError(f"{name}: процесс завершился при запуске. Лог: {self.runner.log_tail(name)!r}")
            last = health_mod.check(spec, self.runner, name, suffix)
            if last.state == "healthy":
                return
            time.sleep(0.1)
        raise LifecycleError(f"{name}: не стал здоровым за {timeout} с ({last.detail if last else '?'})")

    def _flag(self, names, key, value):
        with self.txn(f"flag {key}") as t:
            st = self.store.load()
            for n in names:
                if n in st["modules"]:
                    st["modules"][n][key] = value
            self.store.save(st)

    def _closure(self, name, manifests):
        reg = Registry(manifests)
        edges, _ = solver._edges(manifests, reg)
        seen, stack = set(), [name]
        while stack:
            n = stack.pop()
            if n not in seen:
                seen.add(n)
                stack.extend(edges.get(n, ()))
        return seen

    def start(self, name):
        st = self.installed()
        if name not in st:
            raise ZeroCoreError(f"{name}: не установлен")
        if not st[name].get("enabled"):
            raise ZeroCoreError(f"{name}: не включён (zerocore enable {name})")
        manifests = self.enabled_manifests()
        order = solver.solve(manifests)
        closure = self._closure(name, manifests)
        started = []
        for n in [x for x in order if x in closure]:
            m = manifests[n]
            if m.kind in ("library", "job") or self.is_running(n, m):
                continue
            try:
                self._start_instance(n, m, self.module_dir(n))
            except ZeroCoreError as ex:
                self.emit("module.failed", module=n, error=str(ex)[:500])
                raise
            started.append(n)
            self.emit("module.started", module=n)
        self._flag([n for n in closure if manifests[n].kind in ("service", "external")], "desired", True)
        return started

    def stop(self, name):
        manifests = self.enabled_manifests()
        victims = []
        if name in manifests:
            deps = solver.dependents(name, manifests)
            victims = [n for n in reversed(solver.solve(manifests)) if n in deps]
        stopped = []
        for n in victims + [name]:
            m = manifests.get(n) or self.manifest(n)
            if self.is_running(n, m):
                self._stop_instance(n, m)
                stopped.append(n)
                self.emit("module.stopped", module=n)
        self._flag(victims + [name], "desired", False)
        return stopped

    def restart(self, name):
        self.stop(name)
        return self.start(name)

    # ---------- жизненный цикл набора ----------
    def install(self, source):
        from . import installer
        return installer.install(self, source)

    def enable(self, name):
        with self.txn(f"enable {name}"):
            st = self.store.load()
            if name not in st["modules"]:
                raise ZeroCoreError(f"{name}: не установлен")
            if st["modules"][name].get("enabled"):
                return False
            solver.solve(self.enabled_manifests(add=name))  # ошибка до любых изменений
            st["modules"][name]["enabled"] = True
            self.store.save(st)
        self.emit("module.enabled", module=name)
        self.refresh_tools()
        m = self.manifest(name)
        if m.kind in ("service", "external") and m.run.get("autostart", True):
            self.start(name)
        return True

    def disable(self, name, cascade=False):
        manifests = self.enabled_manifests()
        if name not in manifests:
            return []
        deps = solver.dependents(name, manifests)
        if deps and not cascade:
            raise DependencyError(f"от {name} зависят включённые модули: {', '.join(sorted(deps))} (используйте cascade)")
        victims = [n for n in reversed(solver.solve(manifests)) if n in deps] + [name]
        for n in victims:
            if self.is_running(n, manifests[n]):
                self._stop_instance(n, manifests[n])
        with self.txn(f"disable {name}"):
            st = self.store.load()
            for n in victims:
                st["modules"][n]["enabled"] = False
                st["modules"][n]["desired"] = False
            self.store.save(st)
        for n in victims:
            self.emit("module.disabled", module=n)
        self.refresh_tools()
        return victims

    def swap(self, name, version):
        from . import hot_swap
        return hot_swap.swap(self, name, version)

    def rollback(self, name):
        from . import rollback
        return rollback.rollback(self, name)

    def uninstall(self, name, purge_data=None, force=False, _fail_after_move=False):
        from . import uninstall
        return uninstall.uninstall(self, name, purge_data, force, _fail_after_move)

    # ---------- периодическая работа (cron раз в минуту) ----------
    def tick(self, now=None):
        import fcntl
        now = now or time.time()
        lock = open(self.home / "tick.lock", "a+")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return ["tick уже выполняется, пропуск"]
        actions = []
        try:
            rt = self.runtime.load()
            problems = self.check_integrity()
            if problems and rt.get("_integrity") != problems:
                self.emit("integrity.broken", problems=problems)
                actions.append("целостность нарушена: " + "; ".join(problems))
            rt["_integrity"] = problems
            st = self.installed()
            for n in self.enabled_names():
                try:
                    m = self.manifest(n)
                except ZeroCoreError as ex:
                    actions.append(f"{n}: {ex}")
                    continue
                e = rt.setdefault(n, {})
                if m.kind == "job" and now - e.get("last_run", 0) >= m.run["schedule_seconds"]:
                    argv = self._expand(m.run["command"], n, self.module_dir(n))
                    cwd = self._expand(m.run.get("cwd", "${module_dir}"), n, self.module_dir(n))
                    try:
                        r = subprocess.run(argv, cwd=cwd, env=self._env(n, m, self.module_dir(n)), capture_output=True,
                                           text=True, timeout=m.run.get("timeout", 55))
                        e.update(last_run=now, last_rc=r.returncode, last_out=(r.stdout + r.stderr)[-300:])
                    except (OSError, subprocess.TimeoutExpired) as ex:
                        e.update(last_run=now, last_rc=-1, last_out=str(ex)[:300])
                    actions.append(f"{n}: задача выполнена, код {e['last_rc']}")
                    if e["last_rc"] != 0:
                        self.emit("job.failed", module=n, rc=e["last_rc"])
                h = self.health(n).state if m.kind != "library" or m.health.get("type") != "none" else "unknown"
                if h != e.get("health"):
                    self.emit("health.changed", module=n, old=e.get("health"), new=h)
                    e["health"] = h
                if (m.kind == "service" and m.run.get("restart") == "on-failure" and st[n].get("desired")
                        and h in ("stopped", "unhealthy")):
                    stamps = [t for t in e.get("restarts", []) if now - t < 600]
                    if len(stamps) >= 3:
                        if not e.get("suppressed"):
                            self.emit("restart.suppressed", module=n)
                            e["suppressed"] = True
                    else:
                        try:
                            self._stop_instance(n, m)
                            self._start_instance(n, m, self.module_dir(n))
                            stamps.append(now)
                            e["suppressed"] = False
                            actions.append(f"{n}: перезапущен")
                            self.emit("module.restarted", module=n)
                        except ZeroCoreError as ex:
                            stamps.append(now)
                            actions.append(f"{n}: перезапуск не удался: {str(ex)[:120]}")
                    e["restarts"] = stamps
            self.runtime.save(rt)
        finally:
            lock.close()
        return actions
