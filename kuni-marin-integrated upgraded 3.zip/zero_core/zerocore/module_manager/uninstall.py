"""Безопасное удаление: код уходит в корзину под транзакцией; данные по политике модуля (keep/delete) или флагу."""
import os
import shutil
import time

from ..kernel.errors import DependencyError, ZeroCoreError
from . import dependency_solver as solver


def uninstall(mgr, name, purge_data=None, force=False, _fail_after_move=False):
    ms = mgr.installed().get(name)
    if not ms:
        raise ZeroCoreError(f"{name}: не установлен")
    manifests = mgr.enabled_manifests()
    deps = solver.dependents(name, manifests) if name in manifests else set()
    if deps and not force:
        raise DependencyError(f"от {name} зависят включённые модули: {', '.join(sorted(deps))} (используйте force)")
    if name in manifests:
        mgr.disable(name, cascade=True)
    m = mgr.manifest(name)
    if mgr.is_running(name, m):
        mgr._stop_instance(name, m)
    purge = purge_data if purge_data is not None else m.data_policy == "delete"
    trash = mgr.home / ".trash" / f"{name}-{int(time.time() * 1000)}"
    root, data, cfg = mgr.module_root(name), mgr.home / "data" / name, mgr.config_path(name)
    with mgr.txn(f"uninstall {name}") as t:
        st = mgr.store.load()
        trash.mkdir(parents=True)
        t.add_undo("mv", str(trash / "code"), str(root))
        os.replace(root, trash / "code")
        if purge and data.exists():
            t.add_undo("mv", str(trash / "data"), str(data))
            os.replace(data, trash / "data")
        if purge and cfg.exists():
            t.add_undo("restore_file", str(cfg), cfg.read_text(encoding="utf-8"))
            cfg.unlink()
        del st["modules"][name]
        mgr.store.save(st)
        if _fail_after_move:
            raise RuntimeError("операция прервана (тестовая точка)")
    shutil.rmtree(trash, ignore_errors=True)  # только после успешной фиксации
    mgr.emit("module.uninstalled", module=name, purged=bool(purge))
    mgr.refresh_tools()
    return {"purged_data": bool(purge)}
