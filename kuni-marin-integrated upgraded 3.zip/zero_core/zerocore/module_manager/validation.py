"""Проверка модуля до установки: манифест, наличие файлов, совместимость с уже включёнными модулями."""
from pathlib import Path

from ..kernel.contracts import Manifest
from ..kernel.errors import ContractError


def validate_source(path):
    p = Path(path)
    if not (p / "manifest.json").is_file():
        raise ContractError(f"{p}: нет manifest.json")
    m = Manifest.load(p / "manifest.json")
    run = m.run
    if m.kind in ("service", "job"):
        first = run["command"][0]
        if first.startswith("${module_dir}"):
            rel = first.replace("${module_dir}/", "", 1)
            if not (p / rel).exists():
                raise ContractError(f"{m.name}: файл {rel} из run.command не найден в модуле")
    for arg in run.get("command", []):
        if arg.startswith("${module_dir}/") and not (p / arg.replace("${module_dir}/", "", 1)).exists():
            raise ContractError(f"{m.name}: файл {arg} не найден в модуле")
    return m
