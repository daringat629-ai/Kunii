"""Решатель зависимостей: версии, отсутствующие провайдеры, конфликты, циклы; порядок запуска."""
from ..kernel.contracts import satisfies
from ..kernel.errors import ConflictError, DependencyError
from ..kernel.service_registry import Registry


def _edges(manifests, reg):
    edges, problems = {n: set() for n in manifests}, []
    for m in manifests.values():
        for cap in m.requires:
            p = reg.provider(cap)
            if p is None:
                problems.append(f"{m.name}: нет модуля, предоставляющего {cap}")
            elif p != m.name:
                edges[m.name].add(p)
        for dep, cons in m.depends.items():
            d = manifests.get(dep)
            if d is None:
                problems.append(f"{m.name}: требуется модуль {dep} {cons}, но он не включён")
            elif not satisfies(d.version, cons):
                problems.append(f"{m.name}: нужен {dep} {cons}, а включена версия {d.version}")
            else:
                edges[m.name].add(dep)
    return edges, problems


def solve(manifests):
    """manifests: {имя: Manifest} включённых модулей. Возвращает порядок запуска (зависимости раньше)."""
    reg = Registry(manifests)  # дубли возможностей -> ConflictError
    for m in manifests.values():
        for c in m.conflicts:
            if c in manifests:
                raise ConflictError(f"{m.name} конфликтует с {c}")
    edges, problems = _edges(manifests, reg)
    if problems:
        raise DependencyError("; ".join(problems))
    order, left = [], {n: set(d) for n, d in edges.items()}
    while left:
        ready = sorted(n for n, d in left.items() if not d)
        if not ready:
            raise DependencyError("циклическая зависимость между модулями: " + ", ".join(sorted(left)))
        for n in ready:
            order.append(n)
            del left[n]
        for d in left.values():
            d.difference_update(ready)
    return order


def dependents(name, manifests):
    """Все модули, которые прямо или косвенно зависят от name."""
    reg = Registry({n: m for n, m in manifests.items()})
    edges, _ = _edges(manifests, reg)
    result, frontier = set(), {name}
    while frontier:
        nxt = {n for n, deps in edges.items() if deps & frontier and n not in result and n != name}
        result |= nxt
        frontier = nxt
    return result
