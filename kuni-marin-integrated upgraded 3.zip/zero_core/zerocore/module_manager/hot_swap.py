"""Горячая замена версии модуля.
parallel (по умолчанию): новая версия стартует рядом, проверяется, затем атомарно переключается symlink current
и останавливается старая. Если новая не здорова, старая продолжает работать, состояние не меняется.
stop_first (для модулей с фиксированным портом): старая останавливается, новая стартует, при неудаче старая возвращается."""
import os
from pathlib import Path

from ..kernel.errors import LifecycleError, ZeroCoreError
from . import dependency_solver as solver


def _switch(link, version):
    tmp = link.with_name("current.new")
    if os.path.lexists(tmp):
        tmp.unlink()
    os.symlink(f"versions/{version}", tmp)
    os.replace(tmp, link)  # атомарно


def swap(mgr, name, new_version):
    with mgr.txn(f"swap {name} -> {new_version}") as t:
        st = mgr.store.load()
        ms = st["modules"].get(name)
        if not ms:
            raise ZeroCoreError(f"{name}: не установлен")
        if new_version not in ms["versions"]:
            raise ZeroCoreError(f"{name}: версия {new_version} не установлена (есть: {', '.join(ms['versions'])})")
        old = ms["version"]
        if old == new_version:
            raise ZeroCoreError(f"{name}: версия {new_version} уже активна")
        old_m, new_m = mgr.manifest(name), mgr.manifest(name, new_version)
        if ms.get("enabled"):
            solver.solve(mgr.enabled_manifests(replace={name: new_m}))  # система должна остаться согласованной
        link = mgr.module_root(name) / "current"
        old_target = os.readlink(link)
        old_dir, new_dir = mgr.module_dir(name), mgr.module_dir(name, new_version)
        running = mgr.is_running(name, old_m)
        strategy = "stop_first" if new_m.kind == "external" else new_m.run.get("handoff", "parallel")

        def do_switch():
            t.add_undo("symlink", str(link), old_target)
            _switch(link, new_version)

        if not running or new_m.kind not in ("service", "external"):
            do_switch()
        elif strategy == "parallel":
            mgr._spawn(name, new_m, new_dir, suffix=".staging", staging=True)
            try:
                mgr._wait_ready(name, new_m, new_dir, suffix=".staging")
            except ZeroCoreError as ex:
                mgr.runner.stop(name, 5, ".staging")
                mgr.emit("swap.failed", module=name, version=new_version, error=str(ex)[:300])
                raise LifecycleError(f"{name} {new_version}: новая версия не запустилась, "
                                     f"продолжает работать {old}. {ex}")
            do_switch()
            try:
                mgr.runner.stop(name, old_m.run.get("stop_timeout", 10))
                mgr.runner.promote(name, ".staging", "")
            except BaseException:
                mgr.runner.stop(name, 5, ".staging")
                raise
        else:  # stop_first
            mgr._stop_instance(name, old_m)
            try:
                mgr._start_instance(name, new_m, new_dir)
            except ZeroCoreError as ex:
                try:
                    mgr._stop_instance(name, new_m)
                except ZeroCoreError:
                    pass
                try:
                    mgr._start_instance(name, old_m, old_dir)  # возврат старой версии
                except ZeroCoreError:
                    pass
                mgr.emit("swap.failed", module=name, version=new_version, error=str(ex)[:300])
                raise LifecycleError(f"{name} {new_version}: не запустилась, старая версия {old} возвращена. {ex}")
            do_switch()
        ms["previous"], ms["version"] = old, new_version
        mgr.store.save(st)
    mgr.emit("module.swapped", module=name, old=old, new=new_version)
    mgr.refresh_tools()
    return old, new_version
