"""Откат на предыдущую версию той же безопасной процедурой, что и обновление."""
from ..kernel.errors import ZeroCoreError
from . import hot_swap


def rollback(mgr, name):
    ms = mgr.installed().get(name)
    if not ms:
        raise ZeroCoreError(f"{name}: не установлен")
    prev = ms.get("previous")
    if not prev:
        raise ZeroCoreError(f"{name}: нет предыдущей версии для отката")
    return hot_swap.swap(mgr, name, prev)
