"""Поиск модулей в каталоге: подпапки с manifest.json."""
from pathlib import Path

from ..kernel.contracts import Manifest
from ..kernel.errors import ContractError


def discover(root):
    """Возвращает (найденные, ошибки): {name: (path, Manifest)} и [(path, текст ошибки)]."""
    found, errors = {}, []
    root = Path(root)
    if not root.is_dir():
        return found, errors
    for d in sorted(p for p in root.iterdir() if p.is_dir() and (p / "manifest.json").exists()):
        try:
            m = Manifest.load(d / "manifest.json")
            found[m.name] = (d, m)
        except ContractError as ex:
            errors.append((str(d), str(ex)))
    return found, errors
