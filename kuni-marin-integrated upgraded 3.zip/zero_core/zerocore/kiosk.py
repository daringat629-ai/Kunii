"""Киоск: показать панель на экране самого ноутбука, если на Ubuntu нет графической оболочки (только командная строка).
Ставится минимум: графический сервер Xorg, оконный менеджер Openbox (курсор мыши и тачпада работает) и браузер на весь экран.
Модуль только формирует текст скрипта установки и служб systemd: сам он ничего не устанавливает и root не требует."""
import re
import shlex
from pathlib import Path

from .kernel.errors import ZeroCoreError

KDIR_NAME = ".zerocore-kiosk"
BROWSERS = {"epiphany": "epiphany-browser", "chromium": "chromium-browser", "firefox": "firefox", "existing": ""}
BASE_PACKAGES = ["xserver-xorg", "xserver-xorg-legacy", "xinit", "openbox", "x11-xserver-utils", "curl"]
USER_RE = re.compile(r"^[a-z_][a-z0-9_-]{0,31}$")
HEREDOC = "ZC_EOF"

OPENBOX_RC = """<?xml version="1.0" encoding="UTF-8"?>
<openbox_config xmlns="http://openbox.org/3.4/rc">
  <applications>
    <application class="*">
      <decor>no</decor>
      <maximized>yes</maximized>
      <fullscreen>yes</fullscreen>
    </application>
  </applications>
  <keyboard>
    <keybind key="C-A-q"><action name="Exit"/></keybind>
  </keyboard>
</openbox_config>
"""

SESSION = """#!/bin/sh
# Сессия киоска: запускается через xinit на экране ноутбука. Ctrl+Alt+Q закрывает киоск.
KDIR="$HOME/%(kdir)s"
ZHOME=%(zhome)s
PORT=%(port)d
PREFERRED=%(browser)s
xset s off -dpms s noblank 2>/dev/null
xsetroot -cursor_name left_ptr 2>/dev/null
openbox --config-file "$KDIR/openbox-rc.xml" &
i=0
while [ "$i" -lt 60 ]; do
    curl -fs -o /dev/null "http://127.0.0.1:$PORT/" && break
    i=$((i + 1))
    sleep 1
done
TOKEN=$(cat "$ZHOME/panel_token" 2>/dev/null)
URL="http://127.0.0.1:$PORT/#token=$TOKEN"
pick() { for b in "$@"; do if command -v "$b" >/dev/null 2>&1; then echo "$b"; return; fi; done; }
case "$PREFERRED" in
    chromium) B=$(pick chromium-browser chromium) ;;
    firefox) B=$(pick firefox) ;;
    epiphany) B=$(pick epiphany-browser epiphany) ;;
    *) B= ;;
esac
[ -n "$B" ] || B=$(pick chromium-browser chromium firefox epiphany-browser epiphany surf)
if [ -z "$B" ]; then
    echo "браузер не найден: установите chromium-browser, firefox или epiphany-browser" >&2
    sleep 30
    exit 1
fi
case "$B" in
    chromium-browser|chromium) exec "$B" --kiosk --no-first-run --noerrdialogs --disable-infobars --disable-session-crashed-bubble --password-store=basic --user-data-dir="$KDIR/chromium" "$URL" ;;
    firefox) exec "$B" --kiosk "$URL" ;;
    epiphany-browser|epiphany) exec "$B" --application-mode --profile="$KDIR/epiphany" "$URL" ;;
    *) exec "$B" -F "$URL" ;;
esac
"""


def sd_quote(s):
    """Аргумент для ExecStart: в двойных кавычках, если есть пробелы или спецсимволы."""
    s = str(s)
    if re.fullmatch(r"[A-Za-z0-9_./:@%+=,-]+", s):
        return s
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def session_script(zerocore_home, port, browser):
    if browser not in BROWSERS:
        raise ZeroCoreError(f"браузер: одно из {', '.join(BROWSERS)}")
    return SESSION % {"kdir": KDIR_NAME, "zhome": shlex.quote(str(zerocore_home)), "port": int(port), "browser": shlex.quote(browser)}


def panel_unit(user, user_home, python, zerocore_py, zerocore_home, port):
    return f"""[Unit]
Description=Zero Core: веб-панель
After=network.target

[Service]
User={user}
Environment=HOME={sd_quote(user_home)}
ExecStart={sd_quote(python)} {sd_quote(zerocore_py)} --home {sd_quote(zerocore_home)} panel --host 127.0.0.1 --port {int(port)}
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
"""


def kiosk_unit(user, user_home):
    kdir = Path(user_home) / KDIR_NAME
    return f"""[Unit]
Description=Zero Core: панель на экране ноутбука (X11 + браузер)
After=systemd-user-sessions.service zerocore-panel.service
Wants=zerocore-panel.service

[Service]
User={user}
PAMName=login
TTYPath=/dev/tty7
StandardInput=tty
StandardOutput=journal
StandardError=journal
UtmpIdentifier=tty7
UtmpMode=user
Environment=HOME={sd_quote(user_home)}
ExecStart=/usr/bin/xinit {sd_quote(kdir / 'session.sh')} -- :0 vt7 -nolisten tcp -keeptty
ExecStartPost=+/usr/bin/chvt 7
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
"""


def setup_script(user, user_home, zerocore_home, zerocore_py, python, port=8767, browser="epiphany", boot=False):
    """Готовый shell-скрипт для `sudo sh`: пакеты, файлы киоска, службы. Переменная ZC_ROOT (для проверки) сдвигает записываемые в систему пути."""
    if not USER_RE.match(user or ""):
        raise ZeroCoreError("имя пользователя: строчные латинские буквы, цифры, _ и -")
    if browser not in BROWSERS:
        raise ZeroCoreError(f"браузер: одно из {', '.join(BROWSERS)}")
    packages = BASE_PACKAGES + ([BROWSERS[browser]] if BROWSERS[browser] else [])
    kdir = f"{user_home}/{KDIR_NAME}"

    def heredoc(path, content, mode=None):
        body = f"cat > {path} <<'{HEREDOC}'\n{content.rstrip(chr(10))}\n{HEREDOC}\n"
        return body + (f"chmod {mode} {path}\n" if mode else "")

    parts = [f"""#!/bin/sh
# Создано командой `zerocore kiosk setup`. Запуск: sudo sh <этот файл>
# Ставит минимальную графику (Xorg + Openbox + браузер), чтобы панель открывалась на экране самого ноутбука, с курсором мыши и тачпада.
set -eu
KUSER={shlex.quote(user)}
KDIR={shlex.quote(kdir)}
ROOT="${{ZC_ROOT:-}}"
if [ -z "${{ZC_ROOT:-}}" ] && [ "$(id -u)" != 0 ]; then
    echo "Нужны права администратора: sudo sh $0" >&2
    exit 1
fi
id "$KUSER" >/dev/null 2>&1 || {{ echo "Нет пользователя $KUSER" >&2; exit 1; }}
apt-get update
apt-get install -y {' '.join(packages)}
usermod -aG video,input "$KUSER" || true
mkdir -p "$ROOT/etc/X11" "$ROOT/etc/systemd/system" "$KDIR"
""",
             heredoc('"$ROOT/etc/X11/Xwrapper.config"', "allowed_users=anybody\nneeds_root_rights=yes"),
             heredoc('"$KDIR/session.sh"', session_script(zerocore_home, port, browser), "755"),
             heredoc('"$KDIR/openbox-rc.xml"', OPENBOX_RC),
             heredoc('"$ROOT/etc/systemd/system/zerocore-panel.service"', panel_unit(user, user_home, python, zerocore_py, zerocore_home, port)),
             heredoc('"$ROOT/etc/systemd/system/zerocore-kiosk.service"', kiosk_unit(user, user_home)),
             'chown -R "$KUSER":"$KUSER" "$KDIR"\nsystemctl daemon-reload\n']
    if boot:
        parts.append("systemctl enable zerocore-panel zerocore-kiosk\n")
    parts.append(f"""echo
echo "Готово. Если панель уже запущена в tmux, остановите её: tmux kill-session -t zerocore-panel"
echo "Показать панель на экране ноутбука:  sudo systemctl start zerocore-kiosk"
echo "Вернуться к командной строке:        Ctrl+Alt+F1   (или Ctrl+Alt+Q в самом киоске)"
echo "Остановить киоск:                    sudo systemctl stop zerocore-kiosk"
{'echo "Включено при загрузке: ноутбук сам покажет панель."' if boot else 'echo "Чтобы показывать панель при каждой загрузке: sudo systemctl enable zerocore-panel zerocore-kiosk"'}
""")
    return "\n".join(parts)
