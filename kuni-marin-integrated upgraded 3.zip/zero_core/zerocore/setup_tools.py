"""Запуск «как на видео» на настоящей машине: поиск kuni, адреса для телефона, подключение каталога инструментов к конфигу бота, проверка среды."""
import os
import re
import shlex
import shutil
import socket
import sys
import tomllib
from pathlib import Path

from .admin import providers
from .kernel.errors import ZeroCoreError

CATALOG_KEY = "external_tools_catalog"
TMUX_SESSION = "zerocore-panel"


# ---------- поиск kuni ----------
def detect_kuni_dir(explicit=None):
    """Каталог бота: аргумент, переменная ZEROCORE_KUNI_DIR, ~/kuni, /home/marinka/kuni. Признак: config.toml или бинарник kuni."""
    # явно указанный каталог не подменяется другим: если он неверный, это ошибка, а не повод молча взять ~/kuni
    candidates = [explicit] if explicit else [os.environ.get("ZEROCORE_KUNI_DIR"), str(Path.home() / "kuni"), "/home/marinka/kuni"]
    for c in candidates:
        if not c:
            continue
        d = Path(c).expanduser()
        if d.is_dir() and ((d / "config.toml").is_file() or (d / "kuni").is_file()):
            return d
    return None


# ---------- сеть ----------
def lan_ips():
    """Адреса этого компьютера в локальной сети (без loopback), самый вероятный первым."""
    found = []

    def add(ip):
        if re.fullmatch(r"\d{1,3}(\.\d{1,3}){3}", ip) and not ip.startswith(("127.", "169.254.", "0.")) and ip not in found:
            found.append(ip)
    try:   # адрес интерфейса, через который уходит трафик наружу (пакеты не отправляются)
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            add(s.getsockname()[0])
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(info[4][0])
    except OSError:
        pass
    return found


def port_free(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


# ---------- подключение каталога инструментов к конфигу kuni ----------
def _toml_string(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'


def wire_kuni_catalog(config_path, catalog_path):
    """Добавляет/обновляет `external_tools_catalog` в секции [misc] конфига бота. Остальной текст (комментарии, порядок) не трогает.
    Перед первым изменением кладёт копию рядом: config.toml.bak-zerocore. Возвращает 'added', 'updated' или 'unchanged'."""
    path = Path(config_path)
    if not path.is_file():
        raise ZeroCoreError(f"не найден конфиг бота: {path}")
    original = path.read_bytes().decode("utf-8")   # байты, а не read_text: иначе \r\n превратится в \n
    newline = "\r\n" if "\r\n" in original else "\n"
    lines = original.splitlines()
    wanted = f"{CATALOG_KEY} = {_toml_string(catalog_path)}"
    key_re = re.compile(rf"^(\s*){CATALOG_KEY}\s*=")
    section_re = re.compile(r"^\s*\[([^\[\]]+)\]\s*(#.*)?$")
    in_misc, misc_start, misc_end, key_line = False, None, len(lines), None
    for i, line in enumerate(lines):
        m = section_re.match(line)
        if m:
            if in_misc:
                misc_end = i
                in_misc = False
            if m.group(1).strip() == "misc":
                in_misc, misc_start = True, i
        elif in_misc and key_re.match(line):
            key_line = i
    if key_line is not None:
        indent = key_re.match(lines[key_line]).group(1)
        if lines[key_line].strip() == wanted:
            return "unchanged"
        lines[key_line] = indent + wanted
        status = "updated"
    elif misc_start is not None:
        insert_at = misc_end
        while insert_at > misc_start + 1 and not lines[insert_at - 1].strip():
            insert_at -= 1   # перед пустыми строками в конце секции
        lines.insert(insert_at, wanted)
        status = "added"
    else:
        if lines and lines[-1].strip():
            lines.append("")
        lines += ["[misc]", wanted]
        status = "added"
    text = newline.join(lines) + (newline if original.endswith(("\n", "\r\n")) or status == "added" else "")
    try:
        parsed = tomllib.loads(text)
    except tomllib.TOMLDecodeError as ex:
        raise ZeroCoreError(f"после правки конфиг стал бы некорректным TOML ({ex}); файл не изменён")
    if parsed.get("misc", {}).get(CATALOG_KEY) != str(catalog_path):
        raise ZeroCoreError("не удалось записать ключ в секцию [misc]; файл не изменён")
    backup = path.with_name(path.name + ".bak-zerocore")
    if not backup.exists():
        shutil.copy2(path, backup)
    tmp = path.with_name(path.name + ".tmp-zerocore")
    tmp.write_bytes(text.encode("utf-8"))
    os.replace(tmp, path)
    return status


def wired_catalog(config_path):
    """Что сейчас записано в конфиге бота: путь к каталогу или None."""
    try:
        return tomllib.loads(Path(config_path).read_text(encoding="utf-8")).get("misc", {}).get(CATALOG_KEY) or None
    except (OSError, tomllib.TOMLDecodeError):
        return None


# ---------- tmux ----------
def tmux_command(home, host, port, python=None, script=None):
    """Команда для tmux: панель в отдельном окне, переживает закрытие SSH."""
    python = python or sys.executable
    script = script or str(Path(__file__).resolve().parent.parent / "zerocore.py")
    inner = f"{shlex.quote(python)} {shlex.quote(script)} --home {shlex.quote(str(home))} panel --host {shlex.quote(host)} --port {int(port)}"
    return ["tmux", "new-session", "-d", "-s", TMUX_SESSION, inner]


# ---------- doctor ----------
def doctor(manager, kuni_dir=None, port=8767):
    """Список проверок [(статус, название, подробности, что делать)]; статус ok / warn / fail."""
    out = []

    def add(status, title, detail="", fix=""):
        out.append((status, title, detail, fix))

    add("ok" if sys.version_info >= (3, 11) else "fail", "Python 3.11+", sys.version.split()[0], "нужен python3 версии 3.11 или новее (tomllib)")
    home = Path(manager.home)
    add("ok" if os.access(home, os.W_OK) else "fail", "домашний каталог ядра", str(home), "проверьте права на каталог")
    token = home / "panel_token"
    if token.exists():
        mode = token.stat().st_mode & 0o777
        add("ok" if mode & 0o077 == 0 else "warn", "права на токен панели", oct(mode), f"chmod 600 {token}")
    rows = manager.status()
    add("ok" if rows else "warn", "модули установлены", f"{len(rows)} шт., включено {sum(1 for r in rows if r['enabled'])}", "python3 zerocore.py up")
    problems = manager.check_integrity()
    add("ok" if not problems else "fail", "целостность модулей", "; ".join(problems) or "в порядке", "python3 zerocore.py check")

    kdir = detect_kuni_dir(kuni_dir)
    if not kdir:
        add("fail", "каталог бота kuni", f"не найден ({kuni_dir})" if kuni_dir else "не найден", "укажите: --kuni-dir /home/marinka/kuni")
        return out
    add("ok", "каталог бота kuni", str(kdir))
    cfg = kdir / "config.toml"
    llm = providers.parse_llm(cfg) if cfg.is_file() else {"available": False}
    add("ok" if llm.get("available") else "fail", "config.toml бота читается", f"{llm.get('provider', '?')}: {llm.get('model', '')}" if llm.get("available") else "не найден или повреждён",
        "проверьте файл config.toml")
    logs = kdir / "logs"
    n_logs = sum(1 for e in os.scandir(logs) if e.name.endswith("query.json")) if logs.is_dir() else 0
    add("ok" if n_logs else "warn", "журнал запросов LLM (logs/)", f"{n_logs} запросов" if n_logs else "пусто или нет каталога",
        "виджеты «Генерация», «Тулы» и статистика заполнятся после работы бота")
    console = providers.newest("/tmp/aui.*.log")
    add("ok" if console else "warn", "консольный лог бота (/tmp/aui.*.log)", os.path.basename(console) if console else "не найден", "запустите бота: статистика и живой лог берутся оттуда")
    add("ok" if providers.process_rss_mb("kuni") is not None else "warn", "процесс kuni запущен", "", "запустите бота в tmux: ~/kuni/start-safe.sh")
    wired = wired_catalog(cfg) if cfg.is_file() else None
    expected = str(manager.tools_path())
    if wired == expected:
        add("ok", "каталог инструментов подключён к боту", wired)
    else:
        add("warn", "каталог инструментов подключён к боту", f"сейчас: {wired or 'не задан'}", "python3 zerocore.py wire-kuni  (нужен kuni с этапом B)")
    add("ok" if manager.tools_path().exists() else "warn", "каталог инструментов tools.json", str(manager.tools_path()), "python3 zerocore.py tools")
    add("ok" if port_free("127.0.0.1", port) else "warn", f"порт панели {port}", "свободен" if port_free("127.0.0.1", port) else "занят (панель уже запущена?)",
        f"tmux attach -t {TMUX_SESSION}")
    add("ok" if shutil.which("tmux") else "warn", "tmux", shutil.which("tmux") or "не найден", "sudo apt install tmux (панель в фоне, переживает закрытие SSH)")
    ips = lan_ips()
    add("ok" if ips else "warn", "адрес в локальной сети (для телефона)", ", ".join(ips) or "не найден", "подключитесь к Wi-Fi или укажите --host вручную")
    return out
