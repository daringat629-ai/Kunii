CREATE TABLE cursors(
  consumer TEXT PRIMARY KEY,
  last_id INTEGER NOT NULL
);
