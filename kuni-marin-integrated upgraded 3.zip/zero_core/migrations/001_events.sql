CREATE TABLE events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  topic TEXT NOT NULL,
  producer TEXT NOT NULL,
  payload TEXT NOT NULL
);
CREATE INDEX ix_events_topic ON events(topic);
