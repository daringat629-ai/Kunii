# Контракты Нулевое ядро (API версии 1)

## Манифест `manifest.json`
Обязательные: `api` ("1"), `name` (a-z0-9_, 2–32), `version` (1, 1.2 или 1.2.3), `kind`.
Необязательные: `description`, `run`, `provides`, `requires`, `depends`, `conflicts`, `permissions`, `health`, `data_policy`, `limits`, `config`.
Неизвестные поля запрещены.

| kind | Смысл | Обязательное в `run` |
|---|---|---|
| service | долгоживущий процесс | `command` |
| job | периодическая задача, запускает `zerocore tick` | `command`, `schedule_seconds` ≥ 10 |
| external | процесс вне менеджера (например, kuni) | `start_command` (опционально `stop_command`, `kill_command`) |
| library | данные/адаптер без процесса | — |

`run`: `command`, `cwd`, `env`, `start_timeout`, `stop_timeout`, `timeout` (для job), `handoff` (`parallel`|`stop_first`),
`restart` (`never`|`on-failure`), `autostart`.
`provides`/`requires`: возможности вида `группа.имя` (например, `world.state`). Две реализации одной возможности запрещены.
`depends`: `{"модуль": ">=1.0,<2.0"}`. `conflicts`: список модулей.
`permissions`: `network`, `shell`, `read` (список возможностей, чьи `data/<модуль>/shared/` можно читать), `secrets`.
`health`: `none`, `process`, `pgrep` (`process`), `command` (`command`), `http` (`url`), `file_fresh` (`path`, `max_age_seconds`), `job`.
`data_policy`: `keep` (данные остаются при удалении) или `delete`. `limits`: `memory_mb`, `cpu_seconds`, `open_files`.
`config`: значения по умолчанию; переопределяются `zerocore config <модуль> set <ключ> <значение>`.

Шаблоны в `run`, `health`, `env`: `${data_dir}`, `${home}`, `${module_dir}`, `${config.<ключ>}`
(для булевых: true → "1", false → пусто; пустые переменные окружения не передаются).

## Виджеты (`widgets`)
Список описаний: `id`, `title`, `kind` (`kv`, `table`, `text`, `counter`), `command`, необязательно `refresh_seconds` (1–3600), `size` (`w`, `h`), `actions`
(`id`, `label`, `command`). Формат вывода команды и безопасность: `docs/WEBUI.md`.

## Инструменты для LLM (`tools`)
Список: `name`, `description`, `parameters` (`{имя: {type, description}}`), `required`, `command`, `timeout_seconds`, `max_output_bytes`.
Менеджер экспортирует их в `tools.json` для kuni. Формат, протокол процесса и безопасность: `docs/TOOLS.md`.

## Среда процесса (для модулей на любом языке)
`ZEROCORE_API=1`, `ZEROCORE_HOME`, `ZEROCORE_MODULE`, `ZEROCORE_DATA_DIR`, `ZEROCORE_STAGING` (`1` при проверочном запуске новой версии).
Остановка: SIGTERM на группу процессов, после `stop_timeout` SIGKILL.

## Здоровье
Состояния: `healthy`, `unhealthy`, `stopped`, `unknown`.

## События (шина `zerocore.db`)
`module.installed|enabled|disabled|started|stopped|failed|restarted|swapped|uninstalled`, `swap.failed`, `config.changed`,
`health.changed`, `job.failed`, `restart.suppressed`, `integrity.broken`, `txn.recovered`. Полезная нагрузка ≤ 64 КБ, журнал ограничен 10 000 записей.

## Транзакции
Все изменения (установка, включение, замена, конфигурация, удаление) идут через `ConfigTransaction`: блокировка `flock`,
журнал отката до изменений, откат при ошибке, автоматическое восстановление после смерти процесса при следующем запуске.

## Горячая замена
`parallel`: новая версия стартует рядом (`ZEROCORE_STAGING=1`), проверяется здоровье, symlink `current` переключается атомарно,
старая останавливается. Не здорова новая — старая продолжает работать, состояние не меняется.
`stop_first` (для фиксированного порта): старая останавливается, новая стартует, при неудаче старая возвращается.
