#!/usr/bin/env python3
"""Демонстрационные инструменты для LLM. Протокол: JSON {"tool": ..., "arguments": {...}} на stdin, результат на stdout."""
import json
import sys

request = json.load(sys.stdin)
tool, args = request["tool"], request["arguments"]
if tool == "demo_echo":
    print(args["text"])
elif tool == "demo_add":
    print(args["a"] + args["b"])
else:
    print(f"неизвестный инструмент {tool}", file=sys.stderr)
    sys.exit(2)
