#!/usr/bin/env python3
"""Демонстрационный плагин: виджет-счётчик с кнопками. Показывает, как модуль добавляет свой виджет в панель."""
import json
import os
import sys
from pathlib import Path

data = Path(os.environ["ZEROCORE_DATA_DIR"])
data.mkdir(parents=True, exist_ok=True)
f = data / "counter.txt"


def read():
    try:
        return int(f.read_text())
    except (OSError, ValueError):
        return 0


cmd = sys.argv[1] if len(sys.argv) > 1 else "show"
if cmd == "add":
    n = read() + int(sys.argv[2])
    f.write_text(str(n))
    print(f"+{sys.argv[2]} → {n}")
elif cmd == "reset":
    f.write_text("0")
    print("сброшено")
else:
    print(json.dumps({"value": read(), "label": "кликов"}, ensure_ascii=False))
