#!/usr/bin/env python3
"""Виджет панели: состояние предохранителя (по runtime.json менеджера и журналу остановок)."""
import json
import os
import time
from pathlib import Path

home = Path(os.environ["ZEROCORE_HOME"])
try:
    rt = json.loads((home / "runtime.json").read_text(encoding="utf-8")).get("watchdog", {})
except (OSError, ValueError):
    rt = {}
stops, last = 0, ""
try:
    lines = [l for l in (Path.home() / "kuni" / "watchdog.log").read_text(encoding="utf-8").splitlines() if l.strip()]
    stops, last = len(lines), (lines[-1][:120] if lines else "")
except OSError:
    pass


def ago(t):
    if not t:
        return "ещё не запускался"
    s = int(time.time() - t)
    return f"{s} с назад" if s < 120 else f"{s // 60} мин назад"


print(json.dumps({"items": [["последний запуск", ago(rt.get("last_run"))],
                            ["код возврата", str(rt.get("last_rc", "—"))],
                            ["остановок бота", str(stops)],
                            ["последняя остановка", last or "нет"]]}, ensure_ascii=False))
