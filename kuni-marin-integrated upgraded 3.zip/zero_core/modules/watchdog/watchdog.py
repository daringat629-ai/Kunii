#!/usr/bin/env python3
"""Предохранитель для kuni (cron раз в минуту, от пользователя, под которым работает бот).
Останавливает бота (pkill -x kuni), если:
  A) последние 8 ответов модели свежие и содержат один и тот же вызов инструмента (петля #ask);
  B) за последние 3 минуты в консольном логе бота (/tmp/aui.*.log) больше 15 запусков shell (петля команд).
Журнал: ~/kuni/watchdog.log. Проверка без остановки: WATCHDOG_DRY=1 python3 watchdog.py"""
import glob, os, re, subprocess, time

LOGS = os.environ.get("KUNI_LOGS", os.path.expanduser("~/kuni/logs"))
AUI = os.environ.get("AUI_LOGS", "/tmp/aui.*.log")
WINDOW, MAX_EXEC, N_SAME, FRESH = 180, 15, 8, 240


def rule_same_calls():
    files = sorted(glob.glob(os.path.join(LOGS, "*response.json")))[-N_SAME:]
    if len(files) < N_SAME or any(time.time() - os.path.getmtime(f) > FRESH for f in files):
        return None
    calls = []
    for f in files:
        try:
            txt = open(f, encoding="utf-8", errors="ignore").read()
        except OSError:
            return None
        m = re.search(r'"name":\s*"([^"]+)",\s*"arguments":\s*"(.{0,300})', txt)
        if not m:
            return None
        calls.append(m.group(1) + m.group(2))
    if len(set(calls)) == 1:
        return f"{N_SAME} одинаковых вызовов подряд ({calls[0][:80]})"


def rule_exec_rate():
    logs = [p for p in glob.glob(AUI) if time.time() - os.path.getmtime(p) < WINDOW + 60]
    if not logs:
        return None
    path = max(logs, key=os.path.getmtime)
    with open(path, "rb") as f:
        f.seek(0, 2)
        f.seek(max(0, f.tell() - 400_000))
        data = f.read().decode("utf-8", "ignore")
    lt = time.localtime()
    now_s = lt.tm_hour * 3600 + lt.tm_min * 60 + lt.tm_sec
    n = 0
    for h, m, s in re.findall(r"\[(\d\d):(\d\d):(\d\d)\]\[[^\]]*\]\[tools::shell\][^\n]*?EXEC:", data):
        if (now_s - (int(h) * 3600 + int(m) * 60 + int(s))) % 86400 <= WINDOW:
            n += 1
    if n > MAX_EXEC:
        return f"{n} запусков shell за {WINDOW} с"


def main():
    reason = rule_same_calls() or rule_exec_rate()
    if not reason:
        return
    msg = f"{time.strftime('%F %T')} зацикливание: {reason}"
    try:
        with open(os.path.expanduser("~/kuni/watchdog.log"), "a") as lg:
            lg.write(msg + "\n")
    except OSError:
        pass
    if os.environ.get("WATCHDOG_DRY"):
        print("DRY:", msg)
    else:
        subprocess.run(["pkill", "-x", "kuni"])


if __name__ == "__main__":
    main()
