import contextlib
import io
import json
import os
import socket
import tempfile
import tomllib
import unittest
from pathlib import Path

from helpers import ROOT, Env
from test_admin import TOML
from zerocore import setup_tools as st
from zerocore.cli import main
from zerocore.kernel.errors import ZeroCoreError

CATALOG = "/home/marinka/zero_core_home/tools.json"


class WireKuniTests(unittest.TestCase):
    def setUp(self):
        self.dir = Path(tempfile.mkdtemp(prefix="zc_wire_"))
        self.cfg = self.dir / "config.toml"

    def write(self, text):
        self.cfg.write_text(text, encoding="utf-8")

    def read(self):
        return self.cfg.read_text(encoding="utf-8")

    def test_adds_the_key_to_an_existing_misc_section_and_keeps_everything_else(self):
        original = '# мой конфиг\n[general]\nlockdown = "none"  # комментарий\n\n[misc]\n# важный комментарий\nrandomly_go_sleep = false\nmax_shell_calls_per_turn = 30\n\n[capabilities]\nx = 1\n'
        self.write(original)
        self.assertEqual(st.wire_kuni_catalog(self.cfg, CATALOG), "added")
        text = self.read()
        parsed = tomllib.loads(text)
        self.assertEqual(parsed["misc"]["external_tools_catalog"], CATALOG)
        self.assertEqual(parsed["misc"]["randomly_go_sleep"], False)
        self.assertEqual(parsed["general"]["lockdown"], "none")
        self.assertEqual(parsed["capabilities"]["x"], 1)
        for keep in ("# мой конфиг", "# комментарий", "# важный комментарий"):
            self.assertIn(keep, text)
        # ключ вставлен внутри [misc], а не в чужой секции
        self.assertLess(text.index("[misc]"), text.index("external_tools_catalog"))
        self.assertLess(text.index("external_tools_catalog"), text.index("[capabilities]"))

    def test_updates_an_existing_value_and_is_idempotent(self):
        self.write('[misc]\nexternal_tools_catalog = ""\nother = 1\n')
        self.assertEqual(st.wire_kuni_catalog(self.cfg, CATALOG), "updated")
        self.assertEqual(tomllib.loads(self.read())["misc"]["external_tools_catalog"], CATALOG)
        self.assertEqual(st.wire_kuni_catalog(self.cfg, CATALOG), "unchanged")
        self.assertEqual(tomllib.loads(self.read())["misc"]["other"], 1)

    def test_a_commented_key_is_not_mistaken_for_the_real_one(self):
        self.write('[misc]\n# external_tools_catalog = "/old"\nother = 1\n')
        self.assertEqual(st.wire_kuni_catalog(self.cfg, CATALOG), "added")
        text = self.read()
        self.assertIn('# external_tools_catalog = "/old"', text)
        self.assertEqual(tomllib.loads(text)["misc"]["external_tools_catalog"], CATALOG)

    def test_creates_the_misc_section_when_missing(self):
        self.write('[general]\nlockdown = "none"\n')
        self.assertEqual(st.wire_kuni_catalog(self.cfg, CATALOG), "added")
        parsed = tomllib.loads(self.read())
        self.assertEqual(parsed["misc"]["external_tools_catalog"], CATALOG)
        self.assertEqual(parsed["general"]["lockdown"], "none")

    def test_same_key_in_another_section_is_left_alone(self):
        self.write('[other]\nexternal_tools_catalog = "/not/ours"\n[misc]\na = 1\n')
        st.wire_kuni_catalog(self.cfg, CATALOG)
        parsed = tomllib.loads(self.read())
        self.assertEqual(parsed["other"]["external_tools_catalog"], "/not/ours")
        self.assertEqual(parsed["misc"]["external_tools_catalog"], CATALOG)

    def test_backup_is_made_once_and_keeps_the_original(self):
        original = '[misc]\na = 1\n'
        self.write(original)
        st.wire_kuni_catalog(self.cfg, CATALOG)
        backup = self.dir / "config.toml.bak-zerocore"
        self.assertEqual(backup.read_text(encoding="utf-8"), original)
        st.wire_kuni_catalog(self.cfg, "/another/path/tools.json")   # второй раз копия не перезаписывается
        self.assertEqual(backup.read_text(encoding="utf-8"), original)

    def test_special_characters_in_the_path_are_escaped(self):
        self.write("[misc]\n")
        weird = 'C:\\dir\\"quoted"\\tools.json'
        st.wire_kuni_catalog(self.cfg, weird)
        self.assertEqual(tomllib.loads(self.read())["misc"]["external_tools_catalog"], weird)

    def test_crlf_files_keep_their_line_endings(self):
        self.cfg.write_bytes(b'[misc]\r\na = 1\r\n')
        st.wire_kuni_catalog(self.cfg, CATALOG)
        raw = self.cfg.read_bytes()
        self.assertIn(b"\r\n", raw)
        self.assertNotIn(b"\n", raw.replace(b"\r\n", b""))

    def test_errors_do_not_touch_the_file(self):
        with self.assertRaises(ZeroCoreError):
            st.wire_kuni_catalog(self.dir / "missing.toml", CATALOG)
        self.write('[misc\nbroken = ')   # уже некорректный TOML: правка не должна его «чинить» вслепую
        before = self.read()
        with self.assertRaises(ZeroCoreError):
            st.wire_kuni_catalog(self.cfg, CATALOG)
        self.assertEqual(self.read(), before)
        self.assertFalse((self.dir / "config.toml.bak-zerocore").exists())

    def test_wired_catalog_reads_the_value_back(self):
        self.write("[misc]\n")
        self.assertIsNone(st.wired_catalog(self.cfg))
        st.wire_kuni_catalog(self.cfg, CATALOG)
        self.assertEqual(st.wired_catalog(self.cfg), CATALOG)
        self.assertIsNone(st.wired_catalog(self.dir / "nope.toml"))


class HelpersTests(unittest.TestCase):
    def test_detect_kuni_dir(self):
        empty = Path(tempfile.mkdtemp(prefix="zc_k0_"))
        self.assertIsNone(st.detect_kuni_dir(str(empty)), "каталог без config.toml и бинарника не подходит")
        self.assertIsNone(st.detect_kuni_dir("/nonexistent-kuni-dir"), "явный неверный путь не подменяется другим")
        d = Path(tempfile.mkdtemp(prefix="zc_k_"))
        (d / "config.toml").write_text("")
        self.assertEqual(st.detect_kuni_dir(str(d)), d)
        d2 = Path(tempfile.mkdtemp(prefix="zc_k2_"))
        (d2 / "kuni").write_text("")
        self.assertEqual(st.detect_kuni_dir(str(d2)), d2)
        os.environ["ZEROCORE_KUNI_DIR"] = str(d)
        try:
            self.assertEqual(st.detect_kuni_dir(None), d)
            self.assertIsNone(st.detect_kuni_dir("/nonexistent-kuni-dir"), "переменная окружения не перекрывает явный путь")
        finally:
            del os.environ["ZEROCORE_KUNI_DIR"]

    def test_lan_ips_are_plain_ipv4_without_loopback(self):
        for ip in st.lan_ips():
            self.assertRegex(ip, r"^\d+\.\d+\.\d+\.\d+$")
            self.assertFalse(ip.startswith("127."))

    def test_port_free(self):
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            s.listen(1)
            port = s.getsockname()[1]
            self.assertFalse(st.port_free("127.0.0.1", port))
        self.assertTrue(st.port_free("127.0.0.1", port))

    def test_tmux_command_quotes_paths(self):
        cmd = st.tmux_command("/home/my user/zc home", "192.168.0.5", 8767, python="/usr/bin/python3", script="/opt/zc dir/zerocore.py")
        self.assertEqual(cmd[:5], ["tmux", "new-session", "-d", "-s", st.TMUX_SESSION])
        inner = cmd[5]
        self.assertIn("'/home/my user/zc home'", inner)
        self.assertIn("'/opt/zc dir/zerocore.py'", inner)
        self.assertIn("--host 192.168.0.5 --port 8767", inner)


class CliTests(Env):
    def setUp(self):
        super().setUp()
        self.kdir = self.tmp / "kuni"
        (self.kdir / "logs").mkdir(parents=True)
        (self.kdir / "config.toml").write_text(TOML + "\n[misc]\nrandomly_go_sleep = false\n")
        (self.kdir / "logs" / "2026-10-09 10:00:00.1.0query.json").write_text("{}")
        self.home = str(self.tmp / "cli_home")

    def run_cli(self, *argv):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            code = main(["--home", self.home, *argv])
        return code, buf.getvalue()

    def test_up_prepares_everything_and_is_idempotent(self):
        code, out = self.run_cli("up", "--kuni-dir", str(self.kdir), "--demo", "--wire-kuni", "--no-panel", "--host", "127.0.0.1")
        self.assertEqual(code, 0, out)
        self.assertIn("http://127.0.0.1:8767/", out)
        self.assertIn("Токен", out)
        token = (Path(self.home) / "panel_token").read_text().strip()
        self.assertIn(token, out)
        from zerocore.module_manager.manager import Manager
        m = Manager(self.home)
        enabled = set(m.enabled_names())
        self.assertTrue({"kuni", "watchdog", "world_v2", "demo_counter", "demo_tools"} <= enabled, enabled)
        self.assertEqual(m.config("kuni")["kuni_dir"], str(self.kdir))
        catalog = json.loads(m.tools_path().read_text())
        self.assertEqual(sorted(t["name"] for t in catalog["tools"]), ["demo_add", "demo_echo"])
        cfg = tomllib.loads((self.kdir / "config.toml").read_text())
        self.assertEqual(cfg["misc"]["external_tools_catalog"], str(m.tools_path()))
        self.assertEqual(cfg["misc"]["randomly_go_sleep"], False)
        code2, out2 = self.run_cli("up", "--kuni-dir", str(self.kdir), "--demo", "--wire-kuni", "--no-panel", "--host", "127.0.0.1")
        self.assertEqual(code2, 0, out2)
        self.assertIn("unchanged", out2)
        self.assertNotIn("установлен ", out2)

    def test_up_can_preset_the_black_theme(self):
        code, out = self.run_cli("up", "--kuni-dir", str(self.kdir), "--theme", "black", "--no-panel", "--host", "127.0.0.1")
        self.assertEqual(code, 0, out)
        from zerocore.admin.settings import AdminState
        self.assertEqual(AdminState(self.home).get()["theme"], "black")
        self.assertIn("тема панели: black", out)

    def test_up_without_a_kuni_dir_warns_but_works(self):
        code, out = self.run_cli("up", "--no-panel", "--host", "127.0.0.1", "--kuni-dir", "/nonexistent")
        self.assertEqual(code, 0, out)
        self.assertIn("каталог бота не найден", out)

    def test_wire_flag_without_kuni_is_an_error(self):
        code, out = self.run_cli("up", "--no-panel", "--wire-kuni", "--kuni-dir", "/nonexistent")
        self.assertEqual(code, 1)
        self.assertIn("Ошибка", out)

    def test_wire_kuni_command(self):
        self.run_cli("up", "--kuni-dir", str(self.kdir), "--no-panel", "--host", "127.0.0.1")
        code, out = self.run_cli("wire-kuni", "--kuni-dir", str(self.kdir))
        self.assertEqual(code, 0, out)
        self.assertIn("added", out)
        code, out = self.run_cli("wire-kuni", "--kuni-dir", str(self.kdir))
        self.assertIn("unchanged", out)

    def test_doctor_reports_and_gives_an_exit_code(self):
        self.run_cli("up", "--kuni-dir", str(self.kdir), "--no-panel", "--host", "127.0.0.1")
        code, out = self.run_cli("doctor", "--kuni-dir", str(self.kdir))
        self.assertEqual(code, 0, out)
        self.assertIn("✓ Python 3.11+", out)
        self.assertIn("✓ config.toml бота читается", out)
        self.assertIn("openrouter", out)
        self.assertNotIn(SECRET_MARK, out)
        self.assertIn("! каталог инструментов подключён к боту", out)   # пока не подключён
        self.assertIn("что делать: python3 zerocore.py wire-kuni", out)
        self.run_cli("wire-kuni", "--kuni-dir", str(self.kdir))
        code, out = self.run_cli("doctor", "--kuni-dir", str(self.kdir))
        self.assertIn("✓ каталог инструментов подключён к боту", out)
        self.assertIn("итог: ошибок 0", out)

    def test_doctor_fails_without_a_kuni_dir(self):
        self.run_cli("up", "--no-panel", "--host", "127.0.0.1", "--kuni-dir", "/nonexistent")
        code, out = self.run_cli("doctor", "--kuni-dir", "/nonexistent")
        self.assertEqual(code, 1)
        self.assertIn("✗ каталог бота kuni", out)
        self.assertIn("--kuni-dir", out)

    def test_doctor_detects_broken_kuni_config(self):
        self.run_cli("up", "--kuni-dir", str(self.kdir), "--no-panel", "--host", "127.0.0.1")
        (self.kdir / "config.toml").write_text("[broken")
        code, out = self.run_cli("doctor", "--kuni-dir", str(self.kdir))
        self.assertEqual(code, 1)
        self.assertIn("✗ config.toml бота читается", out)


SECRET_MARK = "SECRET-DO-NOT-LEAK"

if __name__ == "__main__":
    unittest.main()
