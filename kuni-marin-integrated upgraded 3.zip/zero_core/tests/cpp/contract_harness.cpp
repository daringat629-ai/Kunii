// Тестовая программа: читает tools.json так же, как ядро kuni (util/external_tools.*), и выполняет один вызов инструмента.
//   contract_harness <tools.json> --list
//   contract_harness <tools.json> <имя_инструмента> '<json аргументов>'
#include "util/external_tools.h"

#include <fstream>
#include <iostream>
#include <sstream>

int main(int argc, char** argv) {
    if (argc < 3) {
        return 64;
    }
    std::ifstream in(argv[1], std::ios::binary);
    std::stringstream buffer;
    buffer << in.rdbuf();
    const auto catalog = util::external::parseCatalog(buffer.str());
    for (const auto& e : catalog.errors) {
        std::cerr << "CATALOG-ERROR: " << e << "\n";
    }
    if (std::string(argv[2]) == "--list") {
        for (const auto& t : catalog.tools) {
            std::cout << t.name << "\n";
        }
        return catalog.errors.empty() ? 0 : 2;
    }
    const util::external::Tool* tool = nullptr;
    for (const auto& t : catalog.tools) {
        if (t.name == argv[2]) {
            tool = &t;
        }
    }
    if (tool == nullptr) {
        std::cerr << "NO-SUCH-TOOL\n";
        return 3;
    }
    const auto prepared = util::external::prepareCall(*tool, argc > 3 ? argv[3] : "");
    if (!prepared.ok) {
        std::cout << prepared.error;
        return 0;
    }
    const auto result = util::process::run(util::external::makeOptions(*tool, prepared.stdinPayload));
    std::cout << util::external::formatToolResult(result);
    return 0;
}
