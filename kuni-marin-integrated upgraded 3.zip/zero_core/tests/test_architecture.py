import json
import sys
import unittest

from helpers import ROOT, Env
from test_admin import PanelBase, TOML, SECRET
from zerocore.admin import architecture
from zerocore.admin.server import AdminApp

ALL = ("kuni", "watchdog", "webview", "world_v2", "demo_counter", "demo_tools")


def overlap(a, b):
    return a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"] and a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]


class ArchitectureGraphTests(Env):
    def setUp(self):
        super().setUp()
        for m in ALL:
            self.mgr.install(ROOT / "modules" / m)

    def graph(self, toml=None):
        return architecture.build(self.mgr, toml)

    def node(self, g, nid):
        return next(n for n in g["nodes"] if n["id"] == nid)

    def test_structure_is_consistent(self):
        g = self.graph()
        ids = [n["id"] for n in g["nodes"]]
        self.assertEqual(len(ids), len(set(ids)), "уникальные id")
        for e in g["edges"]:
            self.assertIn(e["a"], ids)
            self.assertIn(e["b"], ids)
            self.assertNotEqual(e["a"], e["b"])
            self.assertTrue(e["label"] and e["kind"])
        pairs = [(e["a"], e["b"], e["label"]) for e in g["edges"]]
        self.assertEqual(len(pairs), len(set(pairs)), "нет повторов связей")
        for n in g["nodes"]:
            self.assertTrue(n["title"] and n["group"] and n["status"] in ("ok", "idle", "warn", "bad", "off"))
            p = n["pos"]
            self.assertTrue(0 <= p["x"] and p["x"] + p["w"] <= 24 and p["y"] >= 0, n["id"])

    def test_nodes_do_not_overlap_on_the_grid(self):
        g = self.graph()
        for i, a in enumerate(g["nodes"]):
            for b in g["nodes"][i + 1:]:
                self.assertFalse(overlap(a["pos"], b["pos"]), f"{a['id']} и {b['id']} пересекаются")

    def test_every_installed_module_is_a_node_and_kuni_is_in_the_centre(self):
        g = self.graph()
        mods = {n["module"]: n for n in g["nodes"] if n["group"] == "module"}
        self.assertEqual(set(mods), set(ALL))
        self.assertEqual((mods["kuni"]["pos"]["x"], mods["kuni"]["pos"]["y"]), (10, 10))
        for e in g["edges"]:
            if e["kind"] == "manage":
                self.assertEqual(e["a"], "manager")
        self.assertEqual(len([e for e in g["edges"] if e["kind"] == "manage"]), len(ALL))

    def test_the_six_module_layout_uses_a_second_row_without_collisions(self):
        g = self.graph()
        ys = sorted({n["pos"]["y"] for n in g["nodes"] if n["group"] == "module"})
        self.assertEqual(ys, [10, 15])
        kernel_y = min(n["pos"]["y"] for n in g["nodes"] if n["group"] in ("kernel", "manager"))
        self.assertEqual(kernel_y, 20)   # ядро ниже второго ряда модулей

    def test_many_modules_push_the_kernel_down_and_still_do_not_overlap(self):
        from helpers import make_module
        for i in range(7):
            self.mgr.install(make_module(self.src, f"extra{i}", kind="library"))
        g = self.graph()
        self.assertEqual(len([n for n in g["nodes"] if n["group"] == "module"]), len(ALL) + 7)
        for i, a in enumerate(g["nodes"]):
            for b in g["nodes"][i + 1:]:
                self.assertFalse(overlap(a["pos"], b["pos"]), f"{a['id']} и {b['id']}")

    def test_disabled_modules_are_off_and_their_threads_are_marked(self):
        g = self.graph()
        for n in g["nodes"]:
            if n["group"] == "module":
                self.assertEqual(n["status"], "off", n["id"])
        self.assertTrue(all(e["off"] for e in g["edges"] if e["kind"] == "manage"))
        self.mgr.enable("demo_tools")
        g = self.graph()
        self.assertNotEqual(self.node(g, "mod_demo_tools")["status"], "off")
        manage = next(e for e in g["edges"] if e["kind"] == "manage" and e["b"] == "mod_demo_tools")
        self.assertFalse(manage["off"])

    def test_dependency_tools_and_widget_edges_follow_the_real_manifests(self):
        for m in ("kuni", "watchdog", "world_v2", "demo_counter", "demo_tools"):
            self.mgr.enable(m)
        g = self.graph()
        triples = {(e["a"], e["b"], e["label"], e["kind"]) for e in g["edges"]}
        self.assertIn(("mod_watchdog", "mod_kuni", "telegram.bot", "dep"), triples)            # watchdog требует telegram.bot от kuni
        self.assertIn(("mod_demo_tools", "catalog", "инструменты", "tools"), triples)
        self.assertIn(("mod_demo_counter", "panel", "виджеты", "widgets"), triples)
        self.assertIn(("mod_watchdog", "panel", "виджеты", "widgets"), triples)               # у watchdog есть виджет
        self.assertIn(("mod_webview", "mod_world_v2", "world.state", "dep"), triples)         # webview выключен, связь есть, но «off»
        webview_dep = next(e for e in g["edges"] if e["a"] == "mod_webview" and e["kind"] == "dep")
        self.assertTrue(webview_dep["off"])

    def test_tools_and_widgets_edges_disappear_with_the_module(self):
        self.mgr.enable("demo_tools")
        self.assertTrue(any(e["kind"] == "tools" and e["a"] == "mod_demo_tools" for e in self.graph()["edges"]))
        self.mgr.disable("demo_tools")
        self.assertFalse(any(e["kind"] == "tools" and e["a"] == "mod_demo_tools" for e in self.graph()["edges"]))

    def test_dynamic_values_in_kernel_nodes(self):
        self.mgr.enable("demo_tools")
        self.mgr.enable("world_v2")
        g = self.graph()
        self.assertIn(f"установлено: {len(ALL)}", self.node(g, "manager")["lines"][0])
        self.assertIn("включено: 2", self.node(g, "state")["lines"][0])
        self.assertIn("инструментов: 2", self.node(g, "catalog")["lines"][0])
        self.assertIn("возможностей: 2", self.node(g, "registry")["lines"][0])
        self.assertEqual(self.node(g, "solver")["status"], "ok")
        self.assertIn("ОК", self.node(g, "solver")["lines"][0])

    def test_integrity_problem_turns_the_solver_red(self):
        self.inst("prov", kind="library", provides=["x.cap"])
        self.inst("cons", kind="library", requires=["x.cap"])
        self.mgr.enable("prov")
        self.mgr.enable("cons")
        self.assertEqual(self.node(self.graph(), "solver")["status"], "ok")
        st = self.mgr.store.load()   # ломаем реестр: провайдер возможности выключен, потребитель остался включённым
        st["modules"]["prov"]["enabled"] = False
        self.mgr.store.save(st)
        g = self.graph()
        self.assertEqual(self.node(g, "solver")["status"], "bad")
        self.assertNotIn("ОК", self.node(g, "solver")["lines"][0])

    def test_kuni_internals_and_external_systems(self):
        g = self.graph()
        for nid in ("telegram", "llm", "k_telegram", "k_memory", "k_cognition", "k_tools", "k_media"):
            self.assertIn(nid, [n["id"] for n in g["nodes"]])
        self.assertTrue(all(self.node(g, n)["status"] == "off" for n in ("telegram", "k_cognition")))   # kuni не включён
        self.assertEqual(self.node(g, "llm")["status"], "warn")                                         # нет конфигурации
        pairs = {(e["a"], e["b"]) for e in g["edges"]}
        self.assertIn(("llm", "k_cognition"), pairs)
        self.assertIn(("mod_kuni", "k_cognition"), pairs)
        self.assertIn(("k_tools", "catalog"), pairs)


class ArchitectureApiTests(PanelBase):
    def test_endpoint_requires_a_token_and_returns_the_graph(self):
        self.assertEqual(self.get("/api/architecture", token=None)[0], 401)
        code, g = self.get("/api/architecture")
        self.assertEqual(code, 200)
        self.assertTrue(g["nodes"] and g["edges"])
        self.assertIn("mod_kuni", [n["id"] for n in g["nodes"]])

    def test_llm_node_shows_provider_and_model_but_never_secrets(self):
        g = self.get("/api/architecture")[1]
        llm = next(n for n in g["nodes"] if n["id"] == "llm")
        text = json.dumps(llm, ensure_ascii=False)
        self.assertIn("openrouter", text)
        self.assertIn("deepseek/deepseek-v4-flash", text)
        for leaked in (SECRET, "SECRET", "pa55", "user:", "key=abc"):
            self.assertNotIn(leaked, text)
        self.assertEqual(llm["status"], "ok")

    def test_view_setting_is_validated_and_persisted(self):
        self.assertEqual(self.get("/api/settings")[1]["view"], "panel")
        self.assertEqual(self.post("/api/settings", {"view": "arch"})[1]["view"], "arch")
        self.assertEqual(self.post("/api/settings", {"view": "3d"})[0], 400)
        self.assertEqual(self.get("/api/settings")[1]["view"], "arch")


if __name__ == "__main__":
    unittest.main()
