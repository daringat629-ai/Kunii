import http.client
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request

from helpers import ROOT, Env, make_module
from zerocore.admin import providers, widgets
from zerocore.admin.server import AdminApp, make_server
from zerocore.admin.settings import AdminState, sanitize_layout
from zerocore.kernel.contracts import validate_manifest
from zerocore.kernel.errors import ZeroCoreError

SECRET = "sk-or-v1-SECRET-DO-NOT-LEAK"
TOML = f"""
[general]
papik_chat_id = 1
lockdown = "papik_only"
[general.llm]
model = "deepseek/deepseek-v4-flash"
endpoint.baseUrl = "https://user:pa55@openrouter.ai/api/v1/?key=abc"
endpoint.bearerKey = "{SECRET}"
[general.embedding]
model = "qwen3-embedding"
endpoint.baseUrl = "http://localhost:11434/v1/"
endpoint.bearerKey = ""
"""
COUNTER = """
import json, os, sys
from pathlib import Path
d = Path(os.environ["ZEROCORE_DATA_DIR"]); d.mkdir(parents=True, exist_ok=True); f = d / "c.txt"
def read():
    try: return int(f.read_text())
    except Exception: return 0
if sys.argv[1] == "add": n = read() + int(sys.argv[2]); f.write_text(str(n)); print("+%s -> %d" % (sys.argv[2], n))
else: print(json.dumps({"value": read(), "label": "clicks"}))
"""
PY = sys.executable


def pyc(code):
    return [PY, "-c", code]


class PanelBase(Env):
    def setUp(self):
        super().setUp()
        self.kdir = self.tmp / "kuni"
        (self.kdir / "logs").mkdir(parents=True)
        (self.kdir / "config.toml").write_text(TOML)
        self.console = self.tmp / "aui.1.log"
        self.console.write_text("")
        self.inst("kuni", kind="library", provides=["telegram.bot"],
                  config_extra={"kuni_dir": str(self.kdir), "console_log_glob": str(self.tmp / "aui.*.log")})
        self.mgr.enable("kuni")
        self.app = AdminApp(self.mgr, widget_timeout=1.5)
        self.srv = make_server(self.mgr, "127.0.0.1", 0, token="secret", app=self.app)
        self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def tearDown(self):
        self.srv.shutdown()
        self.srv.server_close()
        super().tearDown()

    def call(self, method, path, body=None, token="secret", raw=False):
        headers = {"X-Token": token} if token is not None else {}
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", data=data, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=15) as r:
                payload = r.read()
                return r.status, (payload if raw else json.loads(payload)), r.headers
        except urllib.error.HTTPError as e:
            payload = e.read()
            return e.code, (payload if raw else json.loads(payload or b"{}")), e.headers

    def get(self, path, **kw):
        return self.call("GET", path, **kw)[:2]

    def post(self, path, body=None, **kw):
        return self.call("POST", path, {} if body is None else body, **kw)[:2]


class SecurityAndStaticTests(PanelBase):
    def test_api_requires_token(self):
        self.assertEqual(self.get("/api/system", token=None)[0], 401)
        self.assertEqual(self.get("/api/system", token="wrong")[0], 401)
        self.assertEqual(self.post("/api/settings", {"theme": "light"}, token="wrong")[0], 401)
        self.assertEqual(self.post("/api/modules/kuni/stop", token=None)[0], 401)
        self.assertEqual(self.get("/api/system")[0], 200)

    def test_static_assets_open_with_security_headers(self):
        code, body, h = self.call("GET", "/", token=None, raw=True)
        self.assertEqual(code, 200)
        self.assertIn(b"<title>", body)
        self.assertIn("default-src 'self'", h["Content-Security-Policy"])
        self.assertEqual(h["X-Content-Type-Options"], "nosniff")
        for path in ("/app.js", "/layout.js", "/style.css"):
            self.assertEqual(self.call("GET", path, token=None, raw=True)[0], 200, path)

    def test_no_path_traversal_and_only_whitelisted_files(self):
        for path in ("/../../etc/passwd", "/%2e%2e/%2e%2e/etc/passwd", "/app.py", "/web/app.js", "/panel_token"):
            conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
            conn.request("GET", path)
            r = conn.getresponse()
            body = r.read()
            self.assertEqual(r.status, 404, path)
            self.assertNotIn(b"root:", body)
            conn.close()

    def test_bad_requests(self):
        self.assertEqual(self.get("/api/zzz")[0], 404)
        self.assertEqual(self.post("/nope")[0], 404)
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("POST", "/api/settings", body=b"not json", headers={"X-Token": "secret", "Content-Length": "8"})
        self.assertEqual(conn.getresponse().status, 400)
        conn.close()
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        conn.request("POST", "/api/settings", headers={"X-Token": "secret", "Content-Length": "999999"})
        self.assertEqual(conn.getresponse().status, 413)
        conn.close()

    def test_handler_exception_gives_500_and_server_survives(self):
        original = self.app.handle
        self.app.handle = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom"))
        code, body = self.get("/api/system")
        self.assertEqual(code, 500)
        self.assertNotIn("boom", json.dumps(body))   # internals are not leaked
        self.app.handle = original
        self.assertEqual(self.get("/api/system")[0], 200)


class DataEndpointTests(PanelBase):
    def test_system(self):
        code, d = self.get("/api/system")
        self.assertEqual(code, 200)
        self.assertEqual(d["pid"], os.getpid())
        self.assertEqual(d["enabled"], 1)
        self.assertEqual(d["integrity"], [])
        self.assertIn("load1", d["host"])

    def test_transports_lists_telegram_modules_only(self):
        self.inst("other", kind="library", provides=["demo.thing"])
        self.mgr.enable("other")
        code, d = self.get("/api/transports")
        self.assertEqual([x["name"] for x in d], ["kuni"])
        self.assertEqual(d[0]["capability"], "telegram.bot")

    def test_llm_never_leaks_secrets(self):
        code, d = self.get("/api/llm")
        text = json.dumps(d)
        self.assertEqual(d["provider"], "openrouter")
        self.assertEqual(d["model"], "deepseek/deepseek-v4-flash")
        self.assertEqual(d["host"], "https://openrouter.ai")
        self.assertEqual(d["embedding_model"], "qwen3-embedding")
        for leaked in (SECRET, "SECRET", "pa55", "user:", "key=abc", "bearerKey"):
            self.assertNotIn(leaked, text)

    def test_llm_missing_config(self):
        (self.kdir / "config.toml").unlink()
        d = self.get("/api/llm")[1]
        self.assertFalse(d["available"])

    def test_provider_guess(self):
        self.assertEqual(providers._provider("http://localhost:11434"), "ollama")
        self.assertEqual(providers._provider("https://api.openai.com"), "openai")
        self.assertEqual(providers._provider("https://llm.example.org"), "llm.example.org")
        self.assertEqual(providers._host_only("not a url"), "")

    def test_stats_from_logs(self):
        today = time.strftime("%Y-%m-%d")
        for i in range(3):
            (self.kdir / "logs" / f"{today} 12:00:0{i}.1response.json").write_text("{}")
        (self.kdir / "logs" / "2020-01-01 00:00:00.1response.json").write_text("{}")
        self.console.write_text(
            "[22:25:23][UI thread][tools::shell][WARN]: EXEC: date\n"
            "[22:25:25][UI thread][tools::shell][WARN]: EXEC: ls\n"
            "[22:25:24][UI thread][send_telegram_message][INFO]: Synthetic typing delay: 1200ms\n"
            "[22:25:30][UI thread][tools::external][INFO]: CALL demo/demo_echo\n"
            "[22:25:31][UI thread][tools::external][INFO]: CALL demo/demo_add\n"
            "[22:26:00][UI thread][OpenAITools][WARN]: tool call refused: Refused: x\n"
            "[22:47:03][UI thread][OpenAIChat][WARN]: chatStreaming: status=HTTP_400_BAD_REQUEST\n"
            "[22:47:04][UI thread][App][ERROR]: broken\n")
        d = self.get("/api/stats")[1]
        self.assertEqual(d["llm_requests_today"], 3)
        self.assertEqual((d["shell_commands"], d["messages_sent"], d["guard_refusals"], d["llm_http_errors"], d["errors"],
                          d["external_calls"]), (2, 1, 1, 1, 1, 2))

    def test_tools_are_taken_from_the_latest_query_with_tools(self):
        logs = self.kdir / "logs"
        (logs / "2026-10-01 10:00:00.1.0query.json").write_text(json.dumps({"tools": [
            {"type": "function", "function": {"name": "old_tool", "description": "x"}}]}))
        (logs / "2026-10-02 10:00:00.1.0query.json").write_text(json.dumps({"tools": [
            {"type": "function", "function": {"name": "shell", "description": "Runs bash"}},
            {"type": "function", "function": {"name": "ask", "description": "memory"}}]}))
        (logs / "2026-10-03 10:00:00.1.0query.json").write_text(json.dumps({"input": "embedding only"}))
        (logs / "2026-10-04 10:00:00.1.0query.json").write_text("{broken json")
        d = self.get("/api/tools")[1]
        self.assertEqual([t["name"] for t in d], ["ask", "shell"])
        self.assertEqual(d[1]["description"], "Runs bash")

    def test_generation_state(self):
        logs = self.kdir / "logs"
        now = time.time()
        q1, r1 = logs / "2026-10-09 10:00:00.1.0query.json", logs / "2026-10-09 10:00:00.1.1response.json"
        q1.write_text("{}")
        r1.write_text("{}")
        os.utime(q1, (now - 10, now - 10))
        os.utime(r1, (now - 6, now - 6))
        d = self.get("/api/generation")[1]
        self.assertTrue(d["known"])
        self.assertFalse(d["active"])
        self.assertAlmostEqual(d["last_seconds"], 4.0, delta=0.2)
        q2 = logs / "2026-10-09 10:00:30.1.0query.json"
        q2.write_text("{}")
        d = self.get("/api/generation")[1]
        self.assertTrue(d["active"])
        old = now - 3600
        os.utime(q2, (old, old))   # a stale query is not an active generation
        self.assertFalse(self.get("/api/generation")[1]["active"])

    def test_log_merges_events_and_console_and_drops_noise(self):
        self.console.write_text(
            "[10:00:00][UI thread][tools::shell][WARN]: EXEC: date\n"
            "[10:00:01][UI thread][Performance][WARN]: Execution of a task took 2000us\n"
            " - ...\n"
            "\x1b[90m[10:00:02][UI thread][App][INFO]: hello\x1b[0m\n")
        rows = self.get("/api/log?n=100")[1]
        texts = [r["text"] for r in rows]
        self.assertTrue(any("EXEC: date" in t for t in texts))
        self.assertTrue(any("hello" in t for t in texts))
        self.assertFalse(any("Performance" in t or t.strip() == "- ..." or "\x1b" in t for t in texts))
        self.assertIn("core", {r["src"] for r in rows})   # менеджер уже публиковал события
        self.assertEqual(self.get("/api/log?n=abc")[0], 200)

    def test_console_timestamp_belongs_to_yesterday_if_it_would_be_in_the_future(self):
        lt = time.localtime()
        now = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 12, 0, 10, 0, 0, -1))
        ts = providers.parse_console_ts("[23:59:59][x]", now)
        self.assertLess(ts, now)
        self.assertAlmostEqual(now - ts, 12 * 3600 + 10 + 1, delta=2 + 3600)   # допуск на переход времени
        self.assertIsNone(providers.parse_console_ts("no timestamp", now))

    def test_metrics_ring_buffer(self):
        s = providers.MetricsSampler(size=5)
        for _ in range(12):
            s.sample_once()
        pts = s.points()
        self.assertEqual(len(pts), 5)
        self.assertTrue(all({"t", "load1", "mem", "rss"} <= set(p) for p in pts))
        for _ in range(3):
            self.app.sampler.sample_once()
        self.assertEqual(len(self.get("/api/metrics")[1]), 3)


class ModulesApiTests(PanelBase):
    def test_enable_start_stop_restart_disable(self):
        self.inst("svc", provides=["x.svc"])
        self.assertFalse(self.get("/api/modules")[1][1]["enabled"])
        self.assertEqual(self.post("/api/modules/svc/enable")[0], 200)
        self.assertTrue(self.mgr.is_running("svc"))
        self.assertEqual(self.post("/api/modules/svc/stop")[0], 200)
        self.assertFalse(self.mgr.is_running("svc"))
        self.assertEqual(self.post("/api/modules/svc/start")[0], 200)
        pid = self.mgr.runner.pid("svc")
        self.assertEqual(self.post("/api/modules/svc/restart")[0], 200)
        self.assertNotEqual(self.mgr.runner.pid("svc"), pid)
        self.assertEqual(self.post("/api/modules/svc/disable")[0], 200)
        self.assertFalse(self.mgr.is_running("svc"))

    def test_errors_are_reported_not_raised(self):
        self.inst("xx", kind="library", provides=["x.cap"])
        self.inst("yy", kind="library", requires=["x.cap"])
        self.mgr.enable("xx")
        self.mgr.enable("yy")
        code, d = self.post("/api/modules/xx/disable")
        self.assertEqual(code, 400)
        self.assertIn("зависят", d["error"])
        code, d = self.post("/api/modules/xx/disable", {"cascade": True})
        self.assertEqual(code, 200)
        self.assertEqual(self.mgr.enabled_names(), ["kuni"])

    def test_crashing_module_does_not_break_the_panel(self):
        self.inst("bad", mode="crash", health="process")
        code, d = self.post("/api/modules/bad/enable")
        self.assertEqual(code, 400)
        self.assertIn("bad", d["error"])
        self.assertEqual(self.get("/api/system")[0], 200)

    def test_unknown_module_and_action(self):
        self.assertEqual(self.post("/api/modules/ghost/start")[0], 404)
        self.assertEqual(self.post("/api/modules/kuni/format_disk")[0], 404)

    def test_widgets_listed_only_for_enabled_modules(self):
        w = [{"id": "a", "title": "A", "kind": "text", "command": pyc("print(1)"), "size": {"w": 5, "h": 4}}]
        self.inst("plug", kind="library", widgets=w)
        rows = {r["name"]: r for r in self.get("/api/modules")[1]}
        self.assertEqual(rows["plug"]["widgets"], [])
        self.mgr.enable("plug")
        rows = {r["name"]: r for r in self.get("/api/modules")[1]}
        self.assertEqual(rows["plug"]["widgets"][0]["id"], "a")
        self.assertEqual(rows["plug"]["widgets"][0]["size"], {"w": 5, "h": 4})


class WidgetTests(PanelBase):
    def setUp(self):
        super().setUp()
        W = [
            {"id": "kvw", "title": "KV", "kind": "kv", "command": pyc("import json;print(json.dumps({'items':[['a','1'],['b','2']]}))")},
            {"id": "tab", "title": "T", "kind": "table", "command": pyc("import json;print(json.dumps({'columns':['x','y'],'rows':[[1,2],[3,4]]}))")},
            {"id": "txt", "title": "Tx", "kind": "text", "command": pyc("import json;print(json.dumps({'text':'привет'}))")},
            {"id": "cnt", "title": "C", "kind": "counter", "command": [PY, "${module_dir}/counter.py", "show"],
             "actions": [{"id": "plus", "label": "+10", "command": [PY, "${module_dir}/counter.py", "add", "10"]}]},
            {"id": "plain", "title": "P", "kind": "kv", "command": pyc("import json;print(json.dumps({'items':[]}))")},
            {"id": "notjson", "title": "N", "kind": "text", "command": pyc("print('hello')")},
            {"id": "shape", "title": "S", "kind": "table", "command": pyc("import json;print(json.dumps({'columns':['a'],'rows':[[1,2]]}))")},
            {"id": "fail", "title": "F", "kind": "text", "command": pyc("import sys;sys.stderr.write('oops');sys.exit(3)")},
            {"id": "slow", "title": "Sl", "kind": "text", "command": pyc("import time;time.sleep(10)")},
            {"id": "huge", "title": "H", "kind": "text", "command": pyc("print('x'*70000)")},
            {"id": "missing", "title": "M", "kind": "text", "command": ["/нет/такого/файла"]},
        ]
        self.inst("plug", kind="library", widgets=W, files={"counter.py": COUNTER})
        self.mgr.enable("plug")

    def w(self, wid):
        return self.get(f"/api/widget/plug/{wid}")[1]

    def test_all_kinds_render(self):
        self.assertEqual(self.w("kvw")["data"]["items"], [["a", "1"], ["b", "2"]])
        self.assertEqual(self.w("tab")["data"]["rows"], [[1, 2], [3, 4]])
        self.assertEqual(self.w("txt")["data"]["text"], "привет")
        c = self.w("cnt")
        self.assertEqual((c["ok"], c["kind"], c["data"]["value"]), (True, "counter", 0))
        self.assertEqual(c["actions"], [{"id": "plus", "label": "+10"}])

    def test_bad_providers_report_errors_without_breaking(self):
        self.assertIn("не JSON", self.w("notjson")["error"])
        self.assertIn("равной длиной", self.w("shape")["error"])
        self.assertIn("кодом 3", self.w("fail")["error"])
        self.assertIn("oops", self.w("fail")["error"])
        self.assertIn("больше", self.w("huge")["error"])
        self.assertIn("не удалось запустить", self.w("missing")["error"])
        for wid in ("notjson", "shape", "fail", "huge", "missing"):
            self.assertFalse(self.w(wid)["ok"])
        self.assertTrue(self.w("kvw")["ok"])

    def test_timeout(self):
        t0 = time.time()
        d = self.w("slow")
        self.assertFalse(d["ok"])
        self.assertIn("таймаут", d["error"])
        self.assertLess(time.time() - t0, 8)

    def test_action_runs_declared_command_and_refreshes(self):
        code, d = self.post("/api/widget/plug/cnt/action/plus")
        self.assertEqual(code, 200)
        self.assertEqual(d["data"]["value"], 10)
        self.assertEqual(d["note"], "+10 -> 10")
        self.assertEqual(self.post("/api/widget/plug/cnt/action/plus")[1]["data"]["value"], 20)
        self.assertEqual(self.w("cnt")["data"]["value"], 20)

    def test_only_declared_actions_and_enabled_modules(self):
        self.assertEqual(self.post("/api/widget/plug/cnt/action/rm_rf")[0], 404)
        self.assertEqual(self.post("/api/widget/plug/plain/action/plus")[0], 404)
        self.assertEqual(self.get("/api/widget/plug/nothing")[0], 404)
        self.assertEqual(self.get("/api/widget/ghost/cnt")[0], 404)
        self.mgr.disable("plug")
        self.assertEqual(self.get("/api/widget/plug/cnt")[0], 404)

    def test_shipped_demo_counter_works_end_to_end(self):
        self.mgr.install(ROOT / "modules" / "demo_counter")
        self.mgr.enable("demo_counter")
        self.assertEqual(self.get("/api/widget/demo_counter/counter")[1]["data"]["value"], 0)
        self.assertEqual(self.post("/api/widget/demo_counter/counter/action/plus10")[1]["data"]["value"], 10)
        self.assertEqual(self.post("/api/widget/demo_counter/counter/action/reset")[1]["data"]["value"], 0)

    def test_shipped_watchdog_widget(self):
        self.mgr.install(ROOT / "modules" / "watchdog")
        self.mgr.enable("watchdog")
        d = self.get("/api/widget/watchdog/status")[1]
        self.assertTrue(d["ok"], d)
        self.assertEqual([k for k, _ in d["data"]["items"]][0], "последний запуск")


class WidgetContractTests(unittest.TestCase):
    BASE = {"api": "1", "name": "demo", "version": "1.0.0", "kind": "library"}

    def ok(self, widgets):
        return validate_manifest({**self.BASE, "widgets": widgets})

    def test_valid(self):
        self.assertEqual(self.ok([{"id": "w1", "title": "T", "kind": "kv", "command": ["x"], "refresh_seconds": 5,
                                   "size": {"w": 6, "h": 4},
                                   "actions": [{"id": "go", "label": "Go", "command": ["y"]}]}]), [])

    def test_invalid_variants(self):
        bad = [
            ([{"id": "W", "title": "t", "kind": "kv", "command": ["x"]}], "id"),
            ([{"id": "a", "title": "", "kind": "kv", "command": ["x"]}], "title"),
            ([{"id": "a", "title": "t", "kind": "chart", "command": ["x"]}], "kind"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": []}], "command"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"], "refresh_seconds": 0}], "refresh_seconds"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"], "size": {"w": 1, "h": 4}}], "size"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"], "extra": 1}], "неизвестное поле"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"]}, {"id": "a", "title": "t", "kind": "kv", "command": ["x"]}], "повтор"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"], "actions": [{"id": "a", "label": "", "command": ["y"]}]}], "label"),
            ([{"id": "a", "title": "t", "kind": "kv", "command": ["x"], "actions": [{"id": "g", "label": "G", "command": "rm -rf /"}]}], "command"),
            ("не список", "список"),
        ]
        for widgets, frag in bad:
            self.assertIn(frag, " | ".join(self.ok(widgets)), widgets)


class SettingsTests(PanelBase):
    def test_defaults_update_and_persistence(self):
        s = self.get("/api/settings")[1]
        self.assertEqual((s["language"], s["theme"], s["log_lines"], s["layout"], s["hidden"]), ("ru", "dark", 200, {}, []))
        code, s = self.post("/api/settings", {"language": "en", "theme": "light", "log_lines": 500, "hidden": ["tools"],
                                              "layout": {"system": {"x": 1, "y": 2, "w": 8, "h": 9}}})
        self.assertEqual(code, 200)
        again = AdminState(self.mgr.home).get()   # новый объект читает с диска
        self.assertEqual((again["language"], again["theme"], again["log_lines"]), ("en", "light", 500))
        self.assertEqual(again["layout"]["system"], {"x": 1, "y": 2, "w": 8, "h": 9})
        self.assertEqual(again["hidden"], ["tools"])

    def test_validation_and_clamping(self):
        self.assertEqual(self.post("/api/settings", {"language": "xx"})[0], 400)
        self.assertEqual(self.post("/api/settings", {"theme": "pink"})[0], 400)
        self.assertEqual(self.post("/api/settings", {"theme": "black"})[1]["theme"], "black")
        self.assertEqual(self.post("/api/settings", {"log_lines": "many"})[0], 400)
        self.assertEqual(self.post("/api/settings", {"hidden": "all"})[0], 400)
        self.assertEqual(self.post("/api/settings", {"hidden": ["../x y"]})[0], 400)
        self.assertEqual(self.post("/api/settings", [1, 2])[0], 400)
        self.assertEqual(self.post("/api/settings", {"log_lines": 99999})[1]["log_lines"], 2000)
        self.assertEqual(self.post("/api/settings", {"log_lines": 1})[1]["log_lines"], 20)
        self.assertEqual(self.get("/api/settings")[1]["gap"], 14)
        self.assertEqual(self.post("/api/settings", {"gap": 28})[1]["gap"], 28)
        self.assertEqual(self.post("/api/settings", {"gap": 999})[1]["gap"], 60)
        self.assertEqual(self.post("/api/settings", {"gap": -5})[1]["gap"], 0)
        self.assertEqual(self.post("/api/settings", {"gap": "wide"})[0], 400)

    def test_layout_is_sanitized(self):
        out = sanitize_layout({"ok": {"x": 100, "y": -5, "w": 1, "h": 999}, "bad id!": {"x": 0, "y": 0, "w": 5, "h": 5},
                               "m:plug:w": {"x": 0, "y": 0, "w": 5, "h": 5}, "str": {"x": "a", "y": 0, "w": 5, "h": 5},
                               "partial": {"x": 0}, "bool": {"x": True, "y": 0, "w": 5, "h": 5}})
        self.assertEqual(out["ok"], {"x": 23, "y": 0, "w": 2, "h": 60})
        self.assertIn("m:plug:w", out)
        self.assertEqual(set(out), {"ok", "m:plug:w"})
        with self.assertRaises(ValueError):
            sanitize_layout([1])
        self.assertEqual(self.post("/api/settings", {"layout": [1]})[0], 400)

    def test_corrupted_settings_file_falls_back_to_defaults(self):
        (self.mgr.home / "admin_state.json").write_text("{broken")
        self.assertEqual(self.get("/api/settings")[1]["language"], "ru")


class ProviderUnitTests(unittest.TestCase):
    def test_console_lines_filtering(self):
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".log", delete=False, encoding="utf-8") as f:
            f.write("\x1b[1mline one\x1b[0m\n \n - ...\n[1][Performance][WARN]: x\nline two\n")
        try:
            self.assertEqual(providers.console_lines(f.name), ["line one", "line two"])
            self.assertEqual(providers.console_lines(f.name, n=1), ["line two"])
            self.assertEqual(providers.console_lines("/нет/файла"), [])
        finally:
            os.unlink(f.name)

    def test_tail_text_limits_size(self):
        import tempfile
        with tempfile.NamedTemporaryFile("w", delete=False) as f:
            f.write("a" * 5000 + "TAIL")
        try:
            t = providers.tail_text(f.name, 100)
            self.assertEqual(len(t), 100)
            self.assertTrue(t.endswith("TAIL"))
        finally:
            os.unlink(f.name)


class JsSuiteTests(unittest.TestCase):
    @unittest.skipUnless(shutil.which("node"), "node не найден")
    def test_javascript_suite(self):
        r = subprocess.run(["node", str(ROOT / "tests" / "js" / "run.js")], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stdout[-1500:] + r.stderr[-500:])
        self.assertIn("passed", r.stdout)


if __name__ == "__main__":
    unittest.main()
