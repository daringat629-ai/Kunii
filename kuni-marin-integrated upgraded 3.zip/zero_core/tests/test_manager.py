import json
import os
import shutil
import subprocess
import sys
import threading
import time
import unittest
import zipfile
from pathlib import Path

from helpers import ROOT, Env, make_module
from zerocore.kernel.errors import (ConflictError, ContractError, DependencyError, LifecycleError, ZeroCoreError, TxnError)
from zerocore.kernel.txn import ConfigTransaction
from zerocore.module_manager.manager import Manager


class InstallEnableTests(Env):
    def test_install_is_disabled_and_files_copied(self):
        m = self.inst("alpha", provides=["x.alpha"])
        self.assertEqual(m.name, "alpha")
        st = self.mgr.installed()["alpha"]
        self.assertFalse(st["enabled"])
        self.assertTrue((self.mgr.module_root("alpha") / "current" / "manifest.json").exists())
        with self.assertRaises(ZeroCoreError):  # та же версия второй раз
            self.mgr.install(make_module(self.src, "alpha"))

    def test_install_from_zip_and_zip_slip_rejected(self):
        d = make_module(self.src, "zipped")
        z = self.tmp / "z.zip"
        with zipfile.ZipFile(z, "w") as f:
            for p in d.rglob("*"):
                if p.is_file():
                    f.write(p, p.relative_to(d))
        self.assertEqual(self.mgr.install(z).name, "zipped")
        evil = self.tmp / "evil.zip"
        with zipfile.ZipFile(evil, "w") as f:
            f.writestr("../escape.txt", "x")
        with self.assertRaises(ZeroCoreError):
            self.mgr.install(evil)

    def test_invalid_module_not_installed(self):
        d = make_module(self.src, "broken")
        (d / "manifest.json").write_text('{"api":"1","name":"broken"}')
        with self.assertRaises(ContractError):
            self.mgr.install(d)
        self.assertNotIn("broken", self.mgr.installed())
        self.assertFalse(self.mgr.module_root("broken").exists())

    def test_missing_command_file_rejected(self):
        d = make_module(self.src, "nofile")
        (d / "svc.py").unlink()
        with self.assertRaises(ContractError):
            self.mgr.install(d)

    def test_enable_missing_dependency_changes_nothing(self):
        self.inst("bb", requires=["x.aa"])
        with self.assertRaises(DependencyError):
            self.mgr.enable("bb")
        self.assertFalse(self.mgr.installed()["bb"]["enabled"])

    def test_start_order_and_cascade_stop(self):
        self.inst("aa", provides=["x.aa"])
        self.inst("bb", requires=["x.aa"])
        self.mgr.enable("aa")
        self.mgr.enable("bb")
        self.assertTrue(self.mgr.is_running("aa") and self.mgr.is_running("bb"))
        pid_b = self.mgr.runner.pid("bb")
        self.mgr.stop("aa")  # сначала останавливается зависимый
        self.assertFalse(self.mgr.is_running("aa"))
        self.assertFalse(self.mgr.is_running("bb"))
        self.assertFalse(self.alive(pid_b))
        started = self.mgr.start("bb")  # старт зависимого поднимает зависимость
        self.assertEqual(started, ["aa", "bb"])

    def test_disable_blocked_by_dependents_then_cascade(self):
        self.inst("aa", provides=["x.aa"])
        self.inst("bb", requires=["x.aa"])
        self.mgr.enable("aa")
        self.mgr.enable("bb")
        with self.assertRaises(DependencyError):
            self.mgr.disable("aa")
        self.assertTrue(self.mgr.installed()["aa"]["enabled"])
        victims = self.mgr.disable("aa", cascade=True)
        self.assertEqual(victims, ["bb", "aa"])
        self.assertEqual(self.mgr.enabled_names(), [])
        self.assertFalse(self.mgr.is_running("aa") or self.mgr.is_running("bb"))

    def test_two_modules_same_capability_conflict(self):
        self.inst("xx", provides=["x.same"], kind="library")
        self.inst("yy", provides=["x.same"], kind="library")
        self.mgr.enable("xx")
        with self.assertRaises(ConflictError):
            self.mgr.enable("yy")
        self.assertFalse(self.mgr.installed()["yy"]["enabled"])

    def test_module_loses_dependency_is_detected(self):
        self.inst("aa", provides=["x.aa"], kind="library")
        self.inst("bb", requires=["x.aa"], kind="library")
        self.mgr.enable("aa")
        self.mgr.enable("bb")
        self.assertEqual(self.mgr.check_integrity(), [])
        st = self.mgr.store.load()  # имитация повреждения: зависимость пропала в обход менеджера
        st["modules"]["aa"]["enabled"] = False
        self.mgr.store.save(st)
        self.assertTrue(any("x.aa" in p for p in self.mgr.check_integrity()))
        actions = self.mgr.tick()
        self.assertTrue(any("целостность" in a for a in actions))
        topics = [e["topic"] for e in self.mgr.bus.recent(50)]
        self.assertIn("integrity.broken", topics)
        self.assertEqual(self.mgr.tick(), [])  # повторно о той же проблеме не шумит


class FailureIsolationTests(Env):
    """Отказоустойчивости: ошибка модуля не валит ядро."""

    def test_crashing_module_does_not_break_manager(self):
        self.inst("good", provides=["x.good"])
        self.inst("bad", mode="crash", health="process")
        self.mgr.enable("good")
        with self.assertRaises(LifecycleError) as cm:
            self.mgr.enable("bad")
        self.assertIn("bad", str(cm.exception))
        self.assertTrue(self.mgr.is_running("good"))  # соседний модуль работает
        rows = {r["name"]: r for r in self.mgr.status()}  # менеджер отвечает
        self.assertEqual(rows["bad"]["running"], False)
        self.assertIn("module.failed", [e["topic"] for e in self.mgr.bus.recent(50)])

    def test_start_timeout_when_never_healthy(self):
        self.inst("slow", mode="nohealth", run_extra={"start_timeout": 1})
        with self.assertRaisesRegex(LifecycleError, "не стал здоровым"):
            self.mgr.enable("slow")
        self.mgr.stop("slow")

    def test_hung_module_on_stop_is_killed(self):
        self.inst("stuck", mode="hang")
        self.mgr.enable("stuck")
        pid = self.mgr.runner.pid("stuck")
        t0 = time.time()
        self.mgr.stop("stuck")
        self.assertLess(time.time() - t0, 6)
        self.assertFalse(self.alive(pid))


class TransactionTests(Env):
    def test_concurrent_config_changes_threads(self):
        """Два запроса на изменение конфигурации одновременно (CLI и панель) выстраиваются в очередь."""
        self.inst("cc", kind="library")
        errors = []

        def worker():
            try:
                for _ in range(8):
                    self.mgr.config_update("cc", lambda c: c.__setitem__("counter", c["counter"] + 1))
            except Exception as ex:  # noqa
                errors.append(ex)
        ts = [threading.Thread(target=worker) for _ in range(6)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errors, [])
        self.assertEqual(self.mgr.config("cc")["counter"], 48)

    def test_concurrent_config_changes_processes(self):
        self.inst("cp", kind="library")
        code = ("import sys; sys.path.insert(0, %r)\n"
                "from zerocore.module_manager.manager import Manager\n"
                "m = Manager(%r, repo_root=%r)\n"
                "for _ in range(6): m.config_update('cp', lambda c: c.__setitem__('counter', c['counter'] + 1))\n"
                % (str(ROOT), str(self.mgr.home), str(ROOT)))
        procs = [subprocess.Popen([sys.executable, "-c", code]) for _ in range(4)]
        self.assertEqual([p.wait(timeout=60) for p in procs], [0, 0, 0, 0])
        self.assertEqual(self.mgr.config("cp")["counter"], 24)

    def test_unknown_config_key_rejected_and_rolled_back(self):
        self.inst("cfg", kind="library")
        with self.assertRaises(ZeroCoreError):
            self.mgr.config_set("cfg", "нет_такого", 1)
        self.assertNotIn("нет_такого", self.mgr.config("cfg"))
        self.assertFalse(self.mgr.config_path("cfg").exists())

    def test_lock_timeout(self):
        t1 = ConfigTransaction(self.mgr.home, "holder", self.mgr.store)
        t1.__enter__()
        try:
            with self.assertRaises(TxnError):
                ConfigTransaction(self.mgr.home, "waiter", self.mgr.store, timeout=0.2).__enter__()
        finally:
            t1.__exit__(None, None, None)

    def test_process_dies_mid_install_recovers_on_start(self):
        """Процесс завершился посреди операции: следующий запуск менеджера откатывает её."""
        root = self.mgr.module_root("ghost")
        tx = self.mgr.txn("install ghost")
        tx.__enter__()
        tx.add_undo("rmtree", str(root))
        (root / "versions" / "1.0.0").mkdir(parents=True)
        st = self.mgr.store.load()
        st["modules"]["ghost"] = {"version": "1.0.0", "versions": ["1.0.0"], "enabled": False}
        self.mgr.store.save(st)
        tx._release()  # «смерть процесса»: блокировка снята, журнал остался
        self.assertTrue((self.mgr.home / "txn.journal.json").exists())
        mgr2 = Manager(self.mgr.home, repo_root=ROOT)
        self.assertTrue(mgr2.recovered)
        self.assertNotIn("ghost", mgr2.installed())
        self.assertFalse(root.exists())
        self.assertFalse((mgr2.home / "txn.journal.json").exists())


class UninstallTests(Env):
    def test_uninstall_keeps_data_by_policy(self):
        self.inst("keeper", kind="library", data_policy="keep")
        (self.mgr.home / "data" / "keeper" / "note.txt").write_text("важное")
        r = self.mgr.uninstall("keeper")
        self.assertFalse(r["purged_data"])
        self.assertNotIn("keeper", self.mgr.installed())
        self.assertFalse(self.mgr.module_root("keeper").exists())
        self.assertEqual((self.mgr.home / "data" / "keeper" / "note.txt").read_text(), "важное")
        self.inst("keeper", kind="library")  # переустановка видит сохранённые данные
        self.assertTrue((self.mgr.home / "data" / "keeper" / "note.txt").exists())

    def test_uninstall_delete_policy_and_purge_flag(self):
        self.inst("tmpdata", kind="library", data_policy="delete")
        (self.mgr.home / "data" / "tmpdata" / "x").write_text("1")
        self.assertTrue(self.mgr.uninstall("tmpdata")["purged_data"])
        self.assertFalse((self.mgr.home / "data" / "tmpdata").exists())
        self.inst("keeper2", kind="library", data_policy="keep")
        (self.mgr.home / "data" / "keeper2" / "x").write_text("1")
        self.mgr.uninstall("keeper2", purge_data=True)
        self.assertFalse((self.mgr.home / "data" / "keeper2").exists())

    def test_uninstall_blocked_by_dependents_unless_force(self):
        self.inst("aa", provides=["x.aa"])
        self.inst("bb", requires=["x.aa"])
        self.mgr.enable("aa")
        self.mgr.enable("bb")
        with self.assertRaises(DependencyError):
            self.mgr.uninstall("aa")
        self.assertIn("aa", self.mgr.installed())
        pid = self.mgr.runner.pid("aa")
        self.mgr.uninstall("aa", force=True)
        self.assertFalse(self.alive(pid))
        self.assertIn("bb", self.mgr.installed())
        self.assertFalse(self.mgr.installed()["bb"]["enabled"])  # зависимый выключен каскадом

    def test_interrupted_uninstall_rolls_back(self):
        self.inst("keepme", kind="library", data_policy="delete")
        (self.mgr.home / "data" / "keepme" / "f").write_text("данные")
        with self.assertRaises(RuntimeError):
            self.mgr.uninstall("keepme", _fail_after_move=True)
        self.assertIn("keepme", self.mgr.installed())
        self.assertTrue((self.mgr.module_root("keepme") / "current" / "manifest.json").exists())
        self.assertEqual((self.mgr.home / "data" / "keepme" / "f").read_text(), "данные")

    def test_process_dies_during_uninstall_recovers(self):
        self.inst("dying", kind="library", data_policy="delete")
        root, data = self.mgr.module_root("dying"), self.mgr.home / "data" / "dying"
        (data / "f").write_text("данные")
        trash = self.mgr.home / ".trash" / "dying-x"
        tx = self.mgr.txn("uninstall dying")
        tx.__enter__()
        trash.mkdir(parents=True)
        tx.add_undo("mv", str(trash / "code"), str(root))
        os.replace(root, trash / "code")
        tx.add_undo("mv", str(trash / "data"), str(data))
        os.replace(data, trash / "data")
        st = self.mgr.store.load()
        del st["modules"]["dying"]
        self.mgr.store.save(st)
        tx._release()  # смерть процесса до фиксации
        mgr2 = Manager(self.mgr.home, repo_root=ROOT)
        self.assertIn("dying", mgr2.installed())
        self.assertTrue((root / "current" / "manifest.json").exists())
        self.assertEqual((data / "f").read_text(), "данные")


class HotSwapTests(Env):
    def running_service(self, version="1.0.0", **kw):
        self.inst("svc", version=version, provides=["x.svc"], **kw)
        self.mgr.enable("svc")
        return self.mgr.runner.pid("svc")

    def test_swap_and_rollback(self):
        old_pid = self.running_service()
        self.inst("svc", version="2.0.0", provides=["x.svc"])
        self.mgr.swap("svc", "2.0.0")
        self.assertEqual(self.mgr.installed()["svc"]["version"], "2.0.0")
        self.assertEqual(os.readlink(self.mgr.module_root("svc") / "current"), "versions/2.0.0")
        new_pid = self.mgr.runner.pid("svc")
        self.assertNotEqual(old_pid, new_pid)
        self.assertFalse(self.alive(old_pid))
        self.assertTrue(self.alive(new_pid))
        self.assertIsNone(self.mgr.runner.pid("svc", ".staging"))
        self.assertTrue((self.mgr.home / "data" / "svc" / "started_2.0.0").exists())
        self.mgr.rollback("svc")
        self.assertEqual(self.mgr.installed()["svc"]["version"], "1.0.0")
        self.assertTrue(self.mgr.is_running("svc"))
        self.assertFalse(self.alive(new_pid))
        self.assertEqual(self.mgr.health("svc").state, "healthy")

    def test_new_version_fails_to_start_old_keeps_working(self):
        old_pid = self.running_service()
        self.inst("svc", version="2.0.0", provides=["x.svc"], mode="crash")
        with self.assertRaisesRegex(LifecycleError, "продолжает работать 1.0.0"):
            self.mgr.swap("svc", "2.0.0")
        self.assertEqual(self.mgr.installed()["svc"]["version"], "1.0.0")
        self.assertEqual(os.readlink(self.mgr.module_root("svc") / "current"), "versions/1.0.0")
        self.assertEqual(self.mgr.runner.pid("svc"), old_pid)
        self.assertTrue(self.alive(old_pid))
        self.assertIsNone(self.mgr.runner.pid("svc", ".staging"))
        self.assertIn("swap.failed", [e["topic"] for e in self.mgr.bus.recent(50)])

    def test_new_version_never_healthy(self):
        old_pid = self.running_service()
        self.inst("svc", version="2.0.0", provides=["x.svc"], mode="nohealth", run_extra={"start_timeout": 1})
        with self.assertRaises(LifecycleError):
            self.mgr.swap("svc", "2.0.0")
        self.assertTrue(self.alive(old_pid))
        self.assertIsNone(self.mgr.runner.pid("svc", ".staging"))

    def test_stop_first_strategy_restores_old_on_failure(self):
        self.running_service(run_extra={"handoff": "stop_first"})
        self.inst("svc", version="2.0.0", provides=["x.svc"], mode="crash", run_extra={"handoff": "stop_first"})
        with self.assertRaisesRegex(LifecycleError, "старая версия 1.0.0 возвращена"):
            self.mgr.swap("svc", "2.0.0")
        self.assertEqual(self.mgr.installed()["svc"]["version"], "1.0.0")
        self.assertTrue(self.mgr.is_running("svc"))
        self.assertEqual(self.mgr.health("svc").state, "healthy")

    def test_swap_blocked_if_dependents_constraint_breaks(self):
        self.inst("core", provides=["x.core"], kind="library")
        self.inst("app", requires=["x.core"], depends={"core": ">=1.0,<2.0"}, kind="library")
        self.mgr.enable("core")
        self.mgr.enable("app")
        self.inst("core", version="2.0.0", provides=["x.core"], kind="library")
        with self.assertRaises(DependencyError):
            self.mgr.swap("core", "2.0.0")
        self.assertEqual(self.mgr.installed()["core"]["version"], "1.0.0")
        self.assertEqual(os.readlink(self.mgr.module_root("core") / "current"), "versions/1.0.0")

    def test_swap_without_running_process_just_switches(self):
        self.inst("lib", kind="library")
        self.inst("lib", version="1.1.0", kind="library")
        self.mgr.swap("lib", "1.1.0")
        self.assertEqual(self.mgr.manifest("lib").version, "1.1.0")

    def test_process_dies_mid_swap_symlink_restored(self):
        self.inst("lib", kind="library")
        self.inst("lib", version="1.1.0", kind="library")
        link = self.mgr.module_root("lib") / "current"
        tx = self.mgr.txn("swap lib")
        tx.__enter__()
        tx.add_undo("symlink", str(link), os.readlink(link))
        tmp = link.with_name("current.new")
        os.symlink("versions/1.1.0", tmp)
        os.replace(tmp, link)  # переключили, но состояние не записали
        tx._release()
        mgr2 = Manager(self.mgr.home, repo_root=ROOT)
        self.assertTrue(mgr2.recovered)
        self.assertEqual(os.readlink(link), "versions/1.0.0")
        self.assertEqual(mgr2.installed()["lib"]["version"], "1.0.0")

    def test_rollback_without_previous(self):
        self.inst("lib", kind="library")
        with self.assertRaises(ZeroCoreError):
            self.mgr.rollback("lib")


class TickTests(Env):
    def test_job_runs_when_due_and_records_failure(self):
        self.inst("jobok", kind="job", schedule=10)
        self.inst("jobbad", kind="job", schedule=10, mode="fail")
        self.mgr.enable("jobok")
        self.mgr.enable("jobbad")
        t0 = time.time()
        self.mgr.tick(now=t0)
        self.mgr.tick(now=t0 + 5)  # ещё рано
        runs = (self.mgr.home / "data" / "jobok" / "runs.txt").read_text().count("run")
        self.assertEqual(runs, 1)
        self.mgr.tick(now=t0 + 11)
        self.assertEqual((self.mgr.home / "data" / "jobok" / "runs.txt").read_text().count("run"), 2)
        self.assertEqual(self.mgr.health("jobok").state, "healthy")
        self.assertEqual(self.mgr.health("jobbad").state, "unhealthy")
        topics = [e["topic"] for e in self.mgr.bus.recent(100)]
        self.assertIn("job.failed", topics)

    def test_restart_on_failure_with_limit(self):
        self.inst("web", health="process", run_extra={"restart": "on-failure"})
        self.mgr.enable("web")
        base = time.time()
        restarts = 0
        for i in range(5):
            pid = self.mgr.runner.pid("web")
            if pid:
                os.killpg(pid, 9)
                time.sleep(0.2)
            acts = self.mgr.tick(now=base + i)
            restarts += sum("перезапущен" in a for a in acts)
        self.assertEqual(restarts, 3)  # не больше трёх за 10 минут
        self.assertIn("restart.suppressed", [e["topic"] for e in self.mgr.bus.recent(100)])

    def test_no_restart_if_user_stopped_it(self):
        self.inst("web2", health="process", run_extra={"restart": "on-failure"})
        self.mgr.enable("web2")
        self.mgr.stop("web2")
        self.mgr.tick(now=time.time())
        self.assertFalse(self.mgr.is_running("web2"))


class CompatibilityTests(Env):
    """Совместимости: модуль на другом языке работает по тому же контракту."""

    def test_bash_module_follows_contract(self):
        d = self.src / "shmod"
        d.mkdir()
        (d / "run.sh").write_text("#!/bin/bash\ntrap 'exit 0' TERM\n"
                                  "[ \"$ZEROCORE_API\" = 1 ] || exit 9\n[ -n \"$ZEROCORE_DATA_DIR\" ] || exit 8\n"
                                  "while true; do touch \"$ZEROCORE_DATA_DIR/ready\"; sleep 0.1; done\n")
        (d / "manifest.json").write_text(json.dumps({
            "api": "1", "name": "shmod", "version": "1.0.0", "kind": "service",
            "run": {"command": ["bash", "${module_dir}/run.sh"], "stop_timeout": 3, "start_timeout": 5},
            "health": {"type": "file_fresh", "path": "${data_dir}/ready", "max_age_seconds": 2}}))
        self.mgr.install(d)
        self.mgr.enable("shmod")
        self.assertEqual(self.mgr.health("shmod").state, "healthy")
        pid = self.mgr.runner.pid("shmod")
        self.mgr.stop("shmod")
        self.assertFalse(self.alive(pid))

    def test_external_module_with_kill_fallback(self):
        exe = self.tmp / "mxfake1"
        shutil.copy("/bin/sleep", exe)
        d = self.src / "ext"
        d.mkdir()
        (d / "manifest.json").write_text(json.dumps({
            "api": "1", "name": "ext", "version": "1.0.0", "kind": "external",
            "run": {"start_command": ["bash", "-c", f"setsid {exe} 300 >/dev/null 2>&1 &"],
                    "stop_command": ["true"], "kill_command": ["pkill", "-x", "mxfake1"],
                    "stop_timeout": 1, "start_timeout": 5},
            "health": {"type": "pgrep", "process": "mxfake1"}}))
        self.mgr.install(d)
        self.mgr.enable("ext")
        self.assertTrue(self.mgr.is_running("ext"))
        self.assertEqual(self.mgr.health("ext").state, "healthy")
        self.mgr.stop("ext")  # stop_command ничего не делает, срабатывает kill_command
        self.assertFalse(self.mgr.is_running("ext"))


class ShippedModulesTests(Env):
    def test_bootstrap_registers_real_modules(self):
        from zerocore.cli import main
        rc = main(["--home", str(self.mgr.home), "bootstrap"])
        self.assertEqual(rc, 0)
        mgr = Manager(self.mgr.home, repo_root=ROOT)
        self.assertEqual(set(mgr.installed()), {"kuni", "watchdog", "webview", "world_v2", "demo_counter", "demo_tools"})
        self.assertEqual(sorted(mgr.enabled_names()), ["kuni", "watchdog", "world_v2"])
        self.assertEqual(mgr.check_integrity(), [])
        kuni = mgr.manifest("kuni")
        self.assertEqual(mgr._expand(kuni.run["start_command"], "kuni", mgr.module_dir("kuni"))[-1],
                         "/home/marinka/kuni/start-safe.sh")

    def test_watchdog_job_runs_through_manager(self):
        from zerocore.cli import main
        main(["--home", str(self.mgr.home), "bootstrap"])
        mgr = Manager(self.mgr.home, repo_root=ROOT)
        mgr.config_set("watchdog", "kuni_logs", str(self.tmp / "нет_логов"))
        mgr.config_set("watchdog", "aui_logs", str(self.tmp / "aui.*.log"))
        mgr.tick(now=time.time())
        self.assertEqual(mgr.health("watchdog").state, "healthy")

    def test_webview_requires_world_state(self):
        from zerocore.cli import main
        main(["--home", str(self.mgr.home), "bootstrap"])
        mgr = Manager(self.mgr.home, repo_root=ROOT)
        mgr.disable("world_v2", cascade=True)
        with self.assertRaises(DependencyError):
            mgr.enable("webview")

    def test_cli_status_and_errors(self):
        from zerocore.cli import main
        self.assertEqual(main(["--home", str(self.mgr.home), "status"]), 0)
        self.assertEqual(main(["--home", str(self.mgr.home), "enable", "нет"]), 1)


if __name__ == "__main__":
    unittest.main()
