import json
import os
import shutil
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from zerocore.module_manager.manager import Manager  # noqa: E402

SVC = textwrap.dedent('''
    import os, signal, sys, time, pathlib
    mode = os.environ.get("MODE", "ok")
    ver = os.environ.get("MODVER", "?")
    data = pathlib.Path(os.environ["ZEROCORE_DATA_DIR"]); data.mkdir(parents=True, exist_ok=True)
    if mode == "crash":
        sys.exit(1)
    if mode == "hang":
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
    else:
        signal.signal(signal.SIGTERM, lambda *a: sys.exit(0))
    (data / ("started_" + ver)).write_text(str(os.getpid()))
    while True:
        if mode != "nohealth":
            (data / ("ready_" + ver)).write_text(str(time.time()))
        time.sleep(0.1)
''')

JOB = textwrap.dedent('''
    import os, sys, pathlib
    d = pathlib.Path(os.environ["ZEROCORE_DATA_DIR"]); d.mkdir(parents=True, exist_ok=True)
    with open(d / "runs.txt", "a") as f:
        f.write("run\\n")
    sys.exit(3 if os.environ.get("MODE") == "fail" else 0)
''')


def make_module(tmp, name, version="1.0.0", kind="service", provides=(), requires=(), depends=None, mode="ok",
                health="file", data_policy="keep", conflicts=(), run_extra=None, schedule=10, config_extra=None, widgets=None, files=None, tools=None):
    d = Path(tmp) / f"{name}-{version}"
    d.mkdir(parents=True, exist_ok=True)
    cfg = {"mode": mode, "ver": version, "counter": 0}
    cfg.update(config_extra or {})
    m = {"api": "1", "name": name, "version": version, "kind": kind, "description": "тестовый модуль",
         "provides": list(provides), "requires": list(requires), "depends": depends or {}, "conflicts": list(conflicts),
         "data_policy": data_policy, "config": cfg}
    if kind == "service":
        (d / "svc.py").write_text(SVC)
        m["run"] = {"command": [sys.executable, "${module_dir}/svc.py"], "stop_timeout": 2, "start_timeout": 3,
                    "env": {"MODE": "${config.mode}", "MODVER": "${config.ver}"}}
        m["health"] = ({"type": "file_fresh", "path": "${data_dir}/ready_${config.ver}", "max_age_seconds": 2}
                       if health == "file" else {"type": health})
    elif kind == "job":
        (d / "job.py").write_text(JOB)
        m["run"] = {"command": [sys.executable, "${module_dir}/job.py"], "schedule_seconds": schedule, "timeout": 10,
                    "env": {"MODE": "${config.mode}"}}
        m["health"] = {"type": "job"}
    else:
        m["health"] = {"type": "none"}
    if run_extra:
        m.setdefault("run", {}).update(run_extra)
    if widgets:
        m["widgets"] = widgets
    if tools:
        m["tools"] = tools
    for fname, text in (files or {}).items():
        (d / fname).write_text(text)
    (d / "manifest.json").write_text(json.dumps(m, ensure_ascii=False, indent=1))
    return d


class Env(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="zerocore_t_"))
        self.src = self.tmp / "src"
        self.src.mkdir()
        self.mgr = Manager(self.tmp / "home", repo_root=ROOT)

    def tearDown(self):
        try:
            for n in list(self.mgr.installed()):
                try:
                    self.mgr.runner.stop(n, 1)
                    self.mgr.runner.stop(n, 1, ".staging")
                except Exception:
                    pass
        finally:
            shutil.rmtree(self.tmp, ignore_errors=True)

    def inst(self, name, **kw):
        return self.mgr.install(make_module(self.src, name, **kw))

    def alive(self, pid):
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return False
        try:
            with open(f"/proc/{pid}/stat") as f:
                return f.read().rsplit(")", 1)[1].split()[0] != "Z"
        except OSError:
            return False
