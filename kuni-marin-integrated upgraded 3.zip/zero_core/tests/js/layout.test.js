const assert = require('assert');
const L = require('../../zerocore/admin/web/layout.js');

function lcg(seed) { let s = seed; return () => (s = (s * 1664525 + 1013904223) % 4294967296) / 4294967296; }
function noOverlaps(layout) {
  const ids = Object.keys(layout);
  for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) {
    if (L.overlaps(layout[ids[i]], layout[ids[j]])) return false;
  }
  return true;
}
module.exports = function (test) {
  test('clampRect keeps the rect inside the grid and respects minimum size', () => {
    assert.deepStrictEqual(L.clampRect({ x: -5, y: -1, w: 1, h: 1 }), { x: 0, y: 0, w: 3, h: 3 });
    assert.deepStrictEqual(L.clampRect({ x: 30, y: 2, w: 8, h: 4 }), { x: 16, y: 2, w: 8, h: 4 });
    assert.deepStrictEqual(L.clampRect({ x: 0, y: 0, w: 99, h: 99 }), { x: 0, y: 0, w: 24, h: 60 });
    assert.deepStrictEqual(L.clampRect({ x: 1.6, y: 2.4, w: 5.5, h: 4.4 }), { x: 2, y: 2, w: 6, h: 4 });
  });
  test('overlaps: touching edges do not overlap', () => {
    assert.ok(L.overlaps({ x: 0, y: 0, w: 4, h: 4 }, { x: 3, y: 3, w: 4, h: 4 }));
    assert.ok(!L.overlaps({ x: 0, y: 0, w: 4, h: 4 }, { x: 4, y: 0, w: 4, h: 4 }));
    assert.ok(!L.overlaps({ x: 0, y: 0, w: 4, h: 4 }, { x: 0, y: 4, w: 4, h: 4 }));
  });
  test('findFreeSpot never overlaps and fills rows left to right', () => {
    const layout = { a: { x: 0, y: 0, w: 8, h: 6 } };
    assert.deepStrictEqual(L.findFreeSpot(layout, 8, 6), { x: 8, y: 0, w: 8, h: 6 });
    layout.b = { x: 8, y: 0, w: 8, h: 6 }; layout.c = { x: 16, y: 0, w: 8, h: 6 };
    assert.deepStrictEqual(L.findFreeSpot(layout, 8, 6), { x: 0, y: 6, w: 8, h: 6 });
  });
  test('mergeLayout keeps saved positions, drops unknown ids, places new widgets without overlap', () => {
    const items = [{ id: 'a', w: 8, h: 6 }, { id: 'b', w: 8, h: 6 }, { id: 'c', w: 8, h: 6 }];
    const saved = { a: { x: 4, y: 2, w: 8, h: 6 }, gone: { x: 0, y: 0, w: 5, h: 5 }, bad: { x: 'q' } };
    const m = L.mergeLayout(saved, items);
    assert.deepStrictEqual(m.a, { x: 4, y: 2, w: 8, h: 6 });
    assert.ok(!('gone' in m) && Object.keys(m).length === 3 && noOverlaps(m));
  });
  test('sanitizeLayout rejects garbage', () => {
    assert.deepStrictEqual(L.sanitizeLayout(null, ['a']), {});
    assert.deepStrictEqual(L.sanitizeLayout({ a: { x: NaN, y: 0, w: 5, h: 5 } }, ['a']), {});
    assert.deepStrictEqual(L.sanitizeLayout({ a: { x: 100, y: 0, w: 5, h: 5 } }, ['a']).a, { x: 19, y: 0, w: 5, h: 5 });
  });
  test('resolveCollisions pushes overlapped widgets below, cascading', () => {
    const layout = { m: { x: 0, y: 0, w: 8, h: 6 }, a: { x: 0, y: 3, w: 8, h: 4 }, b: { x: 0, y: 8, w: 8, h: 4 } };
    const out = L.resolveCollisions(layout, 'm');
    assert.strictEqual(out.a.y, 6);
    assert.strictEqual(out.b.y, 10);   // pushed by a (a ends at 10)
    assert.ok(noOverlaps(out));
    assert.strictEqual(layout.a.y, 3, 'input must not be mutated');
  });
  test('after any drag the layout has no overlaps (random property test)', () => {
    const rnd = lcg(12345);
    for (let round = 0; round < 300; round++) {
      const n = 3 + Math.floor(rnd() * 9);
      const items = [];
      for (let i = 0; i < n; i++) items.push({ id: 'w' + i, w: 3 + Math.floor(rnd() * 10), h: 3 + Math.floor(rnd() * 8) });
      let layout = L.mergeLayout({}, items);
      assert.ok(noOverlaps(layout), 'initial layout overlaps');
      for (let step = 0; step < 6; step++) {
        const id = 'w' + Math.floor(rnd() * n);
        layout[id] = L.clampRect({ x: rnd() * 24, y: rnd() * 30, w: layout[id].w + Math.floor(rnd() * 5 - 2), h: layout[id].h + Math.floor(rnd() * 5 - 2) });
        layout = L.resolveCollisions(layout, id);
        assert.ok(noOverlaps(layout), 'overlap after drag, round ' + round);
      }
    }
  });
  test('pxToCells and rectToPx', () => {
    assert.deepStrictEqual(L.pxToCells(120, 61, 50, 30), { dx: 2, dy: 2 });
    assert.deepStrictEqual(L.pxToCells(-70, -10, 50, 30), { dx: -1, dy: 0 });
    assert.deepStrictEqual(L.rectToPx({ x: 2, y: 1, w: 4, h: 3 }, 50, 30, 6), { left: 103, top: 33, width: 194, height: 84 });
    assert.strictEqual(L.boardRows({ a: { x: 0, y: 2, w: 3, h: 4 }, b: { x: 0, y: 0, w: 3, h: 3 } }), 6);
  });
  test('threadPairs connects only visible widgets and links plugin widgets to the plugins hub', () => {
    const ids = ['system', 'plugins', 'log', 'm:demo:counter', 'm:other:w'];
    const pairs = L.threadPairs(ids).map(p => p.a + '>' + p.b);
    assert.deepStrictEqual(pairs.sort(), ['plugins>log', 'plugins>m:demo:counter', 'plugins>m:other:w', 'system>plugins'].sort());
    assert.deepStrictEqual(L.threadPairs(['system', 'log']).map(p => p.a + '>' + p.b), []);              // нет «Плагинов»: нет и связей
    assert.deepStrictEqual(L.threadPairs(['m:demo:counter']), []);                                          // виджет плагина без хаба
    assert.strictEqual(L.threadPairs(ids).filter(p => p.kind === 'module').length, 2);
    const unique = new Set(L.threadPairs(ids).map(p => p.a + '>' + p.b));
    assert.strictEqual(unique.size, L.threadPairs(ids).length, 'no duplicates');
  });
  test('threadCurve leaves from the facing edges (horizontal and vertical) and handles overlapping rects', () => {
    const r = (left, top, width, height) => ({ left, top, width, height });
    const h = L.threadCurve(r(0, 0, 100, 50), r(300, 100, 100, 50));      // справа
    assert.deepStrictEqual([h[0], h[3]], [[100, 25], [300, 125]]);
    const hl = L.threadCurve(r(300, 100, 100, 50), r(0, 0, 100, 50));     // то же в обратную сторону
    assert.deepStrictEqual([hl[0], hl[3]], [[300, 125], [100, 25]]);
    const v = L.threadCurve(r(0, 0, 100, 50), r(20, 300, 100, 50));       // ниже, горизонтальный зазор отрицательный
    assert.deepStrictEqual([v[0], v[3]], [[50, 50], [70, 300]]);
    const vu = L.threadCurve(r(20, 300, 100, 50), r(0, 0, 100, 50));
    assert.deepStrictEqual([vu[0], vu[3]], [[70, 300], [50, 50]]);
    const o = L.threadCurve(r(0, 0, 100, 100), r(50, 50, 100, 100));      // перекрываются: не падает, конечные точки конечны
    assert.ok(o.every(pt => pt.every(Number.isFinite)));
    assert.strictEqual(h[1][1], 25); assert.strictEqual(h[2][1], 125);    // касательные горизонтальные
    assert.ok(h[1][0] > h[0][0] && h[2][0] < h[3][0]);
  });
  test('bezierPoint hits the end points and the midpoint of a symmetric curve', () => {
    const c = [[0, 0], [100, 0], [100, 100], [200, 100]];
    assert.deepStrictEqual(L.bezierPoint(c, 0), [0, 0]);
    assert.deepStrictEqual(L.bezierPoint(c, 1), [200, 100]);
    const m = L.bezierPoint(c, 0.5);
    assert.ok(Math.abs(m[0] - 100) < 1e-9 && Math.abs(m[1] - 50) < 1e-9);
  });
  test('mergeLayout uses recommended positions when they are free, otherwise finds a free spot', () => {
    const items = [{ id: 'c', w: 4, h: 4, x: 0, y: 0 }, { id: 'a', w: 4, h: 4, x: 10, y: 10 }, { id: 'b', w: 4, h: 4, x: 10, y: 10 }, { id: 'd', w: 4, h: 4 }];
    const m = L.mergeLayout({}, items);
    assert.deepStrictEqual(m.a, { x: 10, y: 10, w: 4, h: 4 });
    assert.deepStrictEqual(m.c, { x: 0, y: 0, w: 4, h: 4 });
    assert.ok(!L.overlaps(m.a, m.b) && Object.keys(m).length === 4);
    const keys = Object.keys(m);
    for (let i = 0; i < keys.length; i++) for (let j = i + 1; j < keys.length; j++) assert.ok(!L.overlaps(m[keys[i]], m[keys[j]]));
    const saved = L.mergeLayout({ a: { x: 2, y: 2, w: 4, h: 4 } }, items);
    assert.deepStrictEqual(saved.a, { x: 2, y: 2, w: 4, h: 4 }, 'a saved rect wins over the hint');
  });
};
