const assert = require('assert');
const { Document } = require('./dom_stub.js');
const L = require('../../zerocore/admin/web/layout.js');
const app = require('../../zerocore/admin/web/app.js');

const flush = async (n = 8) => { for (let i = 0; i < n; i++) await new Promise(r => setImmediate(r)); };

function makeEnv(opts = {}) {
  const doc = new Document();
  const calls = [];
  const store = { zc_token: opts.noToken ? '' : 'tok' };
  let settings = Object.assign({ language: 'ru', theme: 'dark', log_lines: 200, layout: {}, hidden: [] }, opts.settings || {});
  let counter = 229;
  const server = { token: 'tok', fail: {} };
  const data = {
    '/api/system': { zerocore: '0.1.0', python: '3.12', os: 'Linux (x86_64)', pid: 1, home: '/h', uptime: 3700, modules: 2, enabled: 2, integrity: [], host: { load1: 0.5, mem_pct: 40 } },
    '/api/llm': { available: true, provider: 'openrouter', model: 'deepseek/deepseek-v4-flash', host: 'https://openrouter.ai', embedding_model: 'qwen3-embedding', embedding_host: '', lockdown: 'papik_only' },
    '/api/transports': [{ name: 'kuni', capability: 'telegram.bot', running: true, health: 'healthy' }],
    '/api/stats': { llm_requests_today: 5, shell_commands: 2, messages_sent: 3, guard_refusals: 0, llm_http_errors: 0, errors: 0 },
    '/api/generation': { known: true, active: false, last_seconds: 4.2, ago: 30 },
    '/api/metrics': [{ t: 1, load1: 0.2, mem: 40, rss: 300 }, { t: 2, load1: 0.4, mem: 41, rss: 310 }],
    '/api/tools': [{ name: 'shell', description: 'Runs bash' }, { name: 'ask', description: 'memory' }],
    '/api/log': [{ t: 1760000000, src: 'core', text: 'module.started {}' }, { t: 1760000001, src: 'kuni', text: '[WARN]: x' }],
    '/api/architecture': { nodes: [
      { id: 'manager', title: 'Менеджер модулей', group: 'manager', status: 'ok', lines: ['установлено: 2'], pos: { x: 10, y: 15, w: 4, h: 4 } },
      { id: 'mod_kuni', title: 'kuni', group: 'module', status: 'ok', lines: ['даёт: telegram.bot'], module: 'kuni', version: '0.0.2', kind: 'external', enabled: true, running: true, health: 'healthy', pos: { x: 10, y: 10, w: 4, h: 4 } },
      { id: 'mod_demo_tools', title: 'demo_tools', group: 'module', status: 'off', lines: ['инструментов: 2'], module: 'demo_tools', version: '1.0.0', kind: 'library', enabled: false, running: false, health: 'unknown', pos: { x: 5, y: 10, w: 4, h: 4 } },
      { id: 'catalog', title: 'Каталог инструментов', group: 'manager', status: 'ok', lines: ['инструментов: 0'], pos: { x: 20, y: 15, w: 4, h: 4 } }],
      edges: [{ a: 'manager', b: 'mod_kuni', label: 'управляет', kind: 'manage', off: false }, { a: 'manager', b: 'mod_demo_tools', label: 'управляет', kind: 'manage', off: true },
              { a: 'mod_demo_tools', b: 'catalog', label: 'инструменты', kind: 'tools', off: true }] },
    '/api/activity': { now: 500, events: [] },
    '/api/modules': [
      { name: 'kuni', version: '0.0.2', kind: 'external', enabled: true, running: true, health: 'healthy', detail: '', provides: ['telegram.bot'], widgets: [] },
      { name: 'demo_counter', version: '1.0.0', kind: 'library', enabled: true, running: false, health: 'unknown', detail: '', provides: [], widgets: [{ id: 'counter', title: 'Demo counter', kind: 'counter', refresh: 5, size: { w: 6, h: 6 } }] },
    ],
  };
  const fetch = async (path, init) => {
    calls.push({ path, method: init.method, body: init.body ? JSON.parse(init.body) : undefined });
    const reply = (status, body) => ({ status, ok: status < 400, json: async () => body });
    if (init.headers['X-Token'] !== server.token) return reply(401, { error: 'token' });
    if (server.fail[path]) return reply(500, { error: server.fail[path] });
    if (path === '/api/settings') {
      if (init.method === 'POST') settings = Object.assign({}, settings, JSON.parse(init.body));
      return reply(200, settings);
    }
    if (path === '/api/widget/demo_counter/counter') return reply(200, { ok: true, kind: 'counter', title: 'Demo counter', data: { value: counter, label: 'кликов' }, actions: [{ id: 'plus10', label: '+10' }], note: null });
    if (path === '/api/widget/demo_counter/counter/action/plus10') { counter += 10; return reply(200, { ok: true, kind: 'counter', title: 'Demo counter', data: { value: counter, label: 'кликов' }, actions: [{ id: 'plus10', label: '+10' }], note: '+10 → ' + counter }); }
    if (path.startsWith('/api/log')) return reply(200, data['/api/log']);
    if (path.startsWith('/api/activity')) return reply(200, data['/api/activity']);
    if (data[path]) return reply(200, data[path]);
    if (path.startsWith('/api/modules/')) return reply(200, { ok: true });
    return reply(404, { error: 'nf' });
  };
  const intervals = [];
  const env = { document: doc, fetch, storage: { getItem: k => store[k] || null, setItem: (k, v) => { store[k] = v; } },
                setInterval: (fn, ms) => { intervals.push(fn); return intervals.length; }, setTimeout: () => 0, clearTimeout: () => {},
                confirm: () => true, Layout: L, window: { addEventListener() {} } };
  return { env, doc, calls, server, store, intervals, getSettings: () => settings, data };
}
const texts = (doc) => doc.board.all(n => n.classList && n.classList.contains('widget')).map(w => w.textContent).join('\n');

module.exports = function (test) {
  test('boot renders all built-in widgets plus the plugin widget', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const widgets = t.doc.board.byClass('widget');
    assert.strictEqual(widgets.length, 10, 'expected 9 built-in + 1 plugin widget');
    const all = texts(t.doc);
    for (const s of ['Система', 'LLM', 'Транспорты', 'Генерация', 'Статистика', 'График нагрузки', 'Живой лог', 'Плагины', 'Тулы', 'Demo counter']) {
      assert.ok(all.includes(s), 'missing widget title ' + s);
    }
    assert.ok(all.includes('deepseek/deepseek-v4-flash') && all.includes('openrouter'));
    assert.ok(all.includes('kuni 0.0.2') && all.includes('demo_counter 1.0.0'));
    assert.ok(all.includes('229'), 'counter value');
    assert.ok(all.includes('module.started'), 'log line');
    assert.ok(all.includes('▸ shell'), 'tools');
    assert.strictEqual(t.doc.body.className, 'theme-dark');
  });
  test('plugin counter: button runs the declared action and re-renders', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const btn = t.doc.board.buttons('+10')[0];
    assert.ok(btn, '+10 button');
    btn.dispatch('click', {}); await flush();
    const all = texts(t.doc);
    assert.ok(all.includes('239') && all.includes('+10 → 239'));
    assert.ok(t.calls.some(c => c.method === 'POST' && c.path === '/api/widget/demo_counter/counter/action/plus10'));
  });
  test('without a token the login dialog is shown; entering it starts the panel', async () => {
    const t = makeEnv({ noToken: true });
    const a = app.boot(t.env); await flush();
    assert.strictEqual(t.doc.overlay.hidden, false);
    const input = t.doc.overlay.byId('token-input');
    input.value = 'tok';
    t.doc.overlay.byId('token-submit').dispatch('click', {}); await flush(20);
    assert.strictEqual(t.store.zc_token, 'tok');
    assert.strictEqual(t.doc.overlay.hidden, true);
    assert.ok(t.doc.board.byClass('widget').length >= 9);
  });
  test('a token in the address (#token=...) is stored, removed from the address and the panel starts without the login dialog', async () => {
    const t = makeEnv({ noToken: true });
    const replaced = [];
    t.env.location = { hash: '#token=tok', pathname: '/', search: '' };
    t.env.history = { replaceState: (a, b, url) => replaced.push(url) };
    const a = app.boot(t.env); await a.started; await flush();
    assert.strictEqual(t.store.zc_token, 'tok');
    assert.deepStrictEqual(replaced, ['/']);
    assert.strictEqual(t.doc.overlay.hidden, true, 'no login dialog');
    assert.ok(t.doc.board.byClass('widget').length >= 9);
  });
  test('an encoded token and other hash parameters are handled; a hash without a token changes nothing', async () => {
    const t = makeEnv({ noToken: true });
    t.env.location = { hash: '#x=1&token=a%2Bb', pathname: '/p', search: '?q=1' };
    t.env.history = { replaceState() {} };
    t.server.token = 'a+b';
    const a = app.boot(t.env); await a.started; await flush();
    assert.strictEqual(t.store.zc_token, 'a+b');
    const u = makeEnv({ noToken: true });
    u.env.location = { hash: '#something', pathname: '/', search: '' };
    let called = 0; u.env.history = { replaceState() { called++; } };
    app.boot(u.env); await flush();
    assert.strictEqual(called, 0);
    assert.strictEqual(u.doc.overlay.hidden, false, 'login dialog is shown');
  });
  test('a wrong token (401) brings the login dialog back', async () => {
    const t = makeEnv(); t.server.token = 'other';
    const a = app.boot(t.env); await flush(20);
    assert.strictEqual(t.doc.overlay.hidden, false);
    assert.ok(t.doc.overlay.byId('token-input'));
  });
  test('one failing endpoint shows an error in that widget only', async () => {
    const t = makeEnv(); t.server.fail['/api/llm'] = 'config.toml не найден';
    const a = app.boot(t.env); await a.started; await flush();
    const llm = t.doc.board.byId('w-llm');
    assert.ok(llm.textContent.includes('config.toml не найден'));
    assert.ok(t.doc.board.byId('w-system').textContent.includes('Linux'));
  });
  test('dragging a widget moves it by whole cells and saves the layout', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const before = Object.assign({}, a.S.layout.system);
    const head = t.doc.board.byId('w-system').byClass('wh')[0];
    head.dispatch('pointerdown', { clientX: 100, clientY: 100 });
    t.doc.dispatch('pointermove', { clientX: 100 + 100, clientY: 100 + 61 });   // cellW = 1200/24 = 50, rowH = 30
    t.doc.dispatch('pointerup', {}); await flush();
    const after = a.S.layout.system;
    assert.strictEqual(after.x, Math.min(before.x + 2, 24 - before.w));
    assert.strictEqual(after.y, before.y + 2);
    const ids = Object.keys(a.S.layout);
    for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) assert.ok(!L.overlaps(a.S.layout[ids[i]], a.S.layout[ids[j]]), 'overlap ' + ids[i] + ' ' + ids[j]);
    const save = t.calls.filter(c => c.method === 'POST' && c.path === '/api/settings' && c.body.layout).pop();
    assert.ok(save && save.body.layout.system.y === after.y);
    assert.ok(!t.doc.listeners.pointermove.length, 'drag listeners are removed');
  });
  test('resizing changes width and height and respects the minimum', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const r0 = Object.assign({}, a.S.layout.llm);
    const handle = t.doc.board.byId('w-llm').byClass('rh')[0];
    handle.dispatch('pointerdown', { clientX: 500, clientY: 500 });
    t.doc.dispatch('pointermove', { clientX: 500 - 5000, clientY: 500 - 5000 });
    t.doc.dispatch('pointerup', {}); await flush();
    assert.strictEqual(a.S.layout.llm.w, L.MIN_W);
    assert.strictEqual(a.S.layout.llm.h, L.MIN_H);
  });
  test('on a narrow screen widgets are stacked and dragging is disabled', async () => {
    const t = makeEnv(); t.doc.board.rect.width = 500;
    const a = app.boot(t.env); await a.started; await flush();
    assert.strictEqual(t.doc.board.className, 'stack');
    const before = JSON.stringify(a.S.layout);
    t.doc.board.byId('w-system').byClass('wh')[0].dispatch('pointerdown', { clientX: 1, clientY: 1 });
    t.doc.dispatch('pointermove', { clientX: 300, clientY: 300 }); t.doc.dispatch('pointerup', {});
    assert.strictEqual(JSON.stringify(a.S.layout), before);
  });
  test('hiding a widget removes it and can be undone from the hidden list', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.board.byId('w-tools').byClass('wx')[0].dispatch('click', {}); await flush();
    assert.strictEqual(t.doc.board.byId('w-tools'), null);
    assert.deepStrictEqual(t.getSettings().hidden, ['tools']);
    t.doc.topbar.byId('btn-hidden').dispatch('click', {});
    assert.strictEqual(t.doc.overlay.hidden, false);
    t.doc.overlay.buttons('Показать')[0].dispatch('click', {}); await flush();
    assert.ok(t.doc.board.byId('w-tools'));
    assert.deepStrictEqual(t.getSettings().hidden, []);
  });
  test('settings dialog switches language and theme', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.topbar.byId('btn-settings').dispatch('click', {});
    t.doc.overlay.byId('s-lang').value = 'en';
    t.doc.overlay.byId('s-theme').value = 'light';
    t.doc.overlay.byId('s-lines').value = '500';
    t.doc.overlay.byId('s-save').dispatch('click', {}); await flush(20);
    const s = t.getSettings();
    assert.strictEqual(s.language, 'en'); assert.strictEqual(s.theme, 'light'); assert.strictEqual(s.log_lines, 500);
    assert.strictEqual(t.doc.body.className, 'theme-light');
    assert.ok(texts(t.doc).includes('System') && texts(t.doc).includes('Plugins'));
  });
  test('module action asks for confirmation for risky operations', async () => {
    const t = makeEnv(); let asked = 0;
    t.env.confirm = () => { asked++; return false; };
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.board.byId('w-plugins').buttons('остановить')[0].dispatch('click', {}); await flush();
    assert.strictEqual(asked, 1);
    assert.ok(!t.calls.some(c => c.path === '/api/modules/kuni/stop'));
    t.env.confirm = () => true;   // confirm now allows it (env object is shared with the app)
    t.doc.board.byId('w-plugins').buttons('остановить')[0].dispatch('click', {}); await flush();
    assert.ok(t.calls.some(c => c.method === 'POST' && c.path === '/api/modules/kuni/stop'));
  });
  test('without env.confirm the in-panel confirmation dialog is used (cancel does nothing, confirm runs the action)', async () => {
    const t = makeEnv(); delete t.env.confirm;
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.board.byId('w-plugins').buttons('остановить')[0].dispatch('click', {});
    assert.strictEqual(t.doc.overlay.hidden, false);
    assert.ok(t.doc.overlay.textContent.includes('Подтверждение') && t.doc.overlay.textContent.includes('остановить kuni?'));
    t.doc.overlay.byId('confirm-no').dispatch('click', {}); await flush();
    assert.strictEqual(t.doc.overlay.hidden, true);
    assert.ok(!t.calls.some(c => c.path === '/api/modules/kuni/stop'));
    t.doc.board.byId('w-plugins').buttons('остановить')[0].dispatch('click', {});
    t.doc.overlay.byId('confirm-yes').dispatch('click', {}); await flush();
    assert.ok(t.calls.some(c => c.method === 'POST' && c.path === '/api/modules/kuni/stop'));
    assert.strictEqual(t.doc.overlay.hidden, true);
  });
  test('the black theme can be selected', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.topbar.byId('btn-settings').dispatch('click', {});
    const sel = t.doc.overlay.byId('s-theme');
    assert.ok(sel.children.some(o => o.value === 'black'), 'black option exists');
    sel.value = 'black';
    t.doc.overlay.byId('s-save').dispatch('click', {}); await flush(20);
    assert.strictEqual(t.getSettings().theme, 'black');
    assert.strictEqual(t.doc.body.className, 'theme-black');
  });
  test('threads connect the widgets, follow dragging and disappear with hidden widgets', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const key = th => th.a + '>' + th.b;
    const keys = a.S.threads.map(key);
    for (const k of ['system>plugins', 'plugins>log', 'plugins>m:demo_counter:counter', 'system>stats']) assert.ok(keys.includes(k), 'missing thread ' + k + ' in ' + keys.join(' '));
    assert.ok(a.S.threads.every(th => th.p.length === 4 && th.p.every(pt => pt.every(Number.isFinite))));
    const before = JSON.stringify(a.S.threads.find(th => th.b === 'log').p);
    t.doc.board.byId('w-log').byClass('wh')[0].dispatch('pointerdown', { clientX: 900, clientY: 500 });
    assert.strictEqual(a.S.dragId, 'log');
    t.doc.dispatch('pointermove', { clientX: 900 + 120, clientY: 500 + 90 });
    assert.notStrictEqual(JSON.stringify(a.S.threads.find(th => th.b === 'log').p), before, 'thread follows the dragged widget');
    t.doc.dispatch('pointerup', {}); await flush();
    assert.strictEqual(a.S.dragId, null);
    t.doc.board.byId('w-plugins').byClass('wx')[0].dispatch('click', {}); await flush();
    assert.ok(a.S.threads.every(th => th.a !== 'plugins' && th.b !== 'plugins'), 'no threads to a hidden widget');
    assert.doesNotThrow(() => a.drawThreads());
  });
  test('the canvas layer with threads is the first child of the board and is not a widget', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const first = t.doc.board.children[0];
    assert.strictEqual(first.tag, 'canvas'); assert.strictEqual(first.id, 'threads');
    assert.ok(first.width > 0 && first.height > 0);
    assert.strictEqual(t.doc.board.byClass('widget').length, 10);
  });
  test('stacked (phone) layout draws no threads', async () => {
    const t = makeEnv(); t.doc.board.rect.width = 500;
    const a = app.boot(t.env); await a.started; await flush();
    assert.deepStrictEqual(a.S.threads, []);
  });
  test('a pointer press creates a click effect and sends a shockwave along the threads of the clicked widget', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const body = t.doc.board.byId('w-plugins').byClass('wb')[0];
    const n0 = t.doc.body.children.length;
    t.doc.dispatch('pointerdown', { clientX: 120, clientY: 340, target: body });
    const fx = t.doc.body.children[t.doc.body.children.length - 1];
    assert.strictEqual(t.doc.body.children.length, n0 + 1);
    assert.strictEqual(fx.className, 'clickfx'); assert.strictEqual(fx.style.left, '120px'); assert.strictEqual(fx.style.top, '340px');
    assert.strictEqual(a.S.shock.id, 'plugins');
    t.doc.dispatch('pointerdown', { clientX: 5, clientY: 5 });   // мимо виджета: волны нет, кольцо есть
    assert.strictEqual(t.doc.body.children.length, n0 + 2);
    assert.doesNotThrow(() => a.drawThreads());
  });
  test('the spacing setting changes the gap between widgets', async () => {
    const wide = makeEnv({ settings: { gap: 40 } }), tight = makeEnv({ settings: { gap: 4 } });
    const a1 = app.boot(wide.env); await a1.started; await flush();
    const a2 = app.boot(tight.env); await a2.started; await flush();
    const w = e => parseFloat(e.doc.board.byId('w-system').style.width);
    assert.strictEqual(Math.round(w(tight) - w(wide)), 36);
    t_gap_dialog: {
      wide.doc.topbar.byId('btn-settings').dispatch('click', {});
      assert.strictEqual(wide.doc.overlay.byId('s-gap').value, 40);
      wide.doc.overlay.byId('s-gap').value = '22';
      wide.doc.overlay.byId('s-save').dispatch('click', {}); await flush(20);
      assert.strictEqual(wide.getSettings().gap, 22);
    }
  });
  test('architecture view: nodes become widgets (group and off classes), edges become labelled coloured threads', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    const widgets = t.doc.board.byClass('widget');
    assert.strictEqual(widgets.length, 4, 'only architecture nodes, no panel widgets');
    const text = widgets.map(w => w.textContent).join('\n');
    for (const x of ['Менеджер модулей', 'kuni', 'demo_tools', 'Каталог инструментов', 'установлено: 2', 'даёт: telegram.bot']) assert.ok(text.includes(x), 'missing ' + x);
    assert.ok(t.doc.board.byId('w-a:mod_kuni').classList.contains('grp-module'));
    assert.ok(t.doc.board.byId('w-a:manager').classList.contains('grp-manager'));
    assert.ok(t.doc.board.byId('w-a:mod_demo_tools').classList.contains('off'));
    assert.ok(!t.doc.board.byId('w-a:mod_kuni').classList.contains('off'));
    assert.strictEqual(a.S.threads.length, 3);
    const th = a.S.threads.find(x => x.b === 'a:mod_kuni');
    assert.deepStrictEqual([th.a, th.label, th.kind, th.off], ['a:manager', 'управляет', 'manage', false]);
    assert.strictEqual(a.S.threads.filter(x => x.off).length, 2);
    assert.ok(t.doc.topbar.byId('tab-arch').className.includes('active'));
    assert.ok(!t.doc.topbar.byId('tab-panel').className.includes('active'));
    assert.doesNotThrow(() => a.drawThreads());
  });
  test('architecture nodes take the recommended grid position unless a layout was saved', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    assert.deepStrictEqual(a.S.layout['a:manager'], { x: 10, y: 15, w: 4, h: 4 });
    assert.deepStrictEqual(a.S.layout['a:mod_kuni'], { x: 10, y: 10, w: 4, h: 4 });
    const cell = 1200 / 24;
    assert.strictEqual(parseFloat(t.doc.board.byId('w-a:manager').style.left), 10 * cell + 7);   // отступ по умолчанию 14: 7 px с каждой стороны
    const saved = makeEnv({ settings: { view: 'arch', layout: { 'a:manager': { x: 0, y: 0, w: 4, h: 4 } } } });
    const b = app.boot(saved.env); await b.started; await flush();
    assert.deepStrictEqual(b.S.layout['a:manager'], { x: 0, y: 0, w: 4, h: 4 });
    assert.deepStrictEqual(b.S.layout['a:mod_kuni'], { x: 10, y: 10, w: 4, h: 4 });
  });
  test('the tabs switch between the panel and the architecture and the choice is saved', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    assert.strictEqual(t.doc.board.byClass('widget').length, 10);
    t.doc.topbar.byId('tab-arch').dispatch('click', {}); await flush(40);
    assert.strictEqual(t.getSettings().view, 'arch');
    assert.strictEqual(t.doc.board.byClass('widget').length, 4);
    assert.ok(t.doc.board.byId('w-a:manager') && !t.doc.board.byId('w-system'));
    assert.ok(a.S.threads.every(x => x.a.indexOf('a:') === 0 && x.b.indexOf('a:') === 0));
    t.doc.topbar.byId('tab-panel').dispatch('click', {}); await flush(40);
    assert.strictEqual(t.getSettings().view, 'panel');
    assert.strictEqual(t.doc.board.byClass('widget').length, 10);
    assert.ok(a.S.threads.some(x => x.a === 'system' && x.b === 'plugins'));
  });
  test('dragging an architecture node keeps the saved layout of the panel widgets', async () => {
    const t = makeEnv({ settings: { layout: { system: { x: 3, y: 2, w: 8, h: 9 } } } });
    const a = app.boot(t.env); await a.started; await flush();
    t.doc.topbar.byId('tab-arch').dispatch('click', {}); await flush(40);
    t.doc.board.byId('w-a:manager').byClass('wh')[0].dispatch('pointerdown', { clientX: 600, clientY: 500 });
    t.doc.dispatch('pointermove', { clientX: 600 - 200, clientY: 500 - 120 });
    t.doc.dispatch('pointerup', {}); await flush();
    const saved = t.getSettings().layout;
    assert.deepStrictEqual(saved.system, { x: 3, y: 2, w: 8, h: 9 }, 'panel layout preserved');
    assert.ok(saved['a:manager'] && saved['a:manager'].x < 10, 'node moved left');
  });
  test('module nodes have the same buttons as the plugins list, with confirmation for risky actions', async () => {
    const t = makeEnv({ settings: { view: 'arch' } }); const asked = [];
    t.env.confirm = m => { asked.push(m); return true; };
    const a = app.boot(t.env); await a.started; await flush();
    const kuni = t.doc.board.byId('w-a:mod_kuni');
    for (const label of ['выключить', 'остановить', 'перезапустить']) assert.ok(kuni.buttons(label).length === 1, 'button ' + label);
    assert.ok(t.doc.board.byId('w-a:mod_demo_tools').buttons('включить').length === 1);
    kuni.buttons('остановить')[0].dispatch('click', {}); await flush(40);
    assert.deepStrictEqual(asked, ['остановить kuni?']);
    assert.ok(t.calls.some(c => c.method === 'POST' && c.path === '/api/modules/kuni/stop'));
    t.doc.board.byId('w-a:mod_demo_tools').buttons('включить')[0].dispatch('click', {}); await flush(40);
    assert.ok(t.calls.some(c => c.method === 'POST' && c.path === '/api/modules/demo_tools/enable'));
    assert.strictEqual(asked.length, 1, 'enabling is not risky');
  });
  test('refreshing the architecture updates node state, classes and threads', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    const g = t.data['/api/architecture'];
    g.nodes[2].status = 'ok'; g.nodes[2].enabled = true; g.nodes[2].health = 'healthy';
    g.edges.forEach(e => { e.off = false; });
    await a.syncArchitecture(); await flush();
    assert.ok(!t.doc.board.byId('w-a:mod_demo_tools').classList.contains('off'));
    assert.strictEqual(a.S.threads.filter(x => x.off).length, 0);
    g.nodes.push({ id: 'new', title: 'Новый узел', group: 'kernel', status: 'ok', lines: [], pos: { x: 0, y: 0, w: 4, h: 4 } });
    await a.syncArchitecture(); await flush();
    assert.ok(t.doc.board.byId('w-a:new'), 'a new node appears');
  });
  test('the architecture view on a phone is a plain list without threads', async () => {
    const t = makeEnv({ settings: { view: 'arch' } }); t.doc.board.rect.width = 500;
    const a = app.boot(t.env); await a.started; await flush();
    assert.strictEqual(t.doc.board.className, 'stack');
    assert.deepStrictEqual(a.S.threads, []);
    assert.strictEqual(t.doc.board.byClass('widget').length, 4);
  });
  test('the ticker re-syncs the architecture on schedule', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    const n0 = t.calls.filter(c => c.path === '/api/architecture').length;
    const origNow = Date.now; Date.now = () => origNow() + 60000;
    try { a.tick(); await flush(); } finally { Date.now = origNow; }
    assert.ok(t.calls.filter(c => c.path === '/api/architecture').length > n0);
  });
  test('live activity: an event sends a bright pulse along the matching thread in the right direction and flashes both nodes', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    t.data['/api/activity'] = { now: 600, events: [
      { t: 1, a: 'manager', b: 'mod_kuni', kind: 'manager', level: 'info', text: 'module.started kuni' },
      { t: 2, a: 'mod_kuni', b: 'manager', kind: 'manager', level: 'error', text: 'module.failed kuni' },
      { t: 3, a: 'nope', b: 'manager', kind: 'x', level: 'info', text: 'unknown node' }] };
    const n = await a.pollActivity();
    assert.strictEqual(n, 3);
    assert.strictEqual(a.S.activitySince, 600);
    assert.strictEqual(a.S.bursts.length, 2, 'the event for a missing thread is skipped');
    const fwd = a.S.bursts[0], back = a.S.bursts[1];
    assert.deepStrictEqual([fwd.a, fwd.b, fwd.forward, fwd.level], ['a:manager', 'a:mod_kuni', true, 'info']);
    assert.deepStrictEqual([back.a, back.b, back.forward, back.level], ['a:manager', 'a:mod_kuni', false, 'error'], 'reverse event runs backwards on the same thread');
    assert.ok(t.doc.board.byId('w-a:manager').classList.contains('flash'));
    assert.ok(t.doc.board.byId('w-a:mod_kuni').classList.contains('flash'));
    assert.doesNotThrow(() => a.drawThreads());
    assert.ok(t.calls.some(c => c.path === '/api/activity'));
  });
  test('live activity: pulses expire, the poll asks only for new events, and events are ignored in the panel view', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    t.data['/api/activity'] = { now: 700, events: [{ t: 1, a: 'manager', b: 'mod_kuni', kind: 'manager', level: 'info', text: 'x' }] };
    await a.pollActivity();
    assert.strictEqual(a.S.bursts.length, 1);
    const origNow = Date.now; Date.now = () => origNow() + 5000;
    try { a.drawThreads(); } finally { Date.now = origNow; }
    assert.strictEqual(a.S.bursts.length, 0, 'an old pulse is dropped');
    t.data['/api/activity'] = { now: 710, events: [] };
    await a.pollActivity();
    assert.ok(t.calls.filter(c => c.path.startsWith('/api/activity')).pop().path.includes('since=700'), 'asks only for events after the previous poll');
    const p = makeEnv();   // вид «Панель»: опроса активности нет
    const b = app.boot(p.env); await b.started; await flush();
    Date.now = () => origNow() + 60000;
    try { b.tick(); await flush(); } finally { Date.now = origNow; }
    assert.ok(!p.calls.some(c => c.path.startsWith('/api/activity')));
  });
  test('the ticker polls live activity on schedule in the architecture view', async () => {
    const t = makeEnv({ settings: { view: 'arch' } });
    const a = app.boot(t.env); await a.started; await flush();
    const n0 = t.calls.filter(c => c.path.startsWith('/api/activity')).length;
    const origNow = Date.now; Date.now = () => origNow() + 60000;
    try { a.tick(); await flush(); } finally { Date.now = origNow; }
    assert.ok(t.calls.filter(c => c.path.startsWith('/api/activity')).length > n0);
  });
  test('the ticker refreshes widgets on schedule and skips while the tab is hidden', async () => {
    const t = makeEnv();
    const a = app.boot(t.env); await a.started; await flush();
    const n0 = t.calls.length;
    t.doc.hidden = true; a.tick(); await flush();
    assert.strictEqual(t.calls.length, n0, 'hidden tab must not poll');
    t.doc.hidden = false;
    const origNow = Date.now; Date.now = () => origNow() + 60000;
    try { a.tick(); await flush(); } finally { Date.now = origNow; }
    assert.ok(t.calls.length > n0, 'visible tab polls again');
  });
};
