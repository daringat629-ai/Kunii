// Минимальная заглушка DOM: ровно столько, сколько использует панель. Проверяет логику, но не вёрстку.
class Node {
  constructor(tag) {
    this.tag = tag; this.children = []; this.parent = null; this.style = {}; this.listeners = {}; this.attrs = {};
    this.className = ''; this._text = ''; this.hidden = false; this.value = ''; this.scrollTop = 0; this.scrollHeight = 0;
    this.id = ''; this.rect = { width: 1200, height: 800, left: 0, top: 0 };
    const self = this;
    this.classList = {
      _list() { return self.className.split(/\s+/).filter(Boolean); },
      add(c) { const l = this._list(); if (!l.includes(c)) { l.push(c); self.className = l.join(' '); } },
      remove(c) { self.className = this._list().filter(x => x !== c).join(' '); },
      contains(c) { return this._list().includes(c); },
    };
  }
  get firstChild() { return this.children[0] || null; }
  appendChild(c) { if (c.parent) c.parent.removeChild(c); c.parent = this; this.children.push(c); return c; }
  removeChild(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); c.parent = null; return c; }
  setAttribute(k, v) { this.attrs[k] = v; if (k === 'id') this.id = v; }
  addEventListener(ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); }
  removeEventListener(ev, fn) { this.listeners[ev] = (this.listeners[ev] || []).filter(f => f !== fn); }
  dispatch(ev, payload) { (this.listeners[ev] || []).slice().forEach(fn => fn(Object.assign({ target: this, preventDefault() {} }, payload))); }
  set textContent(v) { this.children = []; this._text = String(v); }
  get textContent() { return this._text + this.children.map(c => c.textContent).join(''); }
  getBoundingClientRect() { return this.rect; }
  getContext() { return new Proxy({}, { get: (t, k) => (k in t ? t[k] : () => {}), set: (t, k, v) => { t[k] = v; return true; } }); }
  all(pred, out = []) { if (pred(this)) out.push(this); this.children.forEach(c => c.all && c.all(pred, out)); return out; }
  byClass(cls) { return this.all(n => n.classList && n.classList.contains(cls)); }
  byId(id) { return this.all(n => n.id === id)[0] || null; }
  buttons(text) { return this.all(n => n.tag === 'button' && n.textContent === text); }
}
class Text extends Node { constructor(t) { super('#text'); this._text = String(t); } }
class Document {
  constructor() {
    this.body = new Node('body');
    this.topbar = this.body.appendChild(Object.assign(new Node('header'), { id: 'topbar' }));
    this.board = this.body.appendChild(Object.assign(new Node('main'), { id: 'board' }));
    this.overlay = this.body.appendChild(Object.assign(new Node('div'), { id: 'overlay', hidden: true }));
    this.hidden = false; this.listeners = {};
  }
  createElement(t) { return new Node(t); }
  createTextNode(t) { return new Text(t); }
  getElementById(id) { return this.body.byId(id); }
  addEventListener(ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); }
  removeEventListener(ev, fn) { this.listeners[ev] = (this.listeners[ev] || []).filter(f => f !== fn); }
  dispatch(ev, payload) { (this.listeners[ev] || []).slice().forEach(fn => fn(Object.assign({ preventDefault() {} }, payload))); }
}
module.exports = { Node, Document };
