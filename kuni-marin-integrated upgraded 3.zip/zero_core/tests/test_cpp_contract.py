"""Сквозной контракт: каталог, записанный менеджером, читается и выполняется настоящим кодом ядра kuni (C++).
Нужны g++ и исходники kuni: путь в переменной KUNI_SRC (каталог src) или один из типовых. Иначе тесты пропускаются."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from helpers import ROOT, Env

PY = sys.executable


def find_kuni_src():
    candidates = [os.environ.get("KUNI_SRC"), str(ROOT.parent / "src"), "/home/claude/kuni_src/src", str(ROOT.parent / "kuni-marin-integrated" / "src"),
                  str(Path.home() / "kuni-marin-integrated" / "src")]
    for c in candidates:
        if c and (Path(c) / "util" / "external_tools.cpp").is_file():
            return Path(c)
    return None


SRC = find_kuni_src()


@unittest.skipUnless(shutil.which("g++") and SRC, "нет g++ или исходников kuni с рантаймом внешних инструментов (KUNI_SRC)")
class CppContractTests(Env):
    harness = None

    @classmethod
    def setUpClass(cls):
        cls.build_dir = Path(tempfile.mkdtemp(prefix="zc_cpp_"))
        cls.harness = cls.build_dir / "harness"
        cmd = ["g++", "-std=c++20", "-O1", "-pthread", f"-I{SRC}", str(ROOT / "tests" / "cpp" / "contract_harness.cpp"),
               str(SRC / "util" / "json_lite.cpp"), str(SRC / "util" / "external_tools.cpp"),
               str(SRC / "util" / "process_runner.cpp"), "-o", str(cls.harness)]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise RuntimeError("не удалось собрать контрактную программу:\n" + r.stderr[-2000:])

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.build_dir, ignore_errors=True)

    def run_tool(self, name, args="{}"):
        r = subprocess.run([str(self.harness), str(self.mgr.tools_path()), name, args], capture_output=True, text=True, timeout=30)
        self.assertEqual(r.returncode, 0, r.stderr)
        return r.stdout

    def listing(self):
        r = subprocess.run([str(self.harness), str(self.mgr.tools_path()), "--list"], capture_output=True, text=True, timeout=30)
        return r.returncode, r.stdout.split(), r.stderr

    def enable_demo(self):
        self.mgr.install(ROOT / "modules" / "demo_tools")
        self.mgr.enable("demo_tools")

    def test_the_catalog_written_by_the_manager_is_accepted_without_errors(self):
        self.enable_demo()
        rc, names, err = self.listing()
        self.assertEqual((rc, err), (0, ""))
        self.assertEqual(names, ["demo_echo", "demo_add"])

    def test_tools_really_run_through_the_core_code(self):
        self.enable_demo()
        self.assertEqual(self.run_tool("demo_echo", json.dumps({"text": "привет мир"}, ensure_ascii=False)), "привет мир")
        self.assertEqual(self.run_tool("demo_add", '{"a": 3, "b": 4}'), "7")
        self.assertEqual(self.run_tool("demo_add", '{"a": "3", "b": 4}'), "7")   # "3" вместо 3: типичная ошибка моделей
        self.assertEqual(self.run_tool("demo_add", '{"a": 7.576e+08, "b": 1}'), "757600001")

    def test_argument_errors_never_start_a_process(self):
        self.enable_demo()
        self.assertIn('missing required argument "b"', self.run_tool("demo_add", '{"a": 1}'))
        self.assertIn('unknown argument "zzz"', self.run_tool("demo_add", '{"a": 1, "b": 2, "zzz": 3}'))
        self.assertIn("must be an integer", self.run_tool("demo_add", '{"a": 1.5, "b": 2}'))
        self.assertIn("not valid JSON", self.run_tool("demo_add", "{oops"))

    def test_arguments_are_data_not_shell_code(self):
        self.enable_demo()
        marker = self.tmp / "pwned"
        text = f"$(touch {marker}); `touch {marker}`; echo 'x' && touch {marker}"
        self.assertEqual(self.run_tool("demo_echo", json.dumps({"text": text})), text)
        self.assertFalse(marker.exists())

    def test_environment_and_working_directory_match_the_manager(self):
        script = "import os, json; print(json.dumps({'module': os.environ['ZEROCORE_MODULE'], 'data': os.environ['ZEROCORE_DATA_DIR'], 'api': os.environ['ZEROCORE_API'], 'cwd': os.getcwd()}))"
        self.inst("envmod", kind="library", files={"tool.py": script},
                  tools=[{"name": "show_env", "description": "env", "command": [PY, "${module_dir}/tool.py"]}])
        self.mgr.enable("envmod")
        out = json.loads(self.run_tool("show_env"))
        self.assertEqual(out["module"], "envmod")
        self.assertEqual(out["data"], str(self.mgr.home / "data" / "envmod"))
        self.assertEqual(out["api"], "1")
        self.assertEqual(os.path.realpath(out["cwd"]), os.path.realpath(self.mgr.module_dir("envmod")))

    def test_failures_timeouts_and_limits_are_reported_to_the_llm(self):
        files = {"fail.py": "import sys; print('partial'); sys.stderr.write('oops'); sys.exit(3)",
                 "slow.py": "import time; print('before', flush=True); time.sleep(20)",
                 "big.py": "print('x' * 5000)"}
        tools = [{"name": "t_fail", "description": "d", "command": [PY, "${module_dir}/fail.py"]},
                 {"name": "t_slow", "description": "d", "command": [PY, "${module_dir}/slow.py"], "timeout_seconds": 1},
                 {"name": "t_big", "description": "d", "command": [PY, "${module_dir}/big.py"], "max_output_bytes": 200},
                 {"name": "t_missing", "description": "d", "command": ["/нет/такой/программы"]}]
        self.inst("fails", kind="library", files=files, tools=tools)
        self.mgr.enable("fails")
        out = self.run_tool("t_fail")
        self.assertTrue(out.startswith("error: the tool exited with code 3"), out)
        self.assertIn("partial", out)
        slow = self.run_tool("t_slow")
        self.assertIn("before", slow)
        self.assertIn("[timed out after 1 s", slow)
        big = self.run_tool("t_big")
        self.assertIn("[output truncated]", big)
        self.assertLessEqual(len(big), 200 + len("\n[output truncated]"))
        missing = self.run_tool("t_missing")   # с рабочим каталогом запуск идёт через sh: код 127 и понятный текст
        self.assertTrue(missing.startswith("error: the tool exited with code 127"), missing)
        self.assertIn("/нет/такой/программы", missing)

    def test_hot_swap_changes_what_the_core_executes_without_any_rebuild(self):
        def module(version):
            return {"tool.py": f"import json,sys; a=json.load(sys.stdin)['arguments']; print('v{version}:' + a['text'])"}
        self.inst("hot", version="1.0.0", kind="library", files=module(1), tools=[tool("hot_tool")])
        self.inst("hot", version="2.0.0", kind="library", files=module(2), tools=[tool("hot_tool")])
        self.mgr.enable("hot")
        self.assertEqual(self.run_tool("hot_tool", '{"text": "hi"}'), "v1:hi")
        self.mgr.swap("hot", "2.0.0")
        self.assertEqual(self.run_tool("hot_tool", '{"text": "hi"}'), "v2:hi")
        self.mgr.rollback("hot")
        self.assertEqual(self.run_tool("hot_tool", '{"text": "hi"}'), "v1:hi")
        self.mgr.disable("hot")
        r = subprocess.run([str(self.harness), str(self.mgr.tools_path()), "hot_tool", "{}"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 3)   # инструмента больше нет


def tool(name):
    return {"name": name, "description": "d", "parameters": {"text": {"type": "string"}}, "required": ["text"],
            "command": [PY, "${module_dir}/tool.py"]}


if __name__ == "__main__":
    unittest.main()
