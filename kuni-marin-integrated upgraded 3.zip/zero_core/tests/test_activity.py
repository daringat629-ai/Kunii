import os
import time
import unittest

from helpers import ROOT, Env
from test_admin import PanelBase
from zerocore.admin import activity, architecture

ALL = ("kuni", "watchdog", "webview", "world_v2", "demo_counter", "demo_tools")


def hhmmss(t):
    return time.strftime("%H:%M:%S", time.localtime(t))


class ActivityMappingTests(Env):
    def setUp(self):
        super().setUp()
        self.logs = self.tmp / "logs"
        self.logs.mkdir()
        self.console = self.tmp / "aui.1.log"
        self.console.write_text("")

    def collect(self, since, now=None):
        return activity.collect(self.mgr, str(self.logs), str(self.console), since, now or time.time())

    def test_manager_events_run_along_manager_to_module_threads(self):
        t0 = time.time() - 1
        self.mgr.emit("module.started", module="kuni")
        self.mgr.emit("module.failed", module="webview", error="boom")
        self.mgr.emit("tools.exported", count=2, problems=0)
        self.mgr.emit("config.changed", module="kuni")
        ev = self.collect(t0)["events"]
        pairs = {(e["a"], e["b"], e["level"]) for e in ev}
        self.assertIn(("manager", "mod_kuni", "info"), pairs)
        self.assertIn(("manager", "mod_webview", "error"), pairs)      # сбой помечен как ошибка
        self.assertIn(("manager", "catalog", "info"), pairs)
        self.assertIn(("manager", "lifecycle", "info"), pairs)
        self.assertIn(("manager", "state", "info"), pairs)

    def test_since_filters_out_old_events(self):
        self.mgr.emit("module.started", module="kuni")
        time.sleep(0.05)
        cut = time.time()
        time.sleep(0.05)
        self.mgr.emit("module.stopped", module="kuni")
        texts = [e["text"] for e in self.collect(cut)["events"]]
        self.assertTrue(any("module.stopped" in t for t in texts))
        self.assertFalse(any("module.started" in t for t in texts))

    def test_console_lines_become_traffic_on_the_right_threads(self):
        now = time.time()
        t0 = now - 20
        self.console.write_text(
            f"[{hhmmss(now - 5)}][UI thread][send_telegram_message][INFO]: Synthetic typing delay: 1200ms\n"
            f"[{hhmmss(now - 4)}][UI thread][App][INFO]: Processing notification: You received a direct message\n"
            f"[{hhmmss(now - 3)}][UI thread][tools::shell][WARN]: EXEC: ls -la /tmp\n"
            f"[{hhmmss(now - 3)}][UI thread][tools::external][INFO]: CALL demo_tools/demo_add\n"
            f"[{hhmmss(now - 2)}][UI thread][OpenAITools][WARN]: tool call refused: Refused: x\n"
            f"[{hhmmss(now - 2)}][UI thread][OpenAIChat][WARN]: chatStreaming: status=HTTP_429_TOO_MANY_REQUESTS\n"
            f"[{hhmmss(now - 1)}][UI thread][tools::external][INFO]: Loaded 2 external tool(s): a, b\n"
            f"[{hhmmss(now - 1)}][UI thread][Performance][WARN]: Execution of a task took 2000us\n")
        ev = self.collect(t0, now)["events"]
        pairs = {(e["a"], e["b"], e["kind"], e["level"]) for e in ev}
        self.assertIn(("k_telegram", "telegram", "message", "info"), pairs)
        self.assertIn(("telegram", "k_telegram", "message", "info"), pairs)
        self.assertIn(("k_cognition", "k_tools", "tool", "info"), pairs)
        self.assertIn(("k_tools", "catalog", "tools", "info"), pairs)
        self.assertIn(("k_cognition", "k_tools", "guard", "error"), pairs)
        self.assertIn(("k_cognition", "llm", "llm", "error"), pairs)
        self.assertIn(("catalog", "k_tools", "tools", "info"), pairs)
        texts = " | ".join(e["text"] for e in ev)
        self.assertIn("shell: ls -la /tmp", texts)
        self.assertIn("инструмент demo_tools/demo_add", texts)
        self.assertNotIn("Performance", texts)   # шум замеров не событие

    def test_old_console_lines_are_ignored(self):
        now = time.time()
        self.console.write_text(f"[{hhmmss(now - 100)}][UI thread][tools::shell][WARN]: EXEC: old\n")
        self.assertEqual([e for e in self.collect(now - 10, now)["events"] if e["kind"] == "tool"], [])

    def test_new_llm_log_files_are_llm_traffic(self):
        old = self.logs / "2026-01-01 00:00:00.1.0query.json"
        old.write_text("{}")
        os.utime(old, (time.time() - 500, time.time() - 500))
        since = time.time() - 5
        (self.logs / "2026-10-09 10:00:00.1.0query.json").write_text("{}")
        (self.logs / "2026-10-09 10:00:00.1.1response.json").write_text("{}")
        ev = self.collect(since)["events"]
        self.assertEqual(sorted(e["text"] for e in ev if e["kind"] == "llm"), ["запрос к LLM", "ответ LLM"])
        self.assertTrue(all((e["a"], e["b"]) == ("k_cognition", "llm") for e in ev if e["kind"] == "llm"))

    def test_sorted_deduplicated_and_limited(self):
        now = time.time()
        line = f"[{hhmmss(now - 2)}][UI thread][tools::shell][WARN]: EXEC: same\n"
        self.console.write_text(line * 5)
        ev = [e for e in self.collect(now - 10, now)["events"] if e["kind"] == "tool"]
        self.assertEqual(len(ev), 1, "одинаковые события схлопываются")
        for i in range(80):
            self.mgr.emit("config.changed", module=f"m{i}")
        got = self.collect(now - 10, now)["events"]
        self.assertLessEqual(len(got), activity.LIMIT)
        self.assertEqual([e["t"] for e in got], sorted(e["t"] for e in got))

    def test_missing_sources_do_not_break_collection(self):
        self.assertEqual(activity.collect(self.mgr, "/nonexistent", "/nonexistent.log", 0, time.time())["events"], [])
        self.assertEqual(activity.collect(self.mgr, None, None, time.time() + 100, time.time())["events"], [])

    def test_every_mapped_pair_has_a_real_thread_on_the_architecture(self):
        """Импульс должен было по чему бежать: пара узлов из события обязана быть настоящей связью схемы."""
        for m in ALL:
            self.mgr.install(ROOT / "modules" / m)
        graph = architecture.build(self.mgr)
        threads = {frozenset((e["a"], e["b"])) for e in graph["edges"]}
        ids = {n["id"] for n in graph["nodes"]}
        now = time.time()
        self.console.write_text("".join(f"[{hhmmss(now - 1)}][UI thread]{rest}\n" for rest in (
            "[send_telegram_message][INFO]: Synthetic typing delay: 1ms", "[App][INFO]: Processing notification: x", "[tools::shell][WARN]: EXEC: x",
            "[tools::external][INFO]: CALL a/b", "[tools::external][INFO]: Loaded 1 external tool(s): a", "[OpenAITools][WARN]: tool call refused: x",
            "[OpenAIChat][WARN]: chatStreaming: status=HTTP_500")))
        (self.logs / "x.0query.json").write_text("{}")
        for topic, payload in (("module.installed", {"module": "kuni"}), ("module.swapped", {"module": "kuni"}), ("module.failed", {"module": "webview"}),
                               ("module.started", {"module": "watchdog"}), ("health.changed", {"module": "kuni"}), ("tools.exported", {}), ("config.changed", {"module": "kuni"}),
                               ("integrity.broken", {}), ("swap.failed", {"module": "kuni"}), ("job.failed", {"module": "watchdog"}), ("module.uninstalled", {"module": "demo_tools"})):
            self.mgr.emit(topic, **payload)
        events = self.collect(now - 30, now)["events"]
        self.assertGreater(len(events), 15)
        for e in events:
            self.assertIn(e["a"], ids, e)
            self.assertIn(e["b"], ids, e)
            self.assertIn(frozenset((e["a"], e["b"])), threads, f"нет нити для {e}")


class ActivityApiTests(PanelBase):
    def test_endpoint_needs_a_token_and_returns_recent_events(self):
        self.assertEqual(self.get("/api/activity", token=None)[0], 401)
        self.mgr.emit("module.started", module="kuni")
        code, d = self.get("/api/activity?since=0")
        self.assertEqual(code, 200)
        self.assertIn("now", d)
        self.assertTrue(any(e["a"] == "manager" and e["b"] == "mod_kuni" for e in d["events"]))

    def test_since_is_clamped_and_garbage_is_tolerated(self):
        self.assertEqual(self.get("/api/activity?since=abc")[0], 200)
        d = self.get("/api/activity?since=-5")[1]   # не дальше 5 минут назад
        self.assertTrue(all(e["t"] >= d["now"] - 301 for e in d["events"]))
        future = self.get(f"/api/activity?since={time.time() + 1e6}")[1]
        self.assertEqual(future["events"], [])


if __name__ == "__main__":
    unittest.main()
