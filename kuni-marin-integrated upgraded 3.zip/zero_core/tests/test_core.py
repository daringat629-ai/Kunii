import json
import os
import signal
import sqlite3
import sys
import textwrap
import time
import unittest
from pathlib import Path

from helpers import ROOT, Env, make_module
from zerocore.kernel import migrations, permissions
from zerocore.kernel.contracts import Manifest, satisfies, validate_manifest
from zerocore.kernel.errors import (ConflictError, ContractError, DependencyError, LifecycleError, ZeroCoreError,
                                  MigrationError, PermissionDenied)
from zerocore.kernel.event_bus import EventBus
from zerocore.kernel.lifecycle import ProcessRunner, wait_until
from zerocore.module_manager import dependency_solver as solver
from zerocore.module_manager import discovery

GOOD = {"api": "1", "name": "demo", "version": "1.0.0", "kind": "library"}


def man(name, version="1.0.0", provides=(), requires=(), depends=None, conflicts=()):
    return Manifest.from_dict({"api": "1", "name": name, "version": version, "kind": "library",
                               "provides": list(provides), "requires": list(requires), "depends": depends or {},
                               "conflicts": list(conflicts)})


class ContractTests(unittest.TestCase):
    """Контрактные: все модули соответствуют общему API."""

    def test_shipped_modules_conform(self):
        found, errors = discovery.discover(ROOT / "modules")
        self.assertEqual(errors, [])
        self.assertEqual(set(found), {"kuni", "world_v2", "webview", "watchdog", "demo_counter", "demo_tools"})

    def test_valid_minimal(self):
        self.assertEqual(validate_manifest(GOOD), [])

    def test_invalid_variants(self):
        bad = [
            ({**GOOD, "name": "Bad Name"}, "name"),
            ({**GOOD, "version": "v1"}, "version"),
            ({**GOOD, "extra": 1}, "неизвестное поле"),
            ({**GOOD, "api": "2"}, "api"),
            ({**GOOD, "kind": "job", "run": {"command": ["x"]}}, "schedule_seconds"),
            ({**GOOD, "kind": "service"}, "run.command"),
            ({**GOOD, "kind": "external", "run": {}}, "start_command"),
            ({**GOOD, "provides": ["nodot"]}, "формат группа.имя"),
            ({**GOOD, "depends": {"a": "~1"}}, "ограничение"),
            ({**GOOD, "health": {"type": "http"}}, "health.url"),
            ({**GOOD, "health": {"type": "magic"}}, "health.type"),
            ({**GOOD, "limits": {"memory_mb": -1}}, "limits"),
            ({**GOOD, "run": {"zzz": 1}}, "неизвестное поле zzz"),
            ({**GOOD, "permissions": {"root": True}}, "permissions"),
            ("не объект", "объект"),
        ]
        for d, frag in bad:
            errs = " | ".join(validate_manifest(d))
            self.assertIn(frag, errs, d)
            if isinstance(d, dict):
                with self.assertRaises(ContractError):
                    Manifest.from_dict(d)

    def test_version_constraints(self):
        self.assertTrue(satisfies("1.2.0", ">=1.0,<2.0"))
        self.assertFalse(satisfies("2.0.0", ">=1.0,<2.0"))
        self.assertTrue(satisfies("1", "==1.0.0"))
        self.assertFalse(satisfies("1.0.1", "!=1.0.1"))
        with self.assertRaises(ContractError):
            satisfies("1.0", "latest")


class SolverTests(unittest.TestCase):
    """Зависимостей: несовместимые версии и циклы обнаруживаются."""

    def test_order_dependencies_first(self):
        ms = {"a": man("aa", provides=["x.a"]), "b": man("bb", requires=["x.a"], provides=["x.b"]),
              "c": man("cc", requires=["x.b"])}
        ms = {m.name: m for m in ms.values()}
        order = solver.solve(ms)
        self.assertLess(order.index("aa"), order.index("bb"))
        self.assertLess(order.index("bb"), order.index("cc"))

    def test_missing_capability_and_module(self):
        with self.assertRaisesRegex(DependencyError, "нет модуля, предоставляющего x.y"):
            solver.solve({"aa": man("aa", requires=["x.y"])})
        with self.assertRaisesRegex(DependencyError, "не включён"):
            solver.solve({"aa": man("aa", depends={"bb": ">=1.0"})})

    def test_version_mismatch(self):
        ms = {"aa": man("aa", depends={"bb": ">=2.0"}), "bb": man("bb", version="1.5.0")}
        with self.assertRaisesRegex(DependencyError, "включена версия 1.5.0"):
            solver.solve(ms)

    def test_cycle_detected(self):
        ms = {"aa": man("aa", provides=["x.a"], requires=["x.b"]), "bb": man("bb", provides=["x.b"], requires=["x.a"])}
        with self.assertRaisesRegex(DependencyError, "циклическая"):
            solver.solve(ms)

    def test_duplicate_capability_conflict(self):
        ms = {"aa": man("aa", provides=["x.same"]), "bb": man("bb", provides=["x.same"])}
        with self.assertRaisesRegex(ConflictError, "несколько модулей"):
            solver.solve(ms)

    def test_declared_conflict(self):
        with self.assertRaises(ConflictError):
            solver.solve({"aa": man("aa", conflicts=["bb"]), "bb": man("bb")})

    def test_dependents_transitive(self):
        ms = {m.name: m for m in (man("aa", provides=["x.a"]), man("bb", requires=["x.a"], provides=["x.b"]),
                                  man("cc", requires=["x.b"]), man("dd"))}
        self.assertEqual(solver.dependents("aa", ms), {"bb", "cc"})


class LifecycleTests(Env):
    """Жизненного цикла и нагрузки: старт и остановка не оставляют процессов."""

    def runner(self):
        return ProcessRunner(self.tmp / "run")

    @staticmethod
    def group_members(pgid):
        """Живые (не зомби) процессы группы pgid."""
        out = []
        for d in os.listdir("/proc"):
            if d.isdigit():
                try:
                    with open(f"/proc/{d}/stat") as f:
                        rest = f.read().rsplit(")", 1)[1].split()
                except OSError:
                    continue
                if int(rest[2]) == pgid and rest[0] != "Z":
                    out.append(int(d))
        return out

    def script(self, body):
        p = self.tmp / "s.py"
        p.write_text(textwrap.dedent(body))
        return [sys.executable, str(p)]

    def test_start_stop_leaves_no_processes(self):
        r = self.runner()
        sh = ["bash", "-c", "sleep 100 & sleep 100 & wait"]  # порождает потомков
        pid = r.start("t", sh, self.tmp, dict(os.environ))
        time.sleep(0.2)
        self.assertGreaterEqual(len(self.group_members(pid)), 3)  # bash и два sleep
        self.assertEqual(r.stop("t", 3), "graceful")
        self.assertTrue(wait_until(lambda: not self.group_members(pid), 3), "в группе остались живые процессы")
        self.assertIsNone(r.pid("t"))

    def test_hung_process_is_killed_after_timeout(self):
        r = self.runner()
        argv = self.script("import signal,time\nsignal.signal(signal.SIGTERM, signal.SIG_IGN)\nwhile True: time.sleep(0.1)")
        pid = r.start("h", argv, self.tmp, dict(os.environ))
        time.sleep(0.3)
        t0 = time.time()
        self.assertEqual(r.stop("h", 1.0), "killed")
        self.assertLess(time.time() - t0, 4)
        self.assertFalse(self.alive(pid))

    def test_stale_pidfile_cleaned_and_double_start_refused(self):
        r = self.runner()
        r.pidfile("x").write_text("999999")
        self.assertIsNone(r.pid("x"))
        self.assertFalse(r.pidfile("x").exists())
        r.start("x", ["sleep", "30"], self.tmp, dict(os.environ))
        with self.assertRaises(LifecycleError):
            r.start("x", ["sleep", "30"], self.tmp, dict(os.environ))
        r.stop("x", 2)

    def test_missing_executable_is_lifecycle_error(self):
        with self.assertRaises(LifecycleError):
            self.runner().start("n", ["/нет/такого"], self.tmp, dict(os.environ))

    def test_cpu_limit_kills_runaway(self):
        r = self.runner()
        argv = self.script("while True: pass")
        pid = r.start("cpu", argv, self.tmp, dict(os.environ), limits={"cpu_seconds": 1})
        self.assertTrue(wait_until(lambda: r.pid("cpu") is None, 6), "лимит CPU не остановил процесс")

    def test_open_files_limit_applies(self):
        r = self.runner()
        argv = self.script("import resource,sys\nsys.stdout.write(str(resource.getrlimit(resource.RLIMIT_NOFILE)[0]))")
        r.start("lim", argv, self.tmp, dict(os.environ), limits={"open_files": 77})
        time.sleep(0.5)
        self.assertEqual(r.log_tail("lim").strip()[-2:], "77")


class EventBusTests(Env):
    """Нагрузки: очереди ограничены; события доставляются без дублей."""

    def test_backlog_is_capped(self):
        bus = EventBus(self.mgr.home / "zerocore.db", max_events=50)
        for i in range(120):
            bus.publish("t.x", {"i": i})
        ev = bus.recent(1000)
        self.assertLessEqual(len(ev), 50 + 20)  # плюс события менеджера
        self.assertEqual(ev[-1]["payload"]["i"], 119)

    def test_payload_limit(self):
        with self.assertRaises(ZeroCoreError):
            self.mgr.bus.publish("big", {"x": "я" * 70000})

    def test_cursor_ack_no_duplicates_and_filter(self):
        bus = self.mgr.bus
        bus.poll("c1")  # прочитать накопленное
        bus.publish("a.one", {"n": 1})
        bus.publish("b.two", {"n": 2})
        bus.publish("a.three", {"n": 3})
        got = bus.poll("c1", topics=["a."])
        self.assertEqual([e["payload"]["n"] for e in got], [1, 3])
        self.assertEqual(bus.poll("c1", topics=["a."]), [])
        bus.publish("a.four", {"n": 4})
        self.assertEqual([e["payload"]["n"] for e in bus.poll("c1", topics=["a."])], [4])


class MigrationTests(Env):
    """Базы данных: миграции, транзакции и восстановление."""

    def test_idempotent(self):
        d = self.tmp / "mig"
        d.mkdir()
        (d / "001_a.sql").write_text("CREATE TABLE a(x INTEGER);")
        db = self.tmp / "m.db"
        self.assertEqual(migrations.apply(db, d), ["001_a.sql"])
        self.assertEqual(migrations.apply(db, d), [])

    def test_failure_rolls_back_only_failed_file(self):
        d = self.tmp / "mig2"
        d.mkdir()
        (d / "001_ok.sql").write_text("CREATE TABLE ok(x INTEGER);")
        (d / "002_bad.sql").write_text("CREATE TABLE half(x INTEGER);\nINSERT INTO нет_такой(x) VALUES(1);")
        db = self.tmp / "m2.db"
        with self.assertRaisesRegex(MigrationError, "002_bad.sql"):
            migrations.apply(db, d)
        c = sqlite3.connect(db)
        tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        self.assertIn("ok", tables)
        self.assertNotIn("half", tables)  # частично выполненная миграция откатана
        self.assertEqual([r[0] for r in c.execute("SELECT version FROM schema_migrations")], ["001_ok.sql"])
        c.close()
        (d / "002_bad.sql").write_text("CREATE TABLE fixed(x INTEGER);")
        self.assertEqual(migrations.apply(db, d), ["002_bad.sql"])  # после исправления доезжает

    def test_database_unavailable_during_migration(self):
        d = self.tmp / "mig3"
        d.mkdir()
        (d / "001_a.sql").write_text("CREATE TABLE a(x INTEGER);")
        db = self.tmp / "m3.db"
        migrations.apply(db, d)
        (d / "002_b.sql").write_text("CREATE TABLE b(x INTEGER);")
        blocker = sqlite3.connect(db, isolation_level=None)
        blocker.execute("BEGIN EXCLUSIVE")
        try:
            with self.assertRaises(MigrationError):
                migrations.apply(db, d, timeout=0.3)
        finally:
            blocker.execute("ROLLBACK")
            blocker.close()
        self.assertEqual(migrations.apply(db, d), ["002_b.sql"])


class PermissionTests(Env):
    """Изоляции: один модуль не читает запрещённые данные другого."""

    def test_data_path_traversal_and_symlink_denied(self):
        home = self.mgr.home
        (home / "data" / "aa").mkdir(parents=True)
        (home / "data" / "bb").mkdir(parents=True)
        (home / "data" / "bb" / "secret.txt").write_text("s")
        ok = permissions.resolve_data_path(home, "aa", "file.txt")
        self.assertTrue(str(ok).startswith(str(home / "data" / "aa")))
        with self.assertRaises(PermissionDenied):
            permissions.resolve_data_path(home, "aa", "../bb/secret.txt")
        os.symlink(home / "data" / "bb", home / "data" / "aa" / "link")
        with self.assertRaises(PermissionDenied):
            permissions.resolve_data_path(home, "aa", "link/secret.txt")

    def test_shared_requires_declared_read(self):
        owner = Manifest.from_dict({"api": "1", "name": "owner", "version": "1", "kind": "library",
                                    "provides": ["owner.data"]})
        reader_ok = Manifest.from_dict({"api": "1", "name": "readerok", "version": "1", "kind": "library",
                                        "permissions": {"read": ["owner.data"]}})
        reader_no = Manifest.from_dict({"api": "1", "name": "readerno", "version": "1", "kind": "library"})
        home = self.mgr.home
        (home / "data" / "owner" / "shared").mkdir(parents=True)
        p = permissions.resolve_shared_path(home, reader_ok, owner, "a.json")
        self.assertIn("shared", str(p))
        with self.assertRaises(PermissionDenied):
            permissions.resolve_shared_path(home, reader_no, owner, "a.json")
        with self.assertRaises(PermissionDenied):
            permissions.resolve_shared_path(home, reader_ok, owner, "../private.txt")


if __name__ == "__main__":
    unittest.main()
