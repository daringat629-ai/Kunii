import json
import os
import stat
import sys
import time
import unittest

from helpers import ROOT, Env, make_module
from zerocore.kernel.contracts import validate_manifest
from zerocore.kernel.errors import ContractError
from zerocore.module_manager.manager import Manager

PY = sys.executable
BASE = {"api": "1", "name": "demo", "version": "1.0.0", "kind": "library"}
GOOD_TOOL = {"name": "my_tool", "description": "Does it", "parameters": {"a": {"type": "integer", "description": "x"}},
             "required": ["a"], "command": ["python3", "t.py"], "timeout_seconds": 5, "max_output_bytes": 500}


def tool(name="tool_one", text="t1", extra=None, script="print('x')"):
    t = {"name": name, "description": text, "parameters": {"text": {"type": "string", "description": "d"}},
         "required": ["text"], "command": [PY, "${module_dir}/tool.py"]}
    t.update(extra or {})
    return t


class ToolContractTests(unittest.TestCase):
    def errs(self, tools):
        return " | ".join(validate_manifest({**BASE, "tools": tools}))

    def test_valid(self):
        self.assertEqual(self.errs([GOOD_TOOL]), "")
        self.assertEqual(self.errs([{"name": "ab", "description": "d", "command": ["x"]}]), "")   # параметры необязательны

    def test_invalid_variants(self):
        bad = [
            ([{**GOOD_TOOL, "name": "Bad-Name"}], "name"),
            ([{**GOOD_TOOL, "name": "a"}], "name"),
            ([{**GOOD_TOOL, "description": ""}], "description"),
            ([{**GOOD_TOOL, "parameters": {"p": {"type": "array"}}}], "parameters.p"),
            ([{**GOOD_TOOL, "parameters": {"Bad Name": {"type": "string"}}}], "недопустимое имя"),
            ([{**GOOD_TOOL, "required": ["zzz"]}], "required"),
            ([{**GOOD_TOOL, "command": []}], "command"),
            ([{**GOOD_TOOL, "command": [""]}], "command"),
            ([{**GOOD_TOOL, "command": "rm -rf /"}], "command"),
            ([{**GOOD_TOOL, "timeout_seconds": 0}], "timeout_seconds"),
            ([{**GOOD_TOOL, "timeout_seconds": 301}], "timeout_seconds"),
            ([{**GOOD_TOOL, "max_output_bytes": 50}], "max_output_bytes"),
            ([{**GOOD_TOOL, "extra": 1}], "неизвестное поле"),
            ([GOOD_TOOL, GOOD_TOOL], "повтор"),
            ("не список", "список"),
        ]
        for tools, frag in bad:
            self.assertIn(frag, self.errs(tools), tools)


class CatalogExportTests(Env):
    def catalog(self):
        return json.loads(self.mgr.tools_path().read_text(encoding="utf-8"))

    def names(self):
        return [t["name"] for t in self.catalog()["tools"]]

    def test_enable_exports_an_expanded_catalog(self):
        self.mgr.install(ROOT / "modules" / "demo_tools")
        self.assertFalse(self.mgr.tools_path().exists())   # установленный, но не включённый модуль ничего не добавляет
        self.mgr.enable("demo_tools")
        c = self.catalog()
        self.assertEqual(c["version"], 1)
        self.assertEqual(c["errors"], [])
        self.assertEqual(self.names(), ["demo_echo", "demo_add"])
        t = c["tools"][1]
        mdir = str(self.mgr.module_dir("demo_tools"))
        self.assertEqual(t["module"], "demo_tools")
        self.assertEqual(t["command"], ["python3", mdir + "/tools.py"])   # шаблоны раскрыты
        self.assertEqual(t["cwd"], mdir)
        self.assertEqual(t["parameters"]["required"], ["a", "b"])
        self.assertEqual(t["parameters"]["properties"]["a"]["type"], "integer")
        self.assertEqual((t["timeout_seconds"], t["max_output_bytes"]), (10, 8000))
        self.assertEqual(set(t["env"]), {"ZEROCORE_API", "ZEROCORE_HOME", "ZEROCORE_MODULE", "ZEROCORE_DATA_DIR"})
        self.assertNotIn("${", self.mgr.tools_path().read_text())

    def test_no_secrets_from_the_environment_leak_into_the_catalog(self):
        os.environ["ZC_TEST_SECRET"] = "s3cret-value"
        try:
            self.mgr.install(ROOT / "modules" / "demo_tools")
            self.mgr.enable("demo_tools")
            self.assertNotIn("s3cret-value", self.mgr.tools_path().read_text())
            self.assertNotIn("ZC_TEST_SECRET", self.mgr.tools_path().read_text())
        finally:
            del os.environ["ZC_TEST_SECRET"]

    def test_file_is_not_world_writable(self):
        self.mgr.install(ROOT / "modules" / "demo_tools")
        self.mgr.enable("demo_tools")
        mode = stat.S_IMODE(self.mgr.tools_path().stat().st_mode)
        self.assertEqual(mode & 0o022, 0, oct(mode))

    def test_disable_and_uninstall_remove_tools(self):
        self.inst("m1", kind="library", tools=[tool("tool_one")], files={"tool.py": ""})
        self.inst("m2", kind="library", tools=[tool("tool_two")], files={"tool.py": ""})
        self.mgr.enable("m1")
        self.mgr.enable("m2")
        self.assertEqual(sorted(self.names()), ["tool_one", "tool_two"])
        self.mgr.disable("m1")
        self.assertEqual(self.names(), ["tool_two"])
        self.mgr.uninstall("m2")
        self.assertEqual(self.names(), [])
        self.assertEqual(self.catalog()["version"], 1)

    def test_duplicate_names_first_module_wins_and_is_reported(self):
        self.inst("aaa", kind="library", tools=[tool("same_name", "from aaa")], files={"tool.py": ""})
        self.inst("bbb", kind="library", tools=[tool("same_name", "from bbb")], files={"tool.py": ""})
        self.mgr.enable("aaa")
        self.mgr.enable("bbb")
        c = self.catalog()
        self.assertEqual([(t["module"], t["description"]) for t in c["tools"]], [("aaa", "from aaa")])
        self.assertEqual(len(c["errors"]), 1)
        self.assertIn("уже занято модулем aaa", c["errors"][0])

    def test_config_changes_are_reflected(self):
        self.inst("cfg", kind="library", config_extra={"flag": "one"},
                  tools=[tool("cfg_tool", extra={"command": [PY, "${module_dir}/tool.py", "${config.flag}"]})], files={"tool.py": ""})
        self.mgr.enable("cfg")
        self.assertEqual(self.catalog()["tools"][0]["command"][-1], "one")
        self.mgr.config_set("cfg", "flag", "two")
        self.assertEqual(self.catalog()["tools"][0]["command"][-1], "two")

    def test_hot_swap_and_rollback_change_the_catalog(self):
        self.inst("sw", version="1.0.0", kind="library", tools=[tool("sw_tool", "version one")], files={"tool.py": ""})
        self.inst("sw", version="2.0.0", kind="library", tools=[tool("sw_tool", "version two")], files={"tool.py": ""})
        self.mgr.enable("sw")
        self.assertEqual(self.catalog()["tools"][0]["description"], "version one")
        self.assertIn("/versions/1.0.0/", self.catalog()["tools"][0]["command"][1])
        self.mgr.swap("sw", "2.0.0")
        self.assertEqual(self.catalog()["tools"][0]["description"], "version two")
        self.assertIn("/versions/2.0.0/", self.catalog()["tools"][0]["command"][1])
        self.mgr.rollback("sw")
        self.assertEqual(self.catalog()["tools"][0]["description"], "version one")

    def test_the_file_is_not_rewritten_when_nothing_changed(self):
        self.inst("m1", kind="library", tools=[tool("tool_one")], files={"tool.py": ""})
        self.mgr.enable("m1")
        before = (self.mgr.tools_path().stat().st_mtime_ns, self.catalog()["generated"])
        time.sleep(0.05)
        self.mgr.refresh_tools()
        self.inst("other", kind="library")   # модуль без инструментов не меняет каталог
        self.mgr.enable("other")
        self.assertEqual((self.mgr.tools_path().stat().st_mtime_ns, self.catalog()["generated"]), before)

    def test_catalog_is_recreated_on_start_when_missing(self):
        self.inst("m1", kind="library", tools=[tool("tool_one")], files={"tool.py": ""})
        self.mgr.enable("m1")
        self.mgr.tools_path().unlink()
        mgr2 = Manager(self.mgr.home, repo_root=ROOT)
        self.assertEqual([t["name"] for t in json.loads(mgr2.tools_path().read_text())["tools"]], ["tool_one"])

    def test_a_broken_module_does_not_stop_the_export(self):
        self.inst("good", kind="library", tools=[tool("good_tool")], files={"tool.py": ""})
        self.inst("broken", kind="library", tools=[tool("broken_tool")], files={"tool.py": ""})
        self.mgr.enable("good")
        self.mgr.enable("broken")
        (self.mgr.module_dir("broken") / "manifest.json").write_text("{not json")
        self.mgr.refresh_tools()   # не бросает исключение
        c = self.catalog()
        self.assertEqual([t["name"] for t in c["tools"]], ["good_tool"])
        self.assertTrue(any("broken" in e for e in c["errors"]))

    def test_events_and_cli(self):
        from zerocore.cli import main
        self.inst("m1", kind="library", tools=[tool("tool_one")], files={"tool.py": ""})
        self.mgr.enable("m1")
        topics = [e["topic"] for e in self.mgr.bus.recent(50)]
        self.assertIn("tools.exported", topics)
        self.assertEqual(main(["--home", str(self.mgr.home), "tools"]), 0)

    def test_invalid_tools_are_rejected_at_install(self):
        d = make_module(self.src, "badtools", tools=[{"name": "X", "description": "", "command": []}])
        with self.assertRaises(ContractError):
            self.mgr.install(d)


if __name__ == "__main__":
    unittest.main()
